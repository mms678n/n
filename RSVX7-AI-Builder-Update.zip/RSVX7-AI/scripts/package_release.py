#!/usr/bin/env python3
"""Package the full merged app, including build, without caches or runtime secrets."""
from __future__ import annotations
import os
import re
import gzip
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = Path(os.environ.get('RELEASE_OUTPUT', str(ROOT.parent / 'RSVX7-AI.zip'))).resolve()
FORBIDDEN = {'node_modules', '.git', '.venv', 'venv', 'private', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache', 'coverage', 'test-results', 'playwright-report', '.screenshots', 'test_reports', 'memory'}

def main():
    build = ROOT / 'frontend/build'
    manifest = json.loads((build / 'asset-manifest.json').read_text())
    for asset in set(manifest['files'].values()) | set(manifest['entrypoints']):
        target = (build / asset.lstrip('/')).resolve()
        assert target.is_relative_to(build.resolve()) and target.is_file(), f'Missing built asset: {asset}'
        compressed = Path(str(target) + '.gz')
        if compressed.is_file():
            assert gzip.decompress(compressed.read_bytes()) == target.read_bytes(), f'Stale compressed asset: {asset}'
    paths = []
    for folder, dirs, names in os.walk(ROOT):
        dirs[:] = sorted(d for d in dirs if d not in FORBIDDEN)
        for name in sorted(names):
            path = Path(folder) / name
            if path.is_symlink() or path.resolve() == TARGET: continue
            if name.startswith('.env') and name != '.env.example': continue
            if name.endswith(('.pyc','.pyo','.log','.zip')) or name == 'test_credentials.md' or 'owner-credentials' in name: continue
            paths.append(path)
    required = ('frontend/build/index.html','frontend/build/internal/project-verifier.js','builder/dist/service.mjs','builder/service.ts','backend/builder.py','scripts/run_services.py','frontend/pnpm-lock.yaml','frontend/pnpm-workspace.yaml','Dockerfile','OPERATIONS.txt','VALIDATION.txt','builder/vendor/darkforge/LICENSE','builder/vendor/darkforge/UPSTREAM.txt','backend/mysql_repository.py','backend/migrations/001_initial_schema.sql')
    for name in required:
        assert ROOT / name in paths, f'Missing required component: {name}'
    for name in ('builder/project-pipeline.ts','backend/huggingface_provider.py','scripts/switch_huggingface.py','builder/test-pipeline.mjs','builder/test-runtime-processes.mjs','tests/test_builder_pipeline.py'):
        assert ROOT / name in paths, f'Missing Builder update component: {name}'
    for name in ('backend/vps.py','frontend/src/pages/AdminVPS.jsx','Dockerfile.selfhost','Dockerfile.selfhost.dockerignore',
                 'deploy/compose.selfhost.yaml','deploy/Caddyfile','deploy/install-selfhost.sh','scripts/init_selfhost.py',
                 'scripts/start_local.py','scripts/check_selfhost.py','scripts/verify_gateway.py','scripts/https_status.py','frontend/src/glass-theme.css','Start-Local.cmd','Start-Local.sh','OPERATIONS.txt',
                 'backend/platform_updates.py','scripts/platform_updater.py','frontend/src/pages/PlatformUpdate.jsx','OPERATIONS.txt'):
        assert ROOT / name in paths, f'Missing VPS component: {name}'
    names = ('OPENROUTER_API_KEY','OPENAI_API_KEY','RSVX7_JWT_SECRET','JWT_SECRET','MANUS_API_KEY','RSVX7_MANAGED_OWNER_PASSWORD','OWNER_INITIAL_PASSWORD','TELEGRAM_BOT_TOKEN')
    secrets = [os.environ[name].encode() for name in names if len(os.environ.get(name,'')) >= 16]
    # Detect accidental copies of configured credentials even when packaging
    # without exporting the runtime .env into this process.
    for config in (ROOT / '.env', ROOT / 'backend/.env', ROOT / '.env.selfhost', ROOT / 'private/local.env'):
        if not config.is_file():
            continue
        for line in config.read_text().splitlines():
            name, separator, value = line.partition('=')
            value = value.strip().strip(chr(34)).strip(chr(39))
            if separator and name.strip() in names and len(value) >= 8 and not value.startswith('REPLACE_'):
                secrets.append(value.encode())

    expected = []
    for name in ('backend/remote_control/server.py','backend/remote_control/platform_model.py','remote-agent/agent.py','remote-ui/src/App.js','frontend/build/remote/index.html','frontend/build/remote/app.js','frontend/build/remote/styles.css','scripts/build_remote.mjs','OPERATIONS.txt','backend/migrations/002_remote_workspace.sql'):
        assert ROOT / name in paths, f'Missing remote integration component: {name}'
    for path in sorted(paths):
        relative = path.relative_to(ROOT)
        assert ROOT in path.resolve().parents
        data = path.read_bytes()
        assert not any(value in data for value in secrets), f'Credential value in {relative}'
        assert not re.search(rb'sk-or-v1-[0-9a-f]{32,}',data), f'Provider credential in {relative}'
        expected.append((relative, data))
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(TARGET,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for relative,data in expected:
            archive.write(ROOT / relative, 'RSVX7-AI/' + relative.as_posix())
    with zipfile.ZipFile(TARGET) as archive:
        assert archive.testzip() is None, 'CRC validation failed'
        assert len(archive.namelist()) == len(expected)
        for relative,data in expected:
            assert archive.read('RSVX7-AI/' + relative.as_posix()) == data, f'Content mismatch: {relative}'
    print(f'Verified release: {TARGET}; {len(expected)} files; {TARGET.stat().st_size} bytes')

if __name__ == '__main__': main()
