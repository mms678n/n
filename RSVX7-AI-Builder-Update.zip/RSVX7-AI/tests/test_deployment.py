"""Read-only deployment checks. Run against a running instance via SMOKE_BASE_URL."""
import os
import json
import re
from pathlib import Path

import pytest
import requests

ROOT = Path(__file__).resolve().parent.parent
BASE = os.environ.get("SMOKE_BASE_URL", "http://127.0.0.1:3000").rstrip("/")


@pytest.mark.parametrize("path", ["/", "/#chat", "/#dashboard", "/#admin"])
def test_frontend_shell(path):
    response = requests.get(BASE + path, timeout=10)
    assert response.status_code == 200
    assert re.search(r'<div\b[^>]*\bid="root"[^>]*>', response.text)
    assert "/static/js/" in response.text
    assert "posthog.init" not in response.text


@pytest.mark.parametrize("path", ["/healthz", "/readyz", "/api/", "/api/settings/public"])
def test_public_endpoints(path):
    response = requests.get(BASE + path, timeout=10)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)


def test_route_manifest():
    response = requests.get(BASE + "/manus-routes.json", timeout=10)
    assert response.status_code == 200
    document = response.json()
    expected = json.loads((ROOT / "frontend/public/manus-routes.json").read_text())
    assert document == expected
    routes = {route["path"] for route in document["routes"]}
    assert {"/", "/#chat", "/#dashboard", "/#admin", "/login", "/register", "/chat"} <= routes
    assert len(routes) == len(document["routes"])


@pytest.mark.parametrize("path", ["/api/not-real", "/missing.js", "/.env", "/private/owner-credentials.md", "/backend/server.py", "/static/js/missing.js"])
def test_missing_or_private_paths_are_not_spa(path):
    response = requests.get(BASE + path, timeout=10)
    assert response.status_code == 404
    assert not re.search(r'<div\b[^>]*\bid="root"[^>]*>', response.text)


@pytest.mark.parametrize("path", ["/api/auth/me", "/api/admin/stats", "/api/workspace/projects"])
def test_authentication_is_not_bypassed(path):
    assert requests.get(BASE + path, timeout=10).status_code == 401


def test_compose_private_database():
    import yaml
    config = yaml.safe_load((ROOT / "compose.yaml").read_text())
    assert "ports" not in config["services"]["mongo"]
    assert "mongo_data:/data/db" in config["services"]["mongo"]["volumes"]
    assert config["services"]["app"]["depends_on"]["mongo"]["condition"] == "service_healthy"
