"""Monthly rollover, permanent credit preservation, idempotency and access contracts."""
import asyncio, copy
from datetime import datetime, timezone
from unittest.mock import AsyncMock
import pytest
from fastapi import HTTPException
from tests.test_builder import MemoryDB, run
import memberships as m, tokens, auth, membership_api

NOW = datetime(2026, 1, 31, 12, tzinfo=timezone.utc)
@pytest.fixture
def database(monkeypatch):
    db = MemoryDB()
    for module in (tokens, auth, membership_api): monkeypatch.setattr(module, 'db', db)
    db.users.rows['member'] = {'_id':'member', 'username':'member','role':'user','token_balance':700}
    return db

def test_free_grant_and_rollover_preserve_purchased_credits(database):
    user = run(m.refresh(database.users.rows['member'],database,now=NOW))
    assert user['token_balance']==10700 and user['monthly']['remaining']==10000
    again = run(m.refresh(user,database,now=NOW))
    assert again['token_balance']==10700
    # Simulate spending only monthly funds, then rolling to February.
    run(database.users.update_one({'_id':'member'},{'$inc':{'token_balance':-3000,'monthly.remaining':-3000}}))
    user = run(m.refresh(run(database.users.find_one({'_id':'member'})),database,now=datetime(2026,2,1,tzinfo=timezone.utc)))
    assert user['token_balance']==10700 and m.wallet_fields(user)['purchased_remaining']==700

def test_paid_activation_replay_renewal_cancel_and_expiry(database):
    async def scenario():
        first, second = await asyncio.gather(m.activate(database,'member','pro','operation1',now=NOW),m.activate(database,'member','pro','operation1',now=NOW))
        assert first['monthly']['version']==second['monthly']['version']
        assert second['token_balance']==10_000_700
        assert second['monthly']['ends_at']=='2026-02-28T12:00:00+00:00'
        await database.users.update_one({'_id':'member'},{'$inc':{'token_balance':500}})
        renewed=await m.activate(database,'member','max','operation2',now=NOW)
        assert renewed['token_balance']==25_001_200
        expired=await m.refresh(renewed,database,now=datetime(2026,3,1,tzinfo=timezone.utc))
        assert expired['monthly']['plan']=='free' and expired['token_balance']==11200
        assert m.wallet_fields(expired)['purchased_remaining']==1200
    run(scenario())

@pytest.mark.parametrize('plan,models,features',[
    ('free',['kaligpt'],[]),('pro',['kaligpt','deepdark'],['builder']),('max',['kaligpt','deepdark','rsvx7-ai'],['builder','hacker'])])
def test_all_plan_permissions(plan,models,features):
    user={'role':'user','monthly':m.period(plan,m.utcnow())}
    assert m.entitlements(user)['models']==models
    for model in m.PLANS['max']['models']:
        if model in models:m.require_access(user,model=model)
        else:
            with pytest.raises(HTTPException) as caught:m.require_access(user,model=model)
            assert caught.value.status_code==403
    for feature in ('builder','hacker'):
        if feature in features:m.require_access(user,feature=feature)
        else:
            with pytest.raises(HTTPException):m.require_access(user,feature=feature)

def test_monthly_is_debited_before_topups_and_retry_is_free(database):
    database.users.rows['member'].update(token_balance=20,monthly={**m.period('pro',m.utcnow()),'remaining':8})
    first=run(tokens.charge_user('member',prompt_tokens=8,completion_tokens=2,cached_tokens=2,idempotency_key='fixture-turn'))
    second=run(tokens.charge_user('member',prompt_tokens=8,completion_tokens=2,cached_tokens=2,idempotency_key='fixture-turn'))
    assert first['_id']==second['_id']
    assert first['billable_tokens']==12 and first['monthly_debit']==8 and first['purchased_debit']==4
    user=run(database.users.find_one({'_id':'member'}))
    assert user['token_balance']==8 and user['monthly']['remaining']==0

def test_failed_ledger_compensates_both_buckets(database,monkeypatch):
    database.users.rows['member'].update(token_balance=20,monthly={**m.period('pro',m.utcnow()),'remaining':8})
    monkeypatch.setattr(database.token_usage_history,'insert_one',AsyncMock(side_effect=RuntimeError('ledger failure')))
    with pytest.raises(RuntimeError):run(tokens.charge_user('member',prompt_tokens=8,completion_tokens=0,idempotency_key='failed-turn'))
    user=run(database.users.find_one({'_id':'member'}))
    assert user['token_balance']==20 and user['monthly']['remaining']==8
    assert not user['billing_charge_markers']

def test_pending_request_never_grants_access_and_admin_activation_is_protected(database):
    from fastapi import FastAPI
    import httpx
    app=FastAPI();app.include_router(membership_api.router);app.include_router(membership_api.admin_router)
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='https://fixture.test') as client:
            headers={'Authorization':'Bearer '+auth.make_token('member','user')}
            request=await client.post('/api/memberships/request',headers=headers,json={'plan':'max'})
            assert request.status_code==200 and request.json()['request']['status']=='pending'
            user=await database.users.find_one({'_id':'member'})
            assert m.entitlements(user)['plan']=='free' and user['token_balance']==700
            denied=await client.post('/api/admin/memberships/member',headers=headers,json={'plan':'max','request_id':'fixture-activation'})
            assert denied.status_code==403
            database.users.rows['payer']={'_id':'payer','role':'admin','permissions':['payments'],'username':'payer'}
            paid={'Authorization':'Bearer '+auth.make_token('payer','admin')}
            activated=await client.post('/api/admin/memberships/member',headers=paid,json={'plan':'max','request_id':'fixture-activation'})
            assert activated.status_code==200,activated.text
            replay=await client.post('/api/admin/memberships/member',headers=paid,json={'plan':'max','request_id':'fixture-activation'})
            assert replay.json()['token_balance']==25_000_700
    run(scenario())

def test_expired_paid_plan_cannot_access_features_before_refresh():
    user={'role':'user','monthly':m.period('max',NOW)}
    with pytest.raises(HTTPException):m.require_access(user,feature='hacker')


def test_retry_between_debit_and_ledger_keeps_original_bucket_split(database,monkeypatch):
    database.users.rows['member'].update(token_balance=20,monthly={**m.period('pro',m.utcnow()),'remaining':8})
    insert=database.token_usage_history.insert_one
    first_writer=True
    async def interleave(document):
        nonlocal first_writer
        if first_writer:
            first_writer=False
            replay=await tokens.charge_user('member',prompt_tokens=8,completion_tokens=0,idempotency_key='interleaved')
            assert replay['monthly_debit']==8 and replay['purchased_debit']==4
            raise RuntimeError('simulated duplicate insert after retry committed')
        return await insert(document)
    monkeypatch.setattr(database.token_usage_history,'insert_one',interleave)
    result=run(tokens.charge_user('member',prompt_tokens=8,completion_tokens=0,idempotency_key='interleaved'))
    assert result['monthly_debit']==8
    user=run(database.users.find_one({'_id':'member'}))
    assert user['token_balance']==8 and user['monthly']['remaining']==0
    assert len(database.token_usage_history.rows)==1


def test_admin_adjustments_preserve_bucket_invariant(database):
    database.users.rows['member'].update(token_balance=1200,monthly={**m.period('pro',m.utcnow()),'remaining':1000})
    user, deducted=run(m.adjust_wallet(database,'member',deduct=100))
    assert deducted==100 and user['token_balance']==1100 and user['monthly']['remaining']==900
    user,_=run(m.adjust_wallet(database,'member',purchased=333))
    assert user['token_balance']==1233 and user['monthly']['remaining']==900
    user,deducted=run(m.adjust_wallet(database,'member',deduct=999999))
    assert deducted==1233 and user['token_balance']==0 and user['monthly']['remaining']==0


def test_rollover_rechecks_monthly_bucket_when_topup_restores_same_total(database):
    user=database.users.rows['member']
    user.update(token_balance=150,monthly={**m.period('pro',NOW),'remaining':100})
    stale=copy.deepcopy(user)
    # Debit monthly 10, then top up 10: the total is unchanged, the split is not.
    run(database.users.update_one({'_id':'member'},{'$inc':{'token_balance':-10,'monthly.remaining':-10}}))
    run(database.users.update_one({'_id':'member'},{'$inc':{'token_balance':10}}))
    renewed=run(m.refresh(stale,database,now=datetime(2026,3,1,tzinfo=timezone.utc)))
    assert renewed['token_balance']==10060 and renewed['monthly']['remaining']==10000
    assert m.wallet_fields(renewed)['purchased_remaining']==60
