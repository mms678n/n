import shlex
import sys
import threading
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'remote-agent'))
from execution import ExecutionManager, shell_args


def launch(script, timeout=5):
    events = []
    done, partial = threading.Event(), threading.Event()
    def send(event):
        events.append(event)
        if event['type'] == 'exec_output': partial.set()
        if event['type'] == 'exec_done': done.set()
    manager = ExecutionManager(send)
    manager.start('test', shlex.quote(sys.executable) + ' -c ' + shlex.quote(script), 'bash', timeout)
    return manager, events, done, partial


def test_streams_output_before_exit_without_newline():
    manager, events, done, partial = launch("import time; print('PARTIAL', end='', flush=True); time.sleep(0.6); print('DONE')")
    assert partial.wait(3)
    assert not done.is_set()
    assert done.wait(4)
    assert 'PARTIALDONE' in ''.join(e.get('data', '') for e in events)
    assert events[-1]['exit_code'] == 0


def test_agent_has_real_timeout():
    manager, events, done, partial = launch("import time; print('START', flush=True); time.sleep(30)", timeout=1)
    assert done.wait(5)
    assert events[-1]['exit_code'] == 124
    assert events[-1]['timed_out'] is True


def test_zero_timeout_allows_command_past_the_former_minimum_deadline():
    manager, events, done, partial = launch("import time; print('START', flush=True); time.sleep(1.4); print('DONE')", timeout=0)
    assert done.wait(5)
    assert events[-1]['exit_code'] == 0
    assert events[-1]['timed_out'] is False
    assert 'DONE' in ''.join(e.get('data', '') for e in events)


def test_cancel_stops_process_and_returns_status():
    manager, events, done, partial = launch("import time; print('START', flush=True); time.sleep(30)", timeout=0)
    assert partial.wait(3)
    manager.cancel('test')
    assert done.wait(5)
    assert events[-1]['exit_code'] == 130
    assert events[-1]['cancelled'] is True


def test_slow_output_consumer_receives_all_data_before_completion():
    events = []
    first, release, done = threading.Event(), threading.Event(), threading.Event()
    def send(event):
        if event['type'] == 'exec_output' and not first.is_set():
            first.set()
            release.wait(10)
        events.append(event)
        if event['type'] == 'exec_done': done.set()
    manager = ExecutionManager(send)
    script = "import sys; sys.stdout.write('X' * 8192)"
    command = shlex.quote(sys.executable) + ' -c ' + shlex.quote(script)
    manager.start('slow-output', command, 'bash', 0)
    try:
        assert first.wait(3)
        assert not done.wait(3.5), 'Completion overtook buffered output after the former three-second drain deadline'
    finally:
        release.set()
    assert done.wait(3)
    assert ''.join(e.get('data', '') for e in events) == 'X' * 8192
    assert events[-1]['exit_code'] == 0


def test_windows_uses_noninteractive_powershell_without_shell_true():
    with patch('execution.sys.platform', 'win32'):
        args = shell_args('Get-Date', 'auto')
    assert args[0] == 'powershell.exe'
    assert '-NonInteractive' in args
    assert 'Get-Date' in args[-1]
    assert 'LASTEXITCODE' in args[-1]
