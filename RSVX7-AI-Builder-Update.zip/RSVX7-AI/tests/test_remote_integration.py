"""Integration: real Mongo records, native auth/wallet and the namespaced module."""
import asyncio,io,json,os,secrets,sys,tarfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock
import httpx,pytest
from motor.motor_asyncio import AsyncIOMotorClient
os.environ.setdefault('MONGO_URL','mongodb://127.0.0.1:27017')
os.environ.setdefault('DB_NAME','rsvx7ai_test_remote')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
import server,auth,tokens,ai_settings
from remote_control import server as remote,store,platform_model
from remote_control.auth_bridge import ws_identity

BASE='/api/remote/api'

def scenario(monkeypatch,action):
    async def run():
        client=AsyncIOMotorClient('mongodb://127.0.0.1:27017',serverSelectionTimeoutMS=3000)
        name='rsvx7ai_test_remote_'+secrets.token_hex(6);db=client[name]
        for module in (auth,tokens,ai_settings,platform_model):monkeypatch.setattr(module,'db',db)
        monkeypatch.setattr(store,'get_database',lambda:db)
        await db.users.insert_many([{'_id':uid,'username':uid,'role':'user','status':'active','session_version':0,'token_balance':100000,'monthly':{'plan':'max','remaining':0,'allowance':25000000,'starts_at':'2026-01-01T00:00:00+00:00','ends_at':'2099-01-01T00:00:00+00:00','version':'fixture-max'}} for uid in ('alice','bob')])
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app),base_url='https://fixture.local') as http:
            async def request(path,uid='alice',method='GET',body=None):
                headers={'Authorization':'Bearer '+auth.make_token(uid,'user')} if uid else {}
                return await http.request(method,BASE+path,headers=headers,json=body)
            try:await action(db,request)
            finally:await client.drop_database(name);client.close()
    asyncio.run(run())

def test_shared_identity_and_no_secondary_accounts(monkeypatch):
    async def action(db,request):
        assert (await request('/servers',None)).status_code==401
        assert (await request('/auth/me')).json()['username']=='alice'
        assert (await request('/auth/register',method='POST',body={'username':'escape','password':'password'})).status_code==404
        assert (await request('/admin/users')).status_code==404
        assert await db.users.count_documents({})==2
        await db.users.update_one({'_id':'alice'},{'$set':{'status':'suspended'}})
        assert (await request('/servers')).status_code==403
    scenario(monkeypatch,action)

def test_server_storage_encryption_ownership_and_validation(monkeypatch):
    async def action(db,request):
        result=await request('/servers',method='POST',body={'nickname':'fixture','host':'127.0.0.1','username':'tester','password':'fixture-password'})
        assert result.status_code==200,result.text
        sid=result.json()['id'];saved=await db.remote_servers.find_one({'_id':sid})
        assert saved['password_enc']!='fixture-password' and 'password_enc' not in result.text
        assert not await db.projects.count_documents({})
        assert (await request('/servers','bob')).json()==[]
        assert (await request('/servers/'+sid+'/connect','bob','POST')).status_code==404
        assert (await request('/servers/'+sid+'/docker/container/start/bad;command',method='POST')).status_code==400
        assert (await request('/devices/not-an-id')).status_code==404
    scenario(monkeypatch,action)

def test_agent_bundle_embeds_this_deployment_and_has_no_secrets(monkeypatch):
    async def action(db,request):
        monkeypatch.setenv('OPENROUTER_SITE_URL','https://ai.fixture.test')
        result=await request('/agent/download/windows',None)
        assert result.status_code==200 and 'https://ai.fixture.test/api/remote' in result.text
        assert 'emergent' not in result.text
        result=await request('/agent/bundle',None)
        with tarfile.open(fileobj=io.BytesIO(result.content),mode='r:gz') as bundle:
            config=json.load(bundle.extractfile('hackergpt-agent/agent_server.json'))
            assert config['agent_server_url']=='https://ai.fixture.test/api/remote'
            assert not any('secret' in n or '.env' in n for n in bundle.getnames())
    scenario(monkeypatch,action)

def test_native_websocket_session_revocation_and_origin(monkeypatch):
    async def action(db,request):
        token=auth.make_token('alice','user')
        ws=SimpleNamespace(headers={'host':'fixture.local','origin':'https://fixture.local'})
        assert (await ws_identity(ws,token))['sub']=='alice'
        with pytest.raises(Exception):await ws_identity(SimpleNamespace(headers={'host':'fixture.local','origin':'https://foreign.test'}),token)
        await db.users.update_one({'_id':'alice'},{'$inc':{'session_version':1}})
        with pytest.raises(Exception):await ws_identity(ws,token)
    scenario(monkeypatch,action)

def test_autonomous_sse_uses_platform_model_wallet_and_saved_evidence(monkeypatch):
    async def action(db,request):
        profile=[];calls=[];step=0
        async def settings(name):
            profile.append(name)
            return {'model':'fixture/platform-model','context_length':32000,'max_completion_tokens':512,'supported_parameters':['tools']}
        monkeypatch.setattr(ai_settings,'current_settings',settings)
        monkeypatch.setattr(platform_model,'require_membership',AsyncMock())
        async def create(**kwargs):
            nonlocal step
            calls.append(kwargs);step+=1
            if step<=2:
                name='run_command';args={'command':'printf VERIFIED','stage':'inspect' if step==1 else 'verify','shell':'bash','explanation':'فحص فعلي'}
            else:
                name='finish_task';args={'status':'success','summary':'تم التحقق','evidence':[{'step_id':2,'finding':'VERIFIED'}]}
            tool=SimpleNamespace(id='tool'+str(step),function=SimpleNamespace(name=name,arguments=json.dumps(args)))
            return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content='',tool_calls=[tool]))],usage=SimpleNamespace(prompt_tokens=100,completion_tokens=40,prompt_tokens_details=None))
        model=SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
        monkeypatch.setattr(ai_settings,'client',model);monkeypatch.setattr(ai_settings,'request_client',lambda fallback:fallback)
        async def execute(target,command,shell,timeout,on_output):
            await on_output('VERIFIED');return {'exit_code':0,'output':'VERIFIED','duration':.01}
        monkeypatch.setattr(remote.ssh_manager,'run_command_stream',execute)
        result=await request('/servers',method='POST',body={'nickname':'fixture','host':'127.0.0.1','username':'tester','password':'fixture'})
        result=await request('/ai/chat',method='POST',body={'server_id':result.json()['id'],'message':'Check the fixture value'})
        assert result.status_code==200,result.text
        events=[json.loads(line[5:]) for line in result.text.splitlines() if line.startswith('data:')]
        assert events[-1]['type']=='done' and events[-1]['status']=='success',events
        assert all(call['model']=='fixture/platform-model' for call in calls)
        assert profile and set(profile)=={'deepdark'}
        assert await db.token_usage_history.count_documents({'user_id':'alice'})==3
        assert (await db.users.find_one({'_id':'alice'}))['token_balance']<100000
        assert await db.remote_messages.count_documents({'role':'assistant','task.verified':True})==1
        assert not await db.ai_request_leases.count_documents({})
        assert await db.messages.count_documents({})==0
    scenario(monkeypatch,action)

@pytest.mark.parametrize('complete',[True,False])
def test_conversation_stream_and_cancelled_provider_cleanup(monkeypatch,complete):
    async def action(db,request):
        monkeypatch.setattr(ai_settings,'current_settings',AsyncMock(return_value={'model':'fixture/stream','context_length':32000,'max_completion_tokens':512}))
        monkeypatch.setattr(platform_model,'require_membership',AsyncMock())
        closed=[]
        class Stream:
            def __aiter__(self):return self.events()
            async def events(self):
                yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content='مرحبا'),finish_reason=None)],usage=None)
                if complete:yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content=''),finish_reason='stop')],usage=SimpleNamespace(prompt_tokens=40,completion_tokens=10,prompt_tokens_details=None))
            async def close(self):closed.append(True)
        async def create(**kwargs):
            assert kwargs['stream'] and kwargs['model']=='fixture/stream'
            return Stream()
        monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
        monkeypatch.setattr(ai_settings,'request_client',lambda fallback:fallback)
        result=await request('/ai/chat',method='POST',body={'message':'مرحبا'})
        events=[json.loads(line[5:]) for line in result.text.splitlines() if line.startswith('data:')]
        assert any(event.get('type')=='delta' and event['content']=='مرحبا' for event in events)
        assert events[-1]['status']==('answered' if complete else 'blocked')
        assert closed and not await db.ai_request_leases.count_documents({})
        assert await db.token_usage_history.count_documents({})==(1 if complete else 0)
    scenario(monkeypatch,action)


def test_provider_error_message_does_not_leak_raw_diagnostics():
    from openai import APIStatusError
    from remote_control.errors import public_error
    error=APIStatusError('PRIVATE PROVIDER BODY',response=httpx.Response(401,request=httpx.Request('POST','https://fixture.provider')),body={'private':'DO NOT EXPOSE'})
    message=public_error(error)
    assert 'PRIVATE' not in message and 'DO NOT EXPOSE' not in message
    assert 'المزوّد' in message

@pytest.mark.parametrize('streaming',[False,True])
@pytest.mark.parametrize('cache_field',['details','cache_hit'])
def test_remote_wallet_uses_native_cached_token_formula(monkeypatch,streaming,cache_field):
    async def action(db,request):
        monkeypatch.setattr(ai_settings,'current_settings',AsyncMock(return_value={'model':'fixture/wallet','context_length':32000,'max_completion_tokens':512}))
        monkeypatch.setattr(platform_model,'require_membership',AsyncMock())
        usage=SimpleNamespace(prompt_tokens=100,completion_tokens=50,
            prompt_tokens_details=SimpleNamespace(cached_tokens=20) if cache_field=='details' else None,
            prompt_cache_hit_tokens=20 if cache_field=='cache_hit' else 0)
        class Stream:
            def __aiter__(self):return self.events()
            async def events(self):
                yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content='اختبار'),finish_reason='stop')],usage=None)
                # The usage-only terminal event is valid and must not double charge.
                yield SimpleNamespace(choices=[],usage=usage)
            async def close(self):pass
        async def create(**kwargs):
            return Stream() if streaming else SimpleNamespace(usage=usage,choices=[SimpleNamespace(message=SimpleNamespace(content='اختبار',tool_calls=None))])
        monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
        monkeypatch.setattr(ai_settings,'request_client',lambda fallback:fallback)
        identity=await db.users.find_one({'_id':'alice'})
        marker=platform_model.actor.set(identity)
        try:
            result=await platform_model.client.create(messages=[{'role':'user','content':'اختبار'}],stream=streaming)
            if streaming:
                async for chunk in result:pass
        finally:platform_model.actor.reset(marker)
        assert (await db.users.find_one({'_id':'alice'}))['token_balance']==100000-195
        assert await db.token_usage_history.count_documents({'user_id':'alice'})==1
        assert not await db.ai_request_leases.count_documents({})
    scenario(monkeypatch,action)

@pytest.mark.parametrize('bad_tail',['content','error','conflicting_finish'])
def test_remote_stream_rejects_data_after_terminal_without_debit(monkeypatch,bad_tail):
    async def action(db,request):
        monkeypatch.setattr(ai_settings,'current_settings',AsyncMock(return_value={'model':'fixture/stream','context_length':32000,'max_completion_tokens':512}))
        monkeypatch.setattr(platform_model,'require_membership',AsyncMock())
        closed=[]
        class Stream:
            def __aiter__(self):return self.events()
            async def events(self):
                yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content='جواب'),finish_reason='stop')],usage=None)
                if bad_tail=='error':yield SimpleNamespace(error={'message':'failure'},choices=[],usage=None)
                else:yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content='late' if bad_tail=='content' else ''),finish_reason='length' if bad_tail=='conflicting_finish' else None)],usage=None)
            async def close(self):closed.append(True)
        async def create(**kwargs):return Stream()
        monkeypatch.setattr(ai_settings,'client',SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
        monkeypatch.setattr(ai_settings,'request_client',lambda fallback:fallback)
        result=await request('/ai/chat',method='POST',body={'message':'فحص'})
        events=[json.loads(line[5:]) for line in result.text.splitlines() if line.startswith('data:')]
        assert events[-1]['status']=='blocked'
        assert (await db.users.find_one({'_id':'alice'}))['token_balance']==100000
        assert await db.token_usage_history.count_documents({})==0
        assert closed and not await db.ai_request_leases.count_documents({})
    scenario(monkeypatch,action)

def test_protocol_cache_key_tracks_actual_platform_assignment(monkeypatch):
    async def run():
        monkeypatch.setattr(ai_settings,'current_settings',AsyncMock(side_effect=[{'model':'provider/old'},{'model':'provider/new'}]))
        monkeypatch.setattr(ai_settings,'request_client',lambda fallback:SimpleNamespace(base_url='https://fixture.provider/v1'))
        first=await platform_model.client.protocol_key()
        second=await platform_model.client.protocol_key()
        assert first==('provider/old','https://fixture.provider/v1')
        assert second==('provider/new','https://fixture.provider/v1') and first!=second
    asyncio.run(run())

@pytest.mark.parametrize('plan,status',[('free',403),('pro',403),('max',200)])
def test_remote_requires_max_even_with_large_topup(monkeypatch,plan,status):
    import memberships
    async def action(db,request):
        await db.users.update_one({'_id':'alice'},{'$set':{'monthly':{**memberships.period(plan,memberships.utcnow()),'remaining':0},'token_balance':99999999}})
        result=await request('/servers')
        assert result.status_code==status,result.text
    scenario(monkeypatch,action)
