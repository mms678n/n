"""اختبارات وحدة MySQL؛ pure افتراضياً، وintegration محلي اختياري فقط."""
from __future__ import annotations

import asyncio
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import pytest
import pytest_asyncio

sys.path.insert(0, str(Path(__file__).parents[1] / "backend"))

from mysql_repository import (  # noqa: E402
    DuplicateKeyError,
    MySQLConfigurationError,
    MySQLDatabase,
    parse_mysql_dsn,
)
from sql_document_ops import (  # noqa: E402
    UnsupportedMongoOperator,
    apply_projection,
    apply_update,
    compile_filter,
    matches_document,
)
from sql_schema import MIGRATIONS, TABLE_DDL  # noqa: E402


class TestPureSemantics:
    def test_null_missing_arrays_and_logical_filters(self):
        document = {"_id": "u1", "tags": ["ai", "mysql"], "profile": {"name": "Zo"}, "nullable": None}
        assert matches_document(document, {"nullable": None})
        assert matches_document(document, {"missing": {"$ne": "x"}})
        assert matches_document(document, {"tags": "mysql"})
        assert matches_document(document, {"$or": [{"profile.name": "Zo"}, {"role": "admin"}]})
        assert matches_document(document, {"tags": {"$nin": ["python"]}})
        assert not matches_document(document, {"tags": {"$nin": ["mysql"]}})
        assert matches_document(document, {"profile.name": {"$regex": "^z", "$options": "i"}})
        assert matches_document(document, {"nullable": {"$exists": True, "$type": "null"}})

    def test_update_contract_and_projection(self):
        old = {"_id": "u1", "token_balance": 4, "markers": ["a"], "nested": {"old": True}}
        new = apply_update(old, {
            "$inc": {"token_balance": 3},
            "$set": {"nested.value": "ok"},
            "$addToSet": {"markers": {"$each": ["a", "b"]}},
            "$max": {"high": 8},
            "$unset": {"nested.old": True},
        })
        assert new["token_balance"] == 7
        assert new["markers"] == ["a", "b"]
        assert new["nested"] == {"value": "ok"}
        assert new["high"] == 8
        assert apply_projection(new, {"token_balance": 1, "_id": 0}) == {"token_balance": 7}
        assert apply_projection(new, {"nested.old": 0})["nested"] == {"value": "ok"}
        with pytest.raises(UnsupportedMongoOperator):
            apply_update(old, {"$push": {"markers": "bad"}})

    def test_sql_compilation_is_bound_and_rejects_unsupported(self):
        compiled = compile_filter({
            "user_id": "u1",
            "$or": [{"token_balance": {"$gte": 3}}, {"telegram.verified": {"$exists": False}}],
        }, field_validator=lambda field: field)
        assert "%s" in compiled.sql
        assert "u1" not in compiled.sql
        assert "token_balance" not in compiled.sql or "JSON" in compiled.sql
        with pytest.raises(UnsupportedMongoOperator):
            compile_filter({"x": {"$where": "1=1"}}, field_validator=lambda field: field)

    def test_dsn_tls_policy_never_allows_remote_plaintext(self):
        local = parse_mysql_dsn(
            "mysql://root@localhost:3307/rsvx_test?ssl=false",
            allow_local_plaintext=True,
        )
        assert local.local_plaintext is True
        assert local.connect_kwargs["host"] == "localhost"
        with pytest.raises(MySQLConfigurationError):
            parse_mysql_dsn("mysql://u:p@example.invalid/db?ssl=false", allow_local_plaintext=True)
        with pytest.raises(MySQLConfigurationError):
            parse_mysql_dsn("mysql://u:p@localhost/db?verify=false", allow_local_plaintext=True)

    def test_schema_is_additive_and_versioned(self):
        all_sql = "\n".join(sql for _, sql in TABLE_DDL)
        assert "DROP " not in all_sql.upper()
        assert "TRUNCATE" not in all_sql.upper()
        assert MIGRATIONS[-1].version >= 1
        assert "rsvx7_users" in all_sql
        assert "uniq_rsvx7_users_telegram_verified" in all_sql
        assert "uniq_rsvx7_usage_user_date" in all_sql
        assert "uniq_rsvx7_charge_idempotency" in all_sql
        assert "uniq_rsvx7_redemptions_dedup" in all_sql


@pytest_asyncio.fixture
async def local_db():
    """لا تُقرأ DATABASE_URL؛ لا يعمل هذا fixture إلا باختيار محلي صريح."""
    if os.environ.get("RUN_MYSQL_TESTS") != "1":
        pytest.skip("MySQL integration tests require RUN_MYSQL_TESTS=1")
    url = os.environ.get("RSVX7_MYSQL_TEST_URL")
    if not url:
        pytest.skip("Set RSVX7_MYSQL_TEST_URL to an isolated local MariaDB DSN")
    db = MySQLDatabase(url, allow_local_plaintext=True, minsize=1, maxsize=8)
    if not db.parsed.local_plaintext:
        raise AssertionError("Integration tests must use localhost plaintext or an explicitly local TLS DSN")
    await db.initialize()
    await db.verify_schema()
    try:
        yield db
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_transaction_rollback(local_db):
    uid = "test-rollback-" + os.urandom(6).hex()
    with pytest.raises(RuntimeError):
        async with local_db.transaction(("users",)):
            await local_db.users.insert_one({"_id": uid, "username": uid})
            raise RuntimeError("rollback probe")
    assert await local_db.users.find_one({"_id": uid}) is None


@pytest.mark.asyncio
async def test_concurrent_upsert_same_id_rejects_nonmatching_filter(local_db):
    uid = "test-upsert-" + os.urandom(6).hex()
    async def attempt(marker: str):
        return await local_db.users.update_one(
            {"_id": uid, "marker": marker}, {"$set": {"marker": marker}}, upsert=True
        )
    results = await asyncio.gather(attempt("a"), attempt("b"), return_exceptions=True)
    assert sum(not isinstance(result, Exception) for result in results) == 1
    assert sum(isinstance(result, DuplicateKeyError) for result in results) == 1


@pytest.mark.asyncio
async def test_unique_redemption_idempotency_under_concurrency(local_db):
    key = "test-dedup-" + os.urandom(6).hex()
    async def attempt(suffix: str):
        return await local_db.redemptions.insert_one({
            "_id": "red-" + suffix + os.urandom(4).hex(),
            "user_id": "test-user",
            "code": "TEST",
            "dedup_key": key,
            "tokens": 10,
            "redeemed_at": datetime.now(timezone.utc),
        })
    results = await asyncio.gather(attempt("a"), attempt("b"), return_exceptions=True)
    assert sum(not isinstance(result, Exception) for result in results) == 1
    assert sum(isinstance(result, DuplicateKeyError) for result in results) == 1
