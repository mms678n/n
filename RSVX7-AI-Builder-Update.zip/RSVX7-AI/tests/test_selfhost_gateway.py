"""Real loopback HTTP/TLS and installer regressions; no production services."""
from contextlib import contextmanager, redirect_stdout
import copy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import tempfile
from threading import Thread
import types
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import check_selfhost
from init_selfhost import configure_site, prepare, site_values
from verify_gateway import GatewayError, error_code, gateway_settings, load_settings, probe


def configuration(port,*,tls=False,host='127.0.0.1'):
    origin=('https' if tls else 'http')+'://'+host
    return {'services':{'app':{'environment':{'CORS_ORIGINS':origin,'COOKIE_SECURE':str(tls).lower(),'RSVX7_RELEASE_ID':'fixture-release','OPENROUTER_API_KEY':'private-fixture-never-print'}},
            'gateway':{'environment':{'SITE_ADDRESS':host if tls else ':80'},'ports':[{'target':443 if tls else 80,'published':str(port),'host_ip':'127.0.0.1','protocol':'tcp'}]}}}


@contextmanager
def serving(context=None,*,release='fixture-release',redirect=False):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def handle(self):
            # A TLS-only client may close before sending an HTTP request.
            try:super().handle()
            except (BrokenPipeError,ConnectionResetError):pass
        def do_GET(self):
            self.send_response(302 if redirect else 200)
            self.send_header('Content-Type','application/json' if self.path=='/readyz' else 'text/html')
            if redirect:self.send_header('Location','https://other.example')
            self.end_headers()
            self.wfile.write(json.dumps({'status':'ready','release':release}).encode() if self.path=='/readyz' else b'<html>Fixture</html>')
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    server.daemon_threads=True
    if context:server.socket=context.wrap_socket(server.socket,server_side=True)
    thread=Thread(target=server.serve_forever,daemon=True);thread.start()
    try:yield server.server_port
    finally:server.shutdown();server.server_close();thread.join(timeout=2)


class SiteConfigurationTests(unittest.TestCase):
    def test_update_changes_only_site_keys_and_preserves_credentials_comments_and_permissions(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'private.env'
            original='# private\r\nMONGO_INITDB_ROOT_PASSWORD=same-database-secret\r\nRSVX7_JWT_SECRET=same-auth-secret\r\nSITE_ADDRESS=:80\r\nCORS_ORIGINS=http://localhost\r\nOPENROUTER_SITE_URL=http://localhost\r\nCOOKIE_SECURE=false\r\nOTHER="literal $KEEP `TEXT`"\r\n'
            target.write_bytes(original.encode());target.chmod(0o600)
            self.assertTrue(configure_site(target,'https://rsvx7-ai.com'))
            current=target.read_bytes().decode()
            before=[x for x in original.splitlines() if x.split('=',1)[0] not in site_values('https://rsvx7-ai.com')]
            after=[x for x in current.splitlines() if x.split('=',1)[0] not in site_values('https://rsvx7-ai.com')]
            self.assertEqual(before,after)
            self.assertIn('SITE_ADDRESS=rsvx7-ai.com\r\n',current)
            self.assertIn('COOKIE_SECURE=true\r\n',current)
            self.assertEqual(target.stat().st_mode&0o777,0o600)
            self.assertFalse(configure_site(target,'https://rsvx7-ai.com'))
            self.assertFalse(list(Path(folder).glob('.site-config-*')))

    def test_invalid_origin_or_missing_env_cannot_regenerate_credentials(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'private.env';target.write_text('JWT_SECRET=unchanged\n')
            for site in ('https://user:pw@example.com','https://example.com/path','https://127.0.0.1','https://example.com:8443','https://example.com/?x=1'):
                with self.assertRaises(ValueError):configure_site(target,site)
                self.assertEqual(target.read_text(),'JWT_SECRET=unchanged\n')
            with self.assertRaises(FileNotFoundError):configure_site(Path(folder)/'missing.env','https://example.com')

    def test_first_install_still_creates_once_and_existing_init_is_readonly(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'private.env'
            self.assertTrue(prepare(target,{'siteUrl':'https://example.com'}))
            original=target.read_bytes()
            self.assertFalse(prepare(target,{'siteUrl':'https://different.example'}))
            self.assertEqual(target.read_bytes(),original)

    def test_preflight_rejects_http_only_for_https_origins_or_secure_cookies(self):
        value=configuration(80)
        value['services']['app']['environment']['CORS_ORIGINS']='https://example.com'
        with self.assertRaisesRegex(GatewayError,'https_not_configured'):gateway_settings(value)
        value['services']['app']['environment']['CORS_ORIGINS']='http://example.com'
        value['services']['app']['environment']['COOKIE_SECURE']='true'
        with self.assertRaisesRegex(GatewayError,'https_not_configured'):gateway_settings(value)

    def test_preflight_uses_actual_published_port_and_accepts_local_launcher(self):
        settings=gateway_settings(configuration(8080,host='localhost'))
        self.assertEqual(settings['origin'],'http://localhost:8080')
        self.assertEqual(settings['connect_host'],'127.0.0.1')
        for address in ('https://user:pass@example.com','http://example.com:8080','https://example.com/path','a.example b.example'):
            value=configuration(443,tls=True,host='fixture.example')
            value['services']['gateway']['environment']['SITE_ADDRESS']=address
            with self.assertRaises(ValueError):gateway_settings(value)

    def test_compose_failure_output_never_discloses_secrets(self):
        with patch('verify_gateway.subprocess.run',return_value=types.SimpleNamespace(returncode=1,stdout='',stderr='MONGO_PASSWORD=private')):
            with self.assertRaisesRegex(GatewayError,'^compose_configuration_failed$'):load_settings(Path('/fixture.env'),Path('/fixture.yaml'))


class TLSFixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder=tempfile.TemporaryDirectory();root=Path(cls.folder.name)
        cls.cert=root/'cert.pem';key=root/'key.pem'
        subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=fixture.example','-addext','subjectAltName=DNS:fixture.example','-keyout',str(key),'-out',str(cls.cert)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        cls.server_context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);cls.server_context.load_cert_chain(cls.cert,key)
        cls.client_context=ssl.create_default_context(cafile=str(cls.cert))

    @classmethod
    def tearDownClass(cls):cls.folder.cleanup()


class GatewayTransportTests(TLSFixtureTests):
    def test_http_local_and_public_routes(self):
        with serving() as port:
            settings=gateway_settings(configuration(port))
            probe(settings,local=True);probe(settings)

    def test_actual_tls_uses_domain_sni_on_loopback_and_verifies_certificate(self):
        with serving(self.server_context) as port:
            settings=gateway_settings(configuration(port,tls=True,host='fixture.example'))
            probe(settings,local=True,context=self.client_context)
            with self.assertRaises(ssl.SSLCertVerificationError):probe(settings,local=True)
            wrong={**settings,'host':'wrong.example'}
            with self.assertRaises(ssl.SSLCertVerificationError):probe(wrong,local=True,context=self.client_context)

    def test_plain_http_on_https_port_is_not_ready(self):
        with serving() as port:
            settings=gateway_settings(configuration(port,tls=True,host='fixture.example'))
            with self.assertRaises(ssl.SSLError) as caught:probe(settings,local=True,timeout=1)
            self.assertEqual(error_code(caught.exception),'tls_handshake_failed')

    def test_public_tls_rejects_one_broken_dns_route_even_if_another_works(self):
        # Removing per-address verification must make this regression fail.
        real_resolver=socket.getaddrinfo
        with serving(self.server_context) as port:
            settings=gateway_settings(configuration(port,tls=True,host='fixture.example'))
            def resolve(host,requested_port,*args,**kwargs):
                if host=='fixture.example':
                    return real_resolver('127.0.0.2',requested_port,*args,**kwargs)+real_resolver('127.0.0.1',requested_port,*args,**kwargs)
                return real_resolver(host,requested_port,*args,**kwargs)
            with patch('socket.getaddrinfo',side_effect=resolve):
                with self.assertRaises(ConnectionError):probe(settings,context=self.client_context,timeout=1)

    def test_redirect_and_different_release_are_rejected(self):
        with serving(redirect=True) as port:
            with self.assertRaisesRegex(GatewayError,'gateway_http_response'):probe(gateway_settings(configuration(port)))
        with serving(release='old-release') as port:
            with self.assertRaisesRegex(GatewayError,'release_mismatch'):probe(gateway_settings(configuration(port)))


class InstallerTests(unittest.TestCase):
    def execute(self,port):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);deploy=root/'deploy';deploy.mkdir();scripts=root/'scripts';scripts.mkdir();bin_path=root/'bin';bin_path.mkdir()
            (deploy/'install-selfhost.sh').write_bytes((ROOT/'deploy/install-selfhost.sh').read_bytes())
            (deploy/'compose.selfhost.yaml').write_text('fixture')
            (root/'.env.selfhost').write_text('AI_PROVIDER=openrouter\n')
            config=root/'config.json';config.write_text(json.dumps(configuration(port)))
            wrapper="import runpy,sys\nsys.argv+=['--attempts','1','--delay','0']\nrunpy.run_path("+repr(str(ROOT/'scripts/verify_gateway.py'))+",run_name='__main__')\n"
            (scripts/'verify_gateway.py').write_text(wrapper)
            docker=bin_path/'docker'
            docker.write_text('#!/usr/bin/env python3\nimport os,sys,pathlib\nif "config" in sys.argv:print(pathlib.Path(os.environ["FIXTURE_COMPOSE"]).read_text())\n')
            docker.chmod(0o700)
            env=dict(os.environ,PATH=str(bin_path)+os.pathsep+os.environ['PATH'],FIXTURE_COMPOSE=str(config),RSVX7_RELEASE_ID='fixture-release')
            result=subprocess.run(['sh',str(deploy/'install-selfhost.sh')],env=env,cwd=root,capture_output=True,text=True,timeout=15)
            self.assertNotIn('private-fixture-never-print',result.stdout+result.stderr)
            return result

    def test_installer_announces_ready_only_after_gateway_check(self):
        with serving() as port:result=self.execute(port)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertLess(result.stdout.index('RSVX7_GATEWAY:ready'),result.stdout.index('RSVX7_STAGE:ready'))

    def test_app_ready_but_gateway_down_must_fail_install(self):
        with socket.socket() as closed:
            closed.bind(('127.0.0.1',0));port=closed.getsockname()[1]
        result=self.execute(port)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('RSVX7_STAGE:gateway',result.stdout)
        self.assertNotIn('RSVX7_STAGE:ready',result.stdout)


class HTTPSStatusTests(TLSFixtureTests):
    def diagnostic_module(self):
        self.assertTrue((ROOT/'scripts/https_status.py').is_file(),'A read-only VPS HTTPS diagnostic is required')
        import https_status
        return https_status

    def test_status_distinguishes_resolved_and_running_site_without_leaking_values(self):
        diagnostic=self.diagnostic_module()
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);binary=root/'docker'
            fixture={'services':{'app':{'environment':{'CORS_ORIGINS':'https://expected.example','RSVX7_JWT_SECRET':'do-not-print-this-secret'}},'gateway':{'environment':{'SITE_ADDRESS':'expected.example'},'ports':[]}}}
            container=[{'State':{'Status':'running'},'Config':{'Env':['SITE_ADDRESS=:80','API_KEY=do-not-print-this-secret']},'NetworkSettings':{'Ports':{'443/tcp':[{'HostIp':'0.0.0.0','HostPort':'443'}]}}}]
            binary.write_text('#!/usr/bin/env python3\nimport json,sys\nif "config" in sys.argv:print('+repr(json.dumps(fixture))+')\nelif "ps" in sys.argv:print("fixture-container")\nelif "inspect" in sys.argv:print('+repr(json.dumps(container))+')\nelif "logs" in sys.argv:print('+repr(json.dumps({'level':'error','msg':'obtaining certificate','error':'challenge failed: connection refused do-not-print-this-secret'}))+',file=sys.stderr)\n')
            binary.chmod(0o700)
            # Network calls are separate, real transport tests cover them below.
            with patch.dict(os.environ,{'PATH':str(root)+os.pathsep+os.environ['PATH']}),patch('socket.getaddrinfo',side_effect=socket.gaierror),patch('https_status.endpoint_status',return_value={'tls':'connection_failed'}):
                report=diagnostic.diagnose(root/'private.env',ROOT/'deploy/compose.selfhost.yaml','https://expected.example','135.181.205.186')
            self.assertEqual(report['configuration']['resolved_site'],'expected.example')
            self.assertEqual(report['gateway']['running_site'],':80')
            self.assertFalse(report['gateway']['site_matches_resolved'])
            self.assertEqual(report['gateway']['published_ports'][0]['target'],'443/tcp')
            self.assertIn('acme_connection_failed',report['gateway']['certificate_events'])
            self.assertNotIn('do-not-print-this-secret',json.dumps(report))
            self.assertFalse(report['ready'])

    def test_normal_certificate_attempt_is_not_reported_as_a_failure(self):
        diagnostic=self.diagnostic_module()
        events=diagnostic.certificate_events(json.dumps({'level':'info','logger':'tls.obtain','msg':'obtaining certificate'}))
        self.assertNotIn('certificate_error',events)

    def test_missing_docker_returns_fixed_error_without_traceback(self):
        self.diagnostic_module()
        result=subprocess.run([sys.executable,str(ROOT/'scripts/https_status.py'),'--site','https://example.com'],env=dict(os.environ,PATH='/nonexistent'),capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,1,result.stderr)
        report=json.loads(result.stdout)
        self.assertEqual(report['configuration']['error'],'compose_configuration_failed')
        self.assertNotIn('Traceback',result.stdout+result.stderr)

    def test_status_identifies_plain_http_on_tls_socket(self):
        diagnostic=self.diagnostic_module()
        with serving() as port:
            report=diagnostic.endpoint_status('fixture.example',port,'127.0.0.1',timeout=1)
        self.assertEqual(report['tls'],'tls_handshake_failed')

    def test_status_preserves_certificate_verification_and_domain_sni(self):
        diagnostic=self.diagnostic_module()
        with serving(self.server_context) as port:
            good=diagnostic.endpoint_status('fixture.example',port,'127.0.0.1',context=self.client_context)
            wrong=diagnostic.endpoint_status('wrong.example',port,'127.0.0.1',context=self.client_context)
        self.assertEqual(good['tls'],'verified')
        self.assertEqual(good['application'],'ready')
        self.assertEqual(wrong['tls'],'certificate_not_verified')


class EngineDiagnosticTests(unittest.TestCase):
    def test_current_engine_is_ready_and_old_protocol_is_rejected(self):
        class Response(io.BytesIO):
            status=200
            headers={'Content-Type':'text/html'}
        async def current_settings():return {'key_configured':False}
        fake_ai=types.SimpleNamespace(current_settings=current_settings,BASE_URL='http://fixture',AI_PROVIDER='openrouter')
        for protocol,expected in ((3,'ready'),(2,'not_ready')):
            def request(url,timeout):
                url=url.full_url if hasattr(url,'full_url') else url
                if url.endswith('/health'):body={'status':'ok','protocol':protocol,'mode':'direct'}
                elif url.endswith('/readyz'):body={'status':'ready'}
                else:return Response(b'<html>fixture</html>')
                return Response(json.dumps(body).encode())
            output=io.StringIO()
            with patch.dict(sys.modules,{'builder':types.SimpleNamespace(ENGINE_PROTOCOL=3),'ai_settings':fake_ai}),patch.dict(os.environ,{'RSVX7_JWT_SECRET':'fixture-only'}),patch('urllib.request.urlopen',side_effect=request),redirect_stdout(output):
                exec(check_selfhost.INNER_PROBE,{})
            report=json.loads(output.getvalue())
            self.assertEqual(report['engine'],expected)
            self.assertNotIn('fixture-only',output.getvalue())


if __name__=='__main__':unittest.main()
