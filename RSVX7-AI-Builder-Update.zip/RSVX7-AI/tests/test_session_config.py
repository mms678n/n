"""Pure configuration regression tests; no database, production secrets or HTTP calls."""
import sys
from pathlib import Path

import jwt
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from session_config import session_signing_secret

APP = "fixture-only-application-signing-key-0000000000"


def test_production_uses_application_key_not_platform_alias():
    env = {"RSVX7_RUNTIME_ENV": "production", "RSVX7_JWT_SECRET": APP,
           "JWT_SECRET": "short-platform-alias"}
    key = session_signing_secret(env, require_configured=True)
    assert key == APP
    encoded = jwt.encode({"sub": "fixture"}, key, algorithm="HS256")
    assert jwt.decode(encoded, APP, algorithms=["HS256"])["sub"] == "fixture"
    with pytest.raises(jwt.InvalidSignatureError):
        jwt.decode(encoded, env["JWT_SECRET"], algorithms=["HS256"])


@pytest.mark.parametrize("legacy", ["short", APP])
def test_production_never_falls_back_to_platform_key(legacy):
    with pytest.raises(RuntimeError, match="missing: RSVX7_JWT_SECRET"):
        session_signing_secret({"RSVX7_RUNTIME_ENV": "production", "JWT_SECRET": legacy})


@pytest.mark.parametrize("value", ["short", "REPLACE_" + "x" * 40, " " * 40])
def test_weak_app_key_rejected_without_echoing_value(value):
    with pytest.raises(RuntimeError, match="RSVX7_JWT_SECRET") as error:
        session_signing_secret({"RSVX7_RUNTIME_ENV": "production", "RSVX7_JWT_SECRET": value})
    assert value not in str(error.value)


def test_development_preserves_existing_signing_key():
    assert session_signing_secret({"JWT_SECRET": APP}, require_configured=True) == APP


def test_explicit_app_key_also_takes_priority_in_development():
    assert session_signing_secret({"RSVX7_JWT_SECRET": APP, "JWT_SECRET": "old-fixture"}) == APP


def test_production_cannot_generate_ephemeral_secret():
    with pytest.raises(RuntimeError, match="missing: RSVX7_JWT_SECRET"):
        session_signing_secret({"RSVX7_RUNTIME_ENV": "production"})


def test_configured_entrypoint_requires_a_key_even_in_development():
    with pytest.raises(RuntimeError, match="missing: RSVX7_JWT_SECRET"):
        session_signing_secret({}, require_configured=True)


def test_fixture_development_fallback_still_supports_import_only_tests():
    assert len(session_signing_secret({})) >= 32


def test_docker_always_uses_production_mode():
    text = (Path(__file__).resolve().parents[1] / "Dockerfile").read_text()
    assert "RSVX7_RUNTIME_ENV=production" in text
