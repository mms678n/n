import { useState, useRef, useEffect, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { Send, Bot, User, Square, Sparkles, ChevronRight, Plus, MessageSquare, Trash2 } from "lucide-react";
import { API, api, getToken, wsUrl } from "../lib/api";
import { consumeSSE, newTask, reduceTask, taskFromMessage } from "../lib/task-events";
import TaskProgress from "./TaskProgress";
import { Button } from "./ui/button";

const SUGGESTIONS = ["Check disk space usage", "Show memory and top processes", "Check installed software versions", "Check system health"];

export default function AutonomousChat({ targetType = "server", targetId, targetName = "server", online = true, terminalRef }) {
  const deviceMode = targetType === "device";
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [sessions, setSessions] = useState([]);
  const [showSessions, setShowSessions] = useState(false);
  const [wsReady, setWsReady] = useState(false);
  const sessionRef = useRef(null);
  const activeRef = useRef(null);
  const busyRef = useRef(false);
  const abortRef = useRef(null);
  const wsRef = useRef(null);
  const handlerRef = useRef(null);
  const scrollRef = useRef(null);
  const followRef = useRef(true);
  const requestRef = useRef(0);
  const prefix = deviceMode ? "device-chat" : "chat";

  const loadSessions = useCallback(async () => {
    try {
      const path = deviceMode ? "/devices/" + targetId + "/sessions"
        : "/ai/sessions" + (targetId ? "?server_id=" + encodeURIComponent(targetId) : "");
      const { data } = await api.get(path);
      setSessions(data);
    } catch { /* history should not interrupt execution */ }
  }, [deviceMode, targetId]);
  useEffect(() => { loadSessions(); }, [loadSessions]);

  const applyEvent = useCallback((event) => {
    const activeId = activeRef.current;
    if (activeId == null) return;
    setMessages((previous) => previous.map((message) => message.localId === activeId ? reduceTask(message, event) : message));
  }, []);
  const finishBusy = useCallback(() => {
    busyRef.current = false;
    setStreaming(false);
    activeRef.current = null;
    loadSessions();
  }, [loadSessions]);
  const onEvent = useCallback((event) => {
    if (event.type === "session") { sessionRef.current = event.session_id; return; }
    if (["command", "output", "exit"].includes(event.type)) terminalRef?.current?.writeExecutionEvent?.(event);
    if (event.type === "error") toast.error(event.message || event.content || "Task failed");
    if (event.type === "busy") { toast.message(event.message); return; }
    applyEvent(event);
    if (event.type === "done") finishBusy();
  }, [applyEvent, finishBusy, terminalRef]);
  useEffect(() => { handlerRef.current = onEvent; }, [onEvent]);

  useEffect(() => {
    let alive = true;
    let retry;
    let keepalive;
    let attempt = 0;
    requestRef.current += 1;
    abortRef.current?.abort();
    sessionRef.current = null;
    activeRef.current = null;
    busyRef.current = false;
    setMessages([]); setStreaming(false); setShowSessions(false);
    const connect = () => {
      if (!alive || !deviceMode || !targetId) return;
      const ws = new WebSocket(wsUrl("/api/ws/exec/" + targetId + "?token=" + encodeURIComponent(getToken() || "")));
      wsRef.current = ws;
      ws.onopen = () => {
        if (!alive) { ws.close(); return; }
        attempt = 0;
        setWsReady(true);
        keepalive = setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "ping" })); }, 20000);
      };
      ws.onmessage = (message) => {
        if (!alive || ws !== wsRef.current) return;
        try { handlerRef.current?.(JSON.parse(message.data)); } catch { /* malformed transport frame */ }
      };
      ws.onerror = () => { if (alive) setWsReady(false); };
      ws.onclose = () => {
        clearInterval(keepalive);
        if (!alive || ws !== wsRef.current) return;
        setWsReady(false);
        if (busyRef.current) {
          applyEvent({ type: "interrupted", message: "انقطع الاتصال قبل اكتمال المهمة. راجع الخطوات المنفذة قبل المتابعة. / Connection lost before completion. Review completed steps before continuing." });
          busyRef.current = false; setStreaming(false); activeRef.current = null;
        }
        // Reconnect the transport only. Never replay a task or historical command.
        retry = setTimeout(connect, Math.min(10000, 800 * (2 ** Math.min(attempt++, 4))));
      };
    };
    connect();
    return () => {
      alive = false;
      requestRef.current += 1;
      abortRef.current?.abort();
      clearTimeout(retry); clearInterval(keepalive);
      try { wsRef.current?.close(); } catch { /* noop */ }
    };
  }, [deviceMode, targetId, applyEvent]);

  useEffect(() => {
    if (followRef.current) scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "auto" });
  }, [messages]);

  const send = async (textArg) => {
    const text = (textArg ?? input).trim();
    if (!text || busyRef.current) return;
    if (!online) { toast.error("Device is offline. Start the Hacker rsvx7 Ai Agent."); return; }
    if (deviceMode && wsRef.current?.readyState !== WebSocket.OPEN) { toast.message("Connecting execution channel…"); return; }
    const turn = newTask(text);
    followRef.current = true;
    activeRef.current = turn.localId;
    busyRef.current = true;
    setStreaming(true); setInput("");
    setMessages((previous) => [...previous, { role: "user", content: text }, turn]);
    if (deviceMode) {
      wsRef.current.send(JSON.stringify({ type: "chat", message: text, session_id: sessionRef.current }));
      return;
    }
    const generation = requestRef.current;
    const controller = new AbortController();
    abortRef.current = controller;
    let receivedDone = false;
    try {
      const response = await fetch(API + "/ai/chat", {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + getToken() },
        body: JSON.stringify({ session_id: sessionRef.current, server_id: targetId, message: text,
          terminal_context: terminalRef?.current?.getBuffer?.() || null }), signal: controller.signal,
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.detail || "Server returned " + response.status);
      }
      await consumeSSE(response.body, (event) => {
        if (generation !== requestRef.current) return;
        if (event.type === "done") receivedDone = true;
        onEvent(event);
      });
      if (!receivedDone && generation === requestRef.current) {
        applyEvent({ type: "interrupted", message: turn.language === "ar" ? "انتهى الاتصال دون نتيجة نهائية مؤكدة." : "The stream ended without a confirmed final result." });
      }
    } catch (error) {
      if (generation !== requestRef.current) return;
      if (error.name === "AbortError") {
        applyEvent({ type: "result", status: "cancelled", summary: turn.language === "ar" ? "تم إيقاف المهمة. راجع سجل الخطوات المنفذة." : "Task stopped. Review completed steps in the execution history.", verified: false });
        applyEvent({ type: "done", status: "cancelled" });
      } else {
        toast.error(error.message);
        applyEvent({ type: "error", message: error.message });
      }
    } finally {
      if (generation === requestRef.current) { abortRef.current = null; finishBusy(); }
    }
  };

  const stop = () => {
    if (deviceMode) {
      if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({ type: "cancel" }));
    } else abortRef.current?.abort();
  };
  const newChat = () => {
    if (busyRef.current) return;
    sessionRef.current = null; setMessages([]); setShowSessions(false);
  };
  const loadSession = async (id) => {
    if (busyRef.current) return;
    const path = deviceMode ? "/devices/" + targetId + "/sessions/" + id + "/messages" : "/ai/sessions/" + id + "/messages";
    try {
      const { data } = await api.get(path);
      sessionRef.current = id; setMessages(data.map(taskFromMessage)); setShowSessions(false);
    } catch (error) { toast.error(error.response?.data?.detail || "Could not load chat"); }
  };
  const deleteSession = async (id, event) => {
    event.stopPropagation();
    if (busyRef.current) return;
    try { await api.delete("/ai/sessions/" + id); if (id === sessionRef.current) newChat(); loadSessions(); }
    catch { toast.error("Could not delete chat"); }
  };

  return <div className="h-full flex flex-col min-h-0 bg-[#0A0A0B]" data-testid={deviceMode ? "device-chat" : "ai-chat"}>
    <div className="flex items-center justify-between px-4 h-12 border-b border-white/8 shrink-0">
      <div className="flex items-center gap-2 min-w-0"><div className="w-6 h-6 rounded-md bg-gold/10 flex items-center justify-center"><Sparkles className="w-3.5 h-3.5 text-gold" /></div>
        <span className="font-display font-medium text-sm truncate">Hacker rsvx7 Ai</span><span className="text-[9px] tracking-wider uppercase text-gold/70 border border-gold/20 bg-gold/5 rounded px-1.5 py-0.5">Autonomous</span></div>
      <div className="flex items-center gap-1">
        <button onClick={() => setShowSessions(!showSessions)} title="History" aria-label="History" data-testid={prefix + "-history-btn"} className="p-1.5 rounded-md text-white/40 hover:text-white"><MessageSquare className="w-4 h-4" /></button>
        <button onClick={newChat} disabled={streaming} title="New chat" aria-label="New chat" data-testid={prefix + "-new-chat-btn"} className="p-1.5 rounded-md text-white/40 hover:text-white disabled:opacity-30"><Plus className="w-4 h-4" /></button>
      </div>
    </div>
    <div className="flex-1 flex min-h-0">
      <AnimatePresence>{showSessions && <motion.div initial={{ width: 0, opacity: 0 }} animate={{ width: 190, opacity: 1 }} exit={{ width: 0, opacity: 0 }} className="border-r border-white/8 overflow-hidden shrink-0">
        <div className="w-[190px] p-2 space-y-1 overflow-y-auto h-full">
          {!sessions.length && <p className="text-xs text-white/30 p-2">No saved chats</p>}
          {sessions.map((session) => <div key={session.id} className="flex items-center gap-1">
            <button disabled={streaming} onClick={() => loadSession(session.id)} className={"flex-1 min-w-0 text-start truncate px-2 py-2 rounded-lg text-xs disabled:opacity-30 " + (sessionRef.current === session.id ? "bg-white/10" : "text-white/60 hover:bg-white/5")}>{session.title}</button>
            <button disabled={streaming} title="Delete chat" aria-label="Delete chat" onClick={(event) => deleteSession(session.id, event)} className="p-1 text-white/30 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
          </div>)}
        </div>
      </motion.div>}</AnimatePresence>
      <div className="flex-1 flex flex-col min-w-0">
        <div ref={scrollRef} onScroll={() => { const el = scrollRef.current; followRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 100; }} className="flex-1 overflow-y-auto p-4 space-y-5">
          {!messages.length && <div className="h-full flex flex-col items-center justify-center text-center px-3">
            <div className="w-14 h-14 rounded-2xl bg-gold/10 flex items-center justify-center mb-4"><Bot className="w-7 h-7 text-gold" /></div>
            <h3 className="font-display text-xl font-medium">What would you like done?</h3>
            <p className="text-white/40 text-sm mt-2 mb-6 leading-relaxed max-w-sm">{online ? "Ask in any language. I execute, read the results, fix problems and verify the outcome on " + targetName + "." : "Start the Agent to connect this device."}</p>
            <div className="grid grid-cols-2 gap-2 w-full max-w-md">{SUGGESTIONS.map((suggestion) => <button key={suggestion} disabled={!online || (deviceMode && !wsReady)} onClick={() => send(suggestion)} data-testid={prefix + "-suggestion"} className="text-start text-xs p-3 rounded-xl glass hover:border-gold/30 transition-all flex items-center justify-between gap-2 disabled:opacity-40">{suggestion}<ChevronRight className="w-3 h-3 shrink-0 text-white/30" /></button>)}</div>
          </div>}
          {messages.map((message, index) => <div key={message.localId || index} className={"flex gap-2.5 " + (message.role === "user" ? "justify-end" : "")} data-testid={prefix + "-message-" + message.role}>
            {message.role === "assistant" && <div className="w-7 h-7 rounded-lg bg-gold/10 flex items-center justify-center shrink-0 mt-1"><Bot className="w-4 h-4 text-gold" /></div>}
            <div className={message.role === "user" ? "max-w-[85%]" : "w-full min-w-0"}>{message.role === "user" ? <div dir="auto" className="rounded-2xl rounded-br-sm bg-white/10 px-4 py-2.5 text-sm">{message.content}</div> : <TaskProgress turn={message} />}</div>
            {message.role === "user" && <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0 mt-1"><User className="w-4 h-4" /></div>}
          </div>)}
        </div>
        <div className="p-3 border-t border-white/8">
          <div className="flex items-end gap-2 rounded-2xl glass p-2 focus-within:border-gold/40 transition-colors">
            <textarea dir="auto" value={input} onChange={(event) => setInput(event.target.value)} rows={1} disabled={!online || streaming}
              onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }}
              placeholder={online ? "اكتب طلبك — التنفيذ والمتابعة تلقائيًا…" : "Device offline"} data-testid={prefix + "-input"}
              className="flex-1 bg-transparent resize-none outline-none text-sm px-2 py-1.5 max-h-32 placeholder:text-white/30 disabled:opacity-50" />
            {streaming ? <Button onClick={stop} size="icon" title="Stop task" aria-label="Stop task" data-testid={prefix + "-stop"} className="rounded-xl bg-white/10 hover:bg-white/20 shrink-0"><Square className="w-4 h-4" /></Button>
              : <Button onClick={() => send()} disabled={!input.trim() || !online || (deviceMode && !wsReady)} size="icon" aria-label="Send request" data-testid={prefix + "-send"} className="rounded-xl btn-crimson shrink-0 disabled:opacity-40"><Send className="w-4 h-4" /></Button>}
          </div>
          {deviceMode && !wsReady && online && <p className="text-[10px] text-white/30 mt-1.5 px-1">Connecting execution channel…</p>}
        </div>
      </div>
    </div>
  </div>;
}
