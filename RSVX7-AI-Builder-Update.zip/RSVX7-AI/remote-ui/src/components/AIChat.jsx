import AutonomousChat from "./AutonomousChat";

export default function AIChat({ serverId, terminalRef }) {
  return <AutonomousChat targetType="server" targetId={serverId} targetName="your SSH server" terminalRef={terminalRef} />;
}
