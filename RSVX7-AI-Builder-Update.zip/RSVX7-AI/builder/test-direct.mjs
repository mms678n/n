import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {source} from './fixtures/agent-fixtures.mjs';
const require=createRequire(new URL('../frontend/package.json',import.meta.url));
const folder=await mkdtemp(join(tmpdir(),'direct-builder-'));
let checks=0;
const test=async(name,fn)=>{await fn();checks++;console.log('PASS',name)};
const envelope=(names,remaining=[])=>JSON.stringify({actions:names.map(filePath=>({type:'file',filePath,content:source[filePath]})),remainingFiles:remaining});
try {
  const root=resolve(new URL('..',import.meta.url).pathname);
  await require('esbuild').build({stdin:{contents:`export {generateProject} from './builder/direct-build';export {normalizeFileResponse} from './builder/file-response';export {readModelResponse} from './builder/model-transport';`,resolveDir:root},bundle:true,platform:'node',format:'esm',target:'es2022',outfile:join(folder,'test.mjs'),alias:{'~':join(root,'builder/vendor/darkforge/app')},nodePaths:[join(root,'frontend/node_modules')],define:{'import.meta.env':'{}'}});
  const {generateProject,normalizeFileResponse:normalize,readModelResponse}=await import(pathToFileURL(join(folder,'test.mjs')));
  const names=Object.keys(source);
  const run=async(custom,files={},lockedPaths=[])=>{
    const calls=[],progress=[],controller=new AbortController();
    const result=await generateProject({files,lockedPaths,signal:controller.signal,progress:x=>progress.push(x),call:async call=>{
      calls.push(call);const reply=await custom?.(call,calls,controller);
      return reply||{text:envelope(call.required.length?call.required:names.slice(0,2),call.required.length?[]:names.slice(2)),finishReason:'stop'};
    }});return{result,calls,progress};
  };
  await test('all files are generated directly without a review report',async()=>{
    const {result,calls,progress}=await run();assert.equal(calls.length,3);assert.equal(result.annotation.type,'studioDirectBuild');assert.ok(!('tasks'in result.annotation));
    for(const name of names)assert.equal(result.files['/home/project/'+name].content,source[name]);
    assert.equal(progress.at(-1).files,names.length);
  });
  const content='  مرحبًا &lt;script&gt;\n```js\nconst tag="</boltAction>";\n```\n\n';
  for(const [label,value] of [
    ['canonical actions',{actions:[{type:'file',filePath:'index.html',content}]}],
    ['path alias',{actions:[{type:'file',path:'/home/project/index.html',content}]}],
    ['file_path alias',{actions:[{file_path:'index.html',content}]}],
    ['file map',{files:{'index.html':content}}],
    ['file object map',{files:{'index.html':{content}}}],
    ['file array',{files:[{filename:'index.html',content}]}],
  ])await test(label+' preserves exact source',()=>{
    const result=JSON.parse(normalize(JSON.stringify(value)).text);assert.equal(result.actions[0].content,content);assert.equal(result.actions[0].filePath,'index.html');
  });
  await test('prose and outer JSON fences do not corrupt embedded source fences',()=>{
    const raw='Here are the files:\n```json\n'+JSON.stringify({actions:[{type:'file',filePath:'x.html',content}]})+'\n```\nDone.';
    assert.equal(JSON.parse(normalize(raw).text).actions[0].content,content);
  });
  await test('a double-encoded document is decoded without editing its file strings',()=>{
    assert.equal(JSON.parse(normalize(JSON.stringify(JSON.stringify({files:{'x.html':content}}))).text).actions[0].content,content);
  });
  for(const [label,raw] of [
    ['truncated JSON','{"actions":[{"type":"file","filePath":"x.html","content":"unfinished'],
    ['multiple documents',envelope(['index.html'])+'\n'+envelope(['client.js'])],
    ['shell actions',JSON.stringify({actions:[{type:'shell',content:'echo unsafe'}]})],
    ['conflicting aliases',JSON.stringify({files:[{path:'one.js',filePath:'other.js',content:'x'}]})],
    ['traversal',JSON.stringify({files:{'../private':'x'}})],
    ['generated build output',JSON.stringify({files:{'dist/index.html':'x'}})],
    ['platform-owned tools',JSON.stringify({files:{'.darkforge/tool.js':'x'}})],
  ])await test(label+' is rejected',()=>assert.throws(()=>normalize(raw)));
  await test('one complete assigned file is accepted while the other stays queued',async()=>{
    const {result,calls}=await run(call=>call.required.length?{text:envelope(call.required.slice(0,1)),finishReason:'stop'}:undefined);
    assert.ok(calls.length>3);for(const name of names)assert.equal(result.files['/home/project/'+name].content,source[name]);
  });
  await test('completed files in remainingFiles do not produce repeated batches',async()=>{
    const {calls}=await run(()=>({text:envelope(['index.html'],['index.html']),finishReason:'stop'}));assert.equal(calls.length,1);
  });
  await test('invalid format is corrected using the actual failed response',async()=>{
    const {calls}=await run((call,calls)=>calls.length===1?{text:'not files',finishReason:'stop'}:undefined);
    assert.equal(calls[1].previousReply,'not files');assert.ok(calls[1].feedback.includes('file-actions'));
  });
  await test('validation retains the failing field without echoing source or losing old files',async()=>{
    const failures=[];
    await assert.rejects(generateProject({files:{},signal:new AbortController().signal,onValidationFailure:detail=>failures.push(detail),call:async()=>({text:JSON.stringify({actions:[{filePath:'index.html',content:{private:'never log this source'}}]}),finishReason:'stop'})}),/file_format/);
    assert.equal(failures.length,3);assert.ok(failures[0].reason.includes('actions[0].content'));assert.ok(!JSON.stringify(failures).includes('never log this source'));
  });
  await test('a truncated JSON string continues byte-for-byte across replies',async()=>{
    const raw=JSON.stringify({files:{'x.html':content}});let count=0;
    const {result}=await run(call=>++count===1?{text:raw.slice(0,32),finishReason:'length'}:{text:raw.slice(32),finishReason:'stop'});
    assert.equal(result.files['/home/project/x.html'].content,content);
  });
  await test('a complete restarted document replaces the truncated prefix',async()=>{
    let count=0;const {result}=await run(()=>++count===1?{text:'{"actions":[',finishReason:'length'}:{text:JSON.stringify({files:{'x.html':content}}),finishReason:'stop'});
    assert.equal(result.files['/home/project/x.html'].content,content);
  });
  await test('malformed output cannot mutate or release the previous project',async()=>{
    const files={'/home/project/index.html':{type:'file',content:'original',isBinary:false}};
    await assert.rejects(run(()=>({text:'invalid',finishReason:'stop'}),files),/file_format/);assert.equal(files['/home/project/index.html'].content,'original');
  });
  await test('locked source remains protected',async()=>await assert.rejects(run(()=>({text:envelope(['index.html']),finishReason:'stop'}),{},['index.html']),/file_format/));
  await test('binary assets cannot be overwritten by text',async()=>await assert.rejects(run(()=>({text:envelope(['index.html']),finishReason:'stop'}),{'/home/project/index.html':{type:'file',isBinary:true,content:'AA=='}}),/file_format/));
  await test('provider failures do not trigger format retries',async()=>{
    let calls=0;await assert.rejects(run(()=>{calls++;throw Error('provider unavailable')}),/provider unavailable/);assert.equal(calls,1);
  });
  await test('cancellation after model output prevents committing source',async()=>{
    await assert.rejects(run((call,calls,controller)=>{controller.abort();return{text:envelope(['index.html']),finishReason:'stop'}}),/abort/i);
  });
  const frame=(value)=>JSON.stringify(value)+'\r\n';
  const streamed=(text,split=true)=>new Response(new ReadableStream({start(controller){const bytes=new TextEncoder().encode(text);if(split)for(const byte of bytes)controller.enqueue(Uint8Array.of(byte));else controller.enqueue(bytes);controller.close()}}),{headers:{'content-type':'application/x-ndjson'}});
  await test('internal model stream handles one-byte UTF-8, CRLF and heartbeats',async()=>{
    const result=await readModelResponse(streamed('\n'+frame({type:'delta',text:'أهلاً '})+'\n'+frame({type:'delta',text:'وسهلاً'})+frame({type:'result',finishReason:'stop'})));
    assert.deepEqual(result,{text:'أهلاً وسهلاً',finishReason:'stop'});
  });
  await test('EOF before a final result is a failure',async()=>await assert.rejects(readModelResponse(streamed(frame({type:'delta',text:'partial'}))),/provider_protocol/));
  await test('private thinking becomes counts and accounting progress, never fabricated source',async()=>{
    const progress=[];
    const result=await readModelResponse(streamed(frame({type:'progress',reasoningChars:80,phase:'receiving'})+frame({type:'delta',text:'actual source'})+frame({type:'progress',reasoningChars:80,phase:'accounting'})+frame({type:'result',finishReason:'stop'})),event=>progress.push(event));
    assert.equal(result.text,'actual source');assert.equal(progress[0].chars,0);assert.equal(progress[0].reasoningChars,80);assert.equal(progress.at(-1).phase,'accounting');
  });
  await test('decreasing or malformed thinking counters fail the stream contract',async()=>{
    await assert.rejects(readModelResponse(streamed(frame({type:'progress',reasoningChars:80,phase:'receiving'})+frame({type:'progress',reasoningChars:20,phase:'receiving'}))),/provider_protocol/);
  });
  await test('content after the terminal event is rejected and closes the reader',async()=>{
    let cancelled=false;const data=frame({type:'result',finishReason:'stop'})+frame({type:'delta',text:'late'});
    const response=new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode(data))},cancel(){cancelled=true}}),{headers:{'content-type':'application/x-ndjson'}});
    await assert.rejects(readModelResponse(response),/provider_protocol/);assert.equal(cancelled,true);
  });
  await test('provider errors inside HTTP 200 are not mistaken for success',async()=>await assert.rejects(readModelResponse(streamed(frame({type:'error',status:502,message:'Provider unavailable'}))),/Provider unavailable/));
  console.log(`Direct generation and internal streaming checks passed: ${checks}`);
}finally{await rm(folder,{recursive:true,force:true})}
