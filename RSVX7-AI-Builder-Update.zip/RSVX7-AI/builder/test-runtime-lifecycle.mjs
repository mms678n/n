import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const require = createRequire(new URL('../frontend/package.json', import.meta.url));
const folder = await mkdtemp(join(tmpdir(), 'runtime-lifecycle-'));
let failures = 0;
const test = async (name, run) => {
  try { await run(); console.log('PASS', name); }
  catch (error) { failures++; console.error('FAIL', name, error.message); }
};
try {
  const root = resolve(new URL('..', import.meta.url).pathname);
  await require('esbuild').build({
    stdin: { contents: "export {ProjectRuntime} from './builder/vendor/darkforge/app/lib/runtime/project-runtime';", resolveDir: root },
    bundle: true, platform: 'node', format: 'esm', target: 'es2022', outfile: join(folder, 'runtime.mjs'),
    nodePaths: [join(root, 'frontend/node_modules')],
  });
  const { ProjectRuntime } = await import(pathToFileURL(join(folder, 'runtime.mjs')));
  const runtime = () => new ProjectRuntime(Promise.resolve({}), undefined, false);
  const fail = async (session, diagnostic) => {
    session.fileWritten('src/App.jsx');
    session.recordActionFailure(new Error(diagnostic));
    await session.verify();
  };
  await test('reopening a project at its automatic repair cap cannot restart the repair loop', async () => {
    const session = runtime();
    session.restoreRepairState({ automaticAttempts: 2 });
    session.beginTask(true);
    await fail(session, 'SyntaxError: src/App.jsx:7 Unexpected token');
    assert.equal(session.state.get().phase, 'failed');
    assert.equal(session.state.get().attempt, 2);
    assert.equal(session.repairRequest.get(), undefined);
    session.stop();
  });
  await test('restored attempt one permits only one more automatic repair across file application', async () => {
    const session = runtime();
    session.restoreRepairState({ automaticAttempts: 1 });
    session.beginTask(true);
    await fail(session, 'SyntaxError: src/App.jsx:7 Unexpected token');
    assert.equal(session.repairRequest.get().attempt, 2);
    session.beginTask(true, true);
    await fail(session, 'ReferenceError: src/App.jsx:12 missingName is not defined');
    assert.equal(session.state.get().phase, 'failed');
    assert.equal(session.repairRequest.get(), undefined);
    session.stop();
  });
  await test('repair handoff carries observed diagnostics and affected source; manual retry is explicit', async () => {
    const session = runtime();
    session.beginTask(true);
    await fail(session, 'SyntaxError: src/App.jsx:7 Unexpected token');
    const automatic = session.repairRequest.get();
    assert.equal(automatic.step, 'files');
    assert.equal(automatic.diagnostic, 'SyntaxError: src/App.jsx:7 Unexpected token');
    assert.equal(automatic.automatic, true);
    assert.deepEqual(automatic.affectedFiles, ['/home/project/src/App.jsx']);
    session.pause('Repair submission rejected');
    assert.equal(session.state.get().phase, 'failed');
    assert.equal(session.state.get().requestFailed, true);
    session.requestRepair();
    assert.equal(session.repairRequest.get().automatic, false);
    session.stop();
  });
  await test('network and browser environment failures never become model repair requests', async () => {
    for (const diagnostic of ['getaddrinfo ENOTFOUND registry.npmjs.org', 'SharedArrayBuffer is unavailable in this WebContainer']) {
      const session = runtime();
      session.beginTask(true);
      await fail(session, diagnostic);
      assert.equal(session.state.get().phase, 'failed');
      assert.equal(session.repairRequest.get(), undefined);
      assert.equal(session.canRequestRepair, false);
      session.stop();
    }
  });
} finally { await rm(folder, { recursive: true, force: true }); }
if (failures) process.exitCode = 1;
