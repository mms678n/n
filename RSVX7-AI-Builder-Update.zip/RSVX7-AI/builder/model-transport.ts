export class ModelRequestError extends Error { constructor(message: string, public status?: number) { super(message); } }
const failure = (code: string) => new Error('DF_CHAT_ERROR:' + JSON.stringify({ code }));

/** Incremental internal transport; EOF is successful only after a final result. */
export async function readModelResponse(response: Response, onProgress?: (progress: { chars: number; reasoningChars: number; phase?: 'receiving' | 'accounting' }) => void) {
  if (!response.ok) {
    const value: any = await response.json().catch(() => ({}));
    throw new ModelRequestError(typeof value.detail === 'string' ? value.detail : value.detail?.message || 'Model request failed', response.status);
  }
  if (!(response.headers.get('content-type') || '').includes('ndjson')) {
    const value: any = await response.json();
    if (typeof value.text !== 'string') throw failure('provider_protocol');
    onProgress?.({ chars: value.text.length, reasoningChars: 0 });
    return { text: value.text, finishReason: value.finishReason };
  }
  if (!response.body) throw failure('provider_protocol');
  const reader = response.body.getReader(), decoder = new TextDecoder('utf-8', { fatal: true });
  let buffer = '', text = '', reasoningChars = 0, ending: string | undefined, complete = false;
  const line = (input: string) => {
    if (!input.trim()) return;
    if (complete || input.length > 12 * 1024 * 1024) throw failure('provider_protocol');
    let value: any;
    try { value = JSON.parse(input); } catch { throw failure('provider_protocol'); }
    if (value.type === 'delta' && typeof value.text === 'string') {
      text += value.text;
      if (text.length > 8 * 1024 * 1024) throw failure('provider_protocol');
      onProgress?.({ chars: text.length, reasoningChars, phase: 'receiving' });
    } else if (value.type === 'progress' && ['receiving', 'accounting'].includes(value.phase) && Number.isSafeInteger(value.reasoningChars) && value.reasoningChars >= reasoningChars && value.reasoningChars <= 8 * 1024 * 1024) {
      reasoningChars = value.reasoningChars;
      onProgress?.({ chars: text.length, reasoningChars, phase: value.phase });
    } else if (value.type === 'result' && typeof value.finishReason === 'string') {
      ending = value.finishReason; complete = true;
    } else if (value.type === 'error') {
      throw new ModelRequestError(typeof value.message === 'string' ? value.message : 'provider_unavailable', value.status);
    } else throw failure('provider_protocol');
  };
  try {
    for (;;) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });
      let end: number;
      while ((end = buffer.indexOf('\n')) >= 0) { line(buffer.slice(0, end).replace(/\r$/, '')); buffer = buffer.slice(end + 1); }
      if (buffer.length > 12 * 1024 * 1024) throw failure('provider_protocol');
      if (done) break;
    }
    if (buffer.trim()) line(buffer);
    if (!complete) throw failure('provider_protocol');
    return { text, finishReason: ending };
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
