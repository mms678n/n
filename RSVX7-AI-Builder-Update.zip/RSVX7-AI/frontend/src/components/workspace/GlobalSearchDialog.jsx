import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Search, Folder, MessageSquare, FileText, Sparkles, Loader2, ArrowUpRight } from "lucide-react";
import { wsSearch } from "@/lib/workspacePhase2Client";
import { useWorkspace } from "@/context/WorkspaceContext";
import { ProjectIcon, WORKSPACE_BRAND_COLOR } from "@/components/workspace/ProjectSwitcher";
import { ActionButton, EmptyState, LoadingState, StatusNote } from "@/components/design/Primitives";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/workspace";
import "./workspace-ui.css";

const emptyResults = () => ({ projects: [], conversations: [], messages: [], files: [] });
const resultCount = (results) => Object.values(results).reduce((sum, value) => sum + (Array.isArray(value) ? value.length : 0), 0);
const isAbortError = (error) => error?.name === "AbortError" || error?.code === 20;

function useDebounced(value, milliseconds = 220) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), milliseconds);
    return () => window.clearTimeout(timer);
  }, [value, milliseconds]);
  return debounced;
}

function highlight(text, query) {
  const value = String(text || "");
  if (!query || !value) return value;
  const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const parts = value.split(new RegExp(`(${escaped})`, "gi"));
  return parts.map((part, index) => part.toLocaleLowerCase() === query.toLocaleLowerCase()
    ? <mark key={index} className="workspace-highlight">{part}</mark>
    : <React.Fragment key={index}>{part}</React.Fragment>);
}

function normalizeResults(value) {
  return {
    projects: Array.isArray(value?.projects) ? value.projects : [],
    conversations: Array.isArray(value?.conversations) ? value.conversations : [],
    messages: Array.isArray(value?.messages) ? value.messages : [],
    files: Array.isArray(value?.files) ? value.files : [],
  };
}

export default function GlobalSearchDialog({ open, onClose }) {
  const { projects, setCurrentProjectId } = useWorkspace();
  const { t, dir } = useI18n("workspace");
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounced(query);
  const [results, setResults] = useState(emptyResults);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef(null);
  const abortRef = useRef(null);
  const sequenceRef = useRef(0);

  useEffect(() => {
    if (!open) {
      abortRef.current?.abort();
      abortRef.current = null;
      setQuery("");
      setResults(emptyResults());
      setError(null);
      setLoading(false);
      setActiveIndex(0);
      return undefined;
    }
    const timer = window.setTimeout(() => inputRef.current?.focus(), 60);
    return () => window.clearTimeout(timer);
  }, [open]);

  const search = async (value) => {
    const trimmed = value.trim();
    abortRef.current?.abort();
    abortRef.current = null;
    if (trimmed.length < 2) {
      setResults(emptyResults());
      setError(null);
      setLoading(false);
      setActiveIndex(0);
      return;
    }
    const controller = new AbortController();
    const sequence = ++sequenceRef.current;
    abortRef.current = controller;
    setLoading(true);
    setError(null);
    try {
      const next = await wsSearch(trimmed, 8, { signal: controller.signal });
      if (controller.signal.aborted || sequence !== sequenceRef.current) return;
      setResults(normalizeResults(next));
      setActiveIndex(0);
    } catch (requestError) {
      if (controller.signal.aborted || sequence !== sequenceRef.current || isAbortError(requestError)) return;
      setError(requestError?.message || "تعذر البحث في مساحة العمل.");
      setResults(emptyResults());
    } finally {
      if (!controller.signal.aborted && sequence === sequenceRef.current) setLoading(false);
    }
  };

  useEffect(() => {
    if (open) search(debouncedQuery);
    // search is intentionally an effect-local action; the sequence/AbortController
    // guards make rapid typing safe even when the network resolves out of order.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedQuery, open]);

  const items = useMemo(() => [
    ...results.projects.map((item) => ({ type: "project", item })),
    ...results.conversations.map((item) => ({ type: "conversation", item })),
    ...results.messages.map((item) => ({ type: "message", item })),
  ], [results]);

  const openProject = (projectId) => { setCurrentProjectId(projectId); onClose(); };
  const openConversation = (conversation) => {
    setCurrentProjectId(conversation.project_id);
    onClose();
  };
  const activate = (entry) => {
    if (!entry) return;
    if (entry.type === "project") openProject(entry.item._id);
    else if (entry.type === "conversation" || entry.type === "message") openConversation(entry.item);
  };
  const onInputKeyDown = (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      if (items.length) {
        setActiveIndex((previous) => event.key === "ArrowDown"
          ? (previous + 1) % items.length
          : (previous - 1 + items.length) % items.length);
      }
    }
    if (event.key === "Enter") {
      event.preventDefault();
      activate(items[activeIndex]);
    }
  };
  const projectName = (projectId) => projects.find((project) => project._id === projectId)?.name || t("مشروع غير معروف");
  const hasSearch = debouncedQuery.trim().length >= 2;
  const empty = hasSearch && !loading && !error && resultCount(results) === 0;

  return (
    <Dialog open={open} onOpenChange={(value) => !value && onClose()}>
      <DialogContent className="workspace-dialog workspace-search-dialog" dir={dir} data-testid="global-search-dialog">
        <div className="workspace-dialog-head">
          <DialogHeader>
            <p className="workspace-kicker">{t("بحث سريع")} · <kbd dir="ltr">⌘K / Ctrl K</kbd></p>
            <DialogTitle className="workspace-dialog-title"><Search aria-hidden="true" /> {t("ابحث في مساحة العمل")}</DialogTitle>
            <DialogDescription className="workspace-dialog-description">{t("مشاريع، محادثات، رسائل وملفات — دون مغادرة السياق.")}</DialogDescription>
          </DialogHeader>
        </div>
        <div className="workspace-search-toolbar">
          <div className="workspace-search-field">
            <Search aria-hidden="true" />
            <Input
              ref={inputRef}
              autoFocus
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              onKeyDown={onInputKeyDown}
              placeholder={t("اكتب كلمتين على الأقل…")}
              data-testid="global-search-input"
              className="ds-input"
              aria-label={t("البحث في مساحة العمل")}
            />
            {loading && <Loader2 className="workspace-search-loader" aria-label={t("جارٍ البحث")} />}
          </div>
        </div>

        <div className="workspace-search-results" data-testid="global-search-results" role="listbox" aria-label={t("نتائج البحث")}>
          {!hasSearch && !loading && <div className="workspace-search-intro"><Search aria-hidden="true" /><strong>{t("ابدأ البحث من هنا")}</strong><span>{t("اكتب كلمتين على الأقل للبحث في كل مشاريعك.")}</span></div>}
          {loading && <LoadingState label={t("جارٍ البحث…")} compact />}
          {error && <StatusNote tone="error" onRetry={() => search(debouncedQuery)} retryLabel={t("إعادة المحاولة")}>{t("تعذر إكمال البحث: {error}", { error: t(error) })}</StatusNote>}
          {empty && <EmptyState title={t("لا توجد نتائج")} description={t("لم نعثر على شيء يطابق «{query}».", { query: debouncedQuery.trim() })} />}

          {results.projects.length > 0 && <Section title={t("المشاريع")} icon={Folder} count={results.projects.length}>
            {results.projects.map((project) => {
              const index = items.findIndex((entry) => entry.type === "project" && entry.item._id === project._id);
              return <button
                type="button"
                key={project._id}
                role="option"
                aria-selected={index === activeIndex}
                onMouseEnter={() => setActiveIndex(index)}
                onClick={() => openProject(project._id)}
                data-testid={`search-project-${project._id}`}
                className={`workspace-search-result${index === activeIndex ? " is-active" : ""}`}
              >
                <div className="workspace-search-icon" style={{ "--project-color": project.color || WORKSPACE_BRAND_COLOR }}><ProjectIcon name={project.icon} /></div>
                <div className="workspace-search-copy"><strong dir="auto">{highlight(project.name, debouncedQuery)}</strong>{project.description && <span dir="auto">{highlight(project.description, debouncedQuery)}</span>}</div>
                <ArrowUpRight aria-hidden="true" />
              </button>;
            })}
          </Section>}

          {results.conversations.length > 0 && <Section title={t("المحادثات")} icon={MessageSquare} count={results.conversations.length}>
            {results.conversations.map((conversation) => {
              const index = items.findIndex((entry) => entry.type === "conversation" && entry.item._id === conversation._id);
              return <button
                type="button"
                key={conversation._id}
                role="option"
                aria-selected={index === activeIndex}
                onMouseEnter={() => setActiveIndex(index)}
                onClick={() => openConversation(conversation)}
                data-testid={`search-conv-${conversation._id}`}
                className={`workspace-search-result${index === activeIndex ? " is-active" : ""}`}
              >
                <MessageSquare aria-hidden="true" className="workspace-result-muted-icon" />
                <div className="workspace-search-copy"><strong dir="auto">{highlight(conversation.title, debouncedQuery)}</strong><span>{t("في {project}", { project: projectName(conversation.project_id) })}</span></div>
                <ArrowUpRight aria-hidden="true" />
              </button>;
            })}
          </Section>}

          {results.messages.length > 0 && <Section title={t("الرسائل")} icon={Sparkles} count={results.messages.length}>
            {results.messages.map((message) => {
              const index = items.findIndex((entry) => entry.type === "message" && entry.item._id === message._id);
              return <button
                type="button"
                key={message._id}
                role="option"
                aria-selected={index === activeIndex}
                onMouseEnter={() => setActiveIndex(index)}
                onClick={() => openConversation(message)}
                data-testid={`search-msg-${message._id}`}
                className={`workspace-search-result workspace-message-result${index === activeIndex ? " is-active" : ""}`}
              >
                <Sparkles aria-hidden="true" className="workspace-result-muted-icon" />
                <div className="workspace-search-copy"><small dir="ltr">{message.role || "message"}</small><span dir="auto">{highlight(message.snippet || message.content?.slice(0, 240), debouncedQuery)}</span></div>
                <ArrowUpRight aria-hidden="true" />
              </button>;
            })}
          </Section>}

          {results.files.length > 0 && <Section title={t("الملفات")} icon={FileText} count={results.files.length}>
            {results.files.map((file) => <div key={file._id} data-testid={`search-file-${file._id}`} className="workspace-search-result workspace-file-result">
              <FileText aria-hidden="true" className="workspace-result-muted-icon" />
              <div className="workspace-search-copy"><strong dir="auto">{highlight(file.name, debouncedQuery)}</strong><span>{t("في {project}", { project: projectName(file.project_id) })}</span></div>
            </div>)}
          </Section>}
        </div>
        <p className="workspace-shortcuts"><kbd>↑</kbd><kbd>↓</kbd> {t("للتنقل")} <kbd>Enter</kbd> {t("فتح النتيجة")} <kbd>Esc</kbd> {t("للإغلاق")}</p>
      </DialogContent>
    </Dialog>
  );
}

function Section({ title, icon: Icon, count, children }) {
  const { formatNumber } = useI18n("workspace");
  return <section className="workspace-search-section">
    <h3><Icon aria-hidden="true" /> {title} <span>({formatNumber(count)})</span></h3>
    <div>{children}</div>
  </section>;
}
