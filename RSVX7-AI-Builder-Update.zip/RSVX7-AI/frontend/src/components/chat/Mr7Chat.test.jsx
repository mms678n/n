import React, { act } from "react";
import { createRoot } from "react-dom/client";
import WelcomeState from "./WelcomeState";
import ChatInput from "./ChatInput";
import { setLanguage } from "@/i18n";

const mockSend = jest.fn(() => true);
const mockChat = { sendMessage: mockSend, isStreaming: false, messagesLoading: false, saveErrors: [], retrySave: jest.fn(), stop: jest.fn(), prefs: {}, setModel: jest.fn(), activeChat: null, reasoningSupported: false, reasoningMandatory: false, setDeepThink: jest.fn(), webSearchSupported: false, setWebSearch: jest.fn() };
jest.mock("@/context/ChatContext", () => ({ useChat: () => mockChat }));
jest.mock("@/context/SubscriptionContext", () => ({ useSubscription: () => ({ openRenewalModal: jest.fn() }) }));
jest.mock("@/lib/aiClient", () => ({ processFile: jest.fn() }));
jest.mock("@/components/chat/FileChip", () => () => null);
jest.mock("@/components/design/Primitives", () => ({ Panel: ({ children, ...props }) => <div {...props}>{children}</div>, StatusNote: ({ children }) => <div>{children}</div> }));
jest.mock("@/components/ui/tooltip", () => ({ TooltipProvider: ({ children }) => <>{children}</>, Tooltip: ({ children }) => <>{children}</>, TooltipTrigger: ({ children }) => <>{children}</>, TooltipContent: () => null }));
jest.mock("@/components/ui/dropdown-menu", () => { const Wrap = ({ children }) => <div>{children}</div>; const Item = ({ children, onClick, ...props }) => <button onClick={onClick} {...props}>{children}</button>; return { DropdownMenu: Wrap, DropdownMenuTrigger: Wrap, DropdownMenuContent: Wrap, DropdownMenuItem: Item, DropdownMenuSeparator: () => null, DropdownMenuSub: Wrap, DropdownMenuSubTrigger: Item, DropdownMenuSubContent: Wrap }; });

let root;
let node;
beforeEach(() => { global.IS_REACT_ACT_ENVIRONMENT = true; setLanguage("en"); node = document.createElement("div"); document.body.appendChild(node); root = createRoot(node); mockSend.mockClear(); });
afterEach(async () => { await act(async () => root.unmount()); node.remove(); setLanguage("ar"); });

test("MR7 welcome exposes chat mode and clear unavailable modes", async () => {
  await act(async () => root.render(<WelcomeState />));
  expect(node.querySelector('[data-testid="welcome-heading"]').textContent).toBe("What can I hack today?");
  expect(node.querySelectorAll(".chat-mode-tab")).toHaveLength(3);
  expect(node.querySelectorAll(".chat-mode-tab:disabled")).toHaveLength(2);
  expect(node.querySelectorAll(".chat-suggestion-chip")).toHaveLength(4);
});

test("MR7 suggestion fills the same composer without sending", async () => {
  let suggestion;
  await act(async () => root.render(<><WelcomeState onSuggestedPrompt={(value) => { suggestion = value; }} /><ChatInput suggestion={suggestion} /></>));
  await act(async () => node.querySelector(".chat-suggestion-chip").click());
  await act(async () => root.render(<ChatInput suggestion={suggestion} />));
  expect(node.querySelector('[data-testid="chat-input"]').value).toBe("Pentest methodology");
  expect(mockSend).not.toHaveBeenCalled();
});

test("MR7 keeps Hermes DeepThink and web search disabled without backend claims", async () => {
  await act(async () => root.render(<ChatInput />));
  expect(node.querySelector('[data-testid="deepthink-btn"]').disabled).toBe(true);
  expect(node.querySelector('[data-testid="web-search-btn"]').disabled).toBe(true);
});
