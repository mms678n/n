export const LANGUAGE_KEY = "rsvx7_language";
export const SUPPORTED_LANGUAGES = ["ar", "en"];
const catalogs = new Map();
const reverseCatalogs = new Map();
const listeners = new Set();
function readPreference() {
  try { const saved = localStorage.getItem(LANGUAGE_KEY); return SUPPORTED_LANGUAGES.includes(saved) ? saved : "ar"; }
  catch { return "ar"; }
}
let language = readPreference();
export const getLanguage = () => language;
export const getDirection = () => language === "en" ? "ltr" : "rtl";
export const getLocale = () => language === "en" ? "en-US" : "ar";
export function subscribeLanguage(listener) { listeners.add(listener); return () => listeners.delete(listener); }
export function setLanguage(next) {
  if (!SUPPORTED_LANGUAGES.includes(next)) return;
  try { localStorage.setItem(LANGUAGE_KEY, next); } catch { /* Private browsing still allows session switching. */ }
  if (next === language) return;
  language = next;
  listeners.forEach((listener) => listener());
}
if (typeof window !== "undefined") {
  window.addEventListener("storage", (event) => {
    if (event.key !== LANGUAGE_KEY) return;
    const next = SUPPORTED_LANGUAGES.includes(event.newValue) ? event.newValue : "ar";
    if (language !== next) { language = next; listeners.forEach((listener) => listener()); }
  });
}
export function registerTranslations(namespace, entries) {
  if (!namespace || !entries || typeof entries !== "object") return;
  const merged = { ...(catalogs.get(namespace) || {}), ...entries };
  catalogs.set(namespace, merged);
  reverseCatalogs.set(namespace, new Map(Object.entries(merged).map(([source, english]) => [english, source])));
}
export function translate(source, variables = {}, namespace = "common", selected = language) {
  if (typeof source !== "string") return source;
  const dictionary = catalogs.get(namespace) || {};
  const common = catalogs.get("common") || {};
  const ordered = [dictionary, common, ...catalogs.values()];
  let result = source;
  if (selected === "en") {
    result = ordered.find((catalog) => Object.prototype.hasOwnProperty.call(catalog, source))?.[source] || source;
  } else if (!/[\u0600-\u06ff]/.test(source)) {
    // Only explicit t() calls for interface text reach this lookup; message bodies never do.
    for (const catalog of [reverseCatalogs.get(namespace), reverseCatalogs.get("common"), ...reverseCatalogs.values()]) {
      const original = catalog?.get(source);
      if (original) { result = original; break; }
    }
  }
  return result.replace(/\{([A-Za-z0-9_]+)\}/g, (match, key) =>
    variables != null && Object.prototype.hasOwnProperty.call(variables, key) ? String(variables[key]) : match);
}
export const t = (source, variables, namespace = "common") => translate(source, variables, namespace);
export function formatNumber(value, options) {
  if (value === Infinity || value === "∞") return "∞";
  if (value == null || value === "") return "—";
  const numeric = Number(value);
  return Number.isFinite(numeric) ? new Intl.NumberFormat(getLocale(), options).format(numeric) : String(value);
}
export function formatDate(value, options = {}) {
  if (!value) return "—";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat(getLocale(), Object.keys(options).length ? options : { dateStyle: "medium" }).format(date);
}
