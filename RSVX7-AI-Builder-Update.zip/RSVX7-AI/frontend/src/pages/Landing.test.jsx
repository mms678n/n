import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Landing from "./Landing";
import { setLanguage } from "@/i18n";

let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  setLanguage("ar");
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

function renderLanding(props = {}) {
  return act(async () => root.render(<Landing {...props} />));
}

test("renders the Arabic public home with rsvx7 branding and two-line hero", async () => {
  await renderLanding();

  expect(container.querySelector('[data-testid="landing-page"]').getAttribute("dir")).toBe("rtl");
  expect(container.querySelector(".landing-brand").textContent).toContain("rsvx7");
  expect(container.querySelector(".landing-hero-title").children).toHaveLength(2);
  expect(container.querySelector("#features")).not.toBeNull();
  expect(container.querySelector("#projects")).not.toBeNull();
  expect(container.querySelector("#faq")).not.toBeNull();
  expect(container.textContent).toContain("نماذج قابلة للاختيار");
  expect(container.querySelector("#pricing")).not.toBeNull();
  expect(container.textContent).not.toContain("50K");
  expect(container.textContent).not.toContain("10,000");
});

test("routes CTA actions through callbacks instead of MR7 links", async () => {
  const onSignIn = jest.fn();
  const onRegister = jest.fn();
  const onChat = jest.fn();
  await renderLanding({ onSignIn, onRegister, onChat });

  await act(async () => container.querySelector('[data-testid="landing-sign-in"]').click());
  await act(async () => container.querySelector('[data-testid="landing-hero-register"]').click());
  await act(async () => container.querySelector('[data-testid="landing-hero-chat"]').click());

  expect(onSignIn).toHaveBeenCalledTimes(1);
  expect(onRegister).toHaveBeenCalledTimes(1);
  expect(onChat).toHaveBeenCalledTimes(1);
  expect(container.querySelectorAll('a[href^="https://"]').length).toBe(0);
});

test("mobile menu is keyboard-dismissible and FAQ uses disclosure semantics", async () => {
  await renderLanding();
  const menuButton = container.querySelector('[data-testid="landing-mobile-menu-button"]');

  await act(async () => menuButton.click());
  expect(menuButton.getAttribute("aria-expanded")).toBe("true");
  expect(container.querySelector('[data-testid="landing-mobile-menu"]')).not.toBeNull();

  await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" })));
  expect(menuButton.getAttribute("aria-expanded")).toBe("false");
  expect(container.querySelector('[data-testid="landing-mobile-menu"]')).toBeNull();

  const disclosure = container.querySelector(".landing-faq-item");
  expect(disclosure.querySelector("summary")).not.toBeNull();
  await act(async () => disclosure.querySelector("summary").click());
  expect(disclosure.open).toBe(true);
});

test("language switcher changes the home copy and direction", async () => {
  await renderLanding();
  const select = container.querySelector('[data-testid="language-switcher"]');
  const valueSetter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value").set;

  await act(async () => {
    valueSetter.call(select, "en");
    select.dispatchEvent(new Event("change", { bubbles: true }));
  });

  expect(container.querySelector('[data-testid="landing-page"]').getAttribute("dir")).toBe("ltr");
  expect(container.querySelector(".landing-hero-title").textContent).toContain("Powerful AI for");
  expect(container.querySelector('[data-testid="landing-sign-in"]').textContent).toContain("Sign in");
});
