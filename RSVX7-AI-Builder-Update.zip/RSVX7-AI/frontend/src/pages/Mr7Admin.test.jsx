import fs from "fs";
import path from "path";

const read = (file) => fs.readFileSync(path.join(__dirname, file), "utf8");

test("admin surfaces use the MR7 compact black/red geometry", () => {
  const css = read("admin-ui.css");

  expect(css).toContain("ui-sans-serif, system-ui, sans-serif");
  expect(css).toContain("--admin-primary: var(--primary");
  expect(css).toContain("border-radius: 8px");
  expect(css).toContain("min-height: 40px");
  expect(css).toContain(".admin-page .admin-tab");
  expect(css).toContain("border-radius: 6px");
  expect(css).not.toContain("border-radius: 999px");
  expect(css).not.toMatch(/DeepSeek-style pill/);
});

test("admin detail stylesheet keeps cards rectangular and compact", () => {
  const css = read("admin-details.css");

  expect(css).toContain(".admin-detail-card");
  expect(css).toContain("border-radius: 8px");
  expect(css).not.toContain("border-radius: 999px");
});
