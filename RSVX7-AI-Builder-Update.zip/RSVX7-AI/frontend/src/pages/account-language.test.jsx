import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Dashboard from "./Dashboard";
import SettingsDialog from "@/components/chat/SettingsDialog";
import { setLanguage } from "@/i18n";

const mockAuthFetch = jest.fn();
const mockLogout = jest.fn();
const mockRefresh = jest.fn().mockResolvedValue({});
const mockActivateSession = jest.fn().mockResolvedValue({});
const mockDeleteChat = jest.fn().mockResolvedValue(true);
const mockSetPrefs = jest.fn();
const mockBalanceRefresh = jest.fn();
const mockUser = {
  _id: "account-language-user",
  username: "demo-user",
  plan: "wallet",
  status: "active",
  token_balance: 4200,
  total_used_tokens: 1800,
  total_input_tokens: 1000,
  total_output_tokens: 800,
  telegram: { verified: true },
};

jest.mock("@/context/AuthContext", () => ({
  useAuth: () => ({
    user: mockUser,
    authFetch: mockAuthFetch,
    logout: mockLogout,
    refresh: mockRefresh,
    activateSession: mockActivateSession,
  }),
}));
jest.mock("@/context/TokensContext", () => ({ useTokens: () => ({ refresh: mockBalanceRefresh }) }));
jest.mock("@/context/ChatContext", () => ({
  useChat: () => ({
    chats: [{ id: "chat-1" }],
    deleteChat: mockDeleteChat,
    prefs: { autoSuffix: { enabled: false, text: "Suffix" } },
    setPrefs: mockSetPrefs,
  }),
}));
jest.mock("@/components/chat/Logo", () => () => <span aria-hidden="true">logo</span>);
jest.mock("@/lib/clipboard", () => ({ copyToClipboard: jest.fn().mockResolvedValue(undefined) }));
jest.mock("@/components/design/Primitives", () => {
  const React = require("react");
  return {
    ActionButton: ({ children, loading, disabled, ...props }) => <button {...props} disabled={disabled || loading}>{children}</button>,
    EmptyState: ({ title, description }) => <div><h3>{title}</h3><p>{description}</p></div>,
    LoadingState: ({ label }) => <div role="status">{label}</div>,
    MetricCard: ({ label, value, detail }) => <section><span>{label}</span><strong>{value}</strong><small>{detail}</small></section>,
    PageShell: ({ children, ...props }) => <main {...props}>{children}</main>,
    Panel: ({ children, ...props }) => <section {...props}>{children}</section>,
    StatusNote: ({ children, onRetry, ...props }) => <div {...props} role={props.tone === "error" ? "alert" : "status"}>{children}{onRetry && <button onClick={onRetry}>retry</button>}</div>,
  };
});
jest.mock("@/components/ui/dialog", () => {
  const Element = ({ children, ...props }) => require("react").createElement("div", props, children);
  return { Dialog: Element, DialogContent: Element, DialogHeader: Element, DialogTitle: Element, DialogDescription: Element, DialogFooter: Element };
});
jest.mock("@/components/ui/button", () => ({ Button: ({ variant, ...props }) => require("react").createElement("button", props) }));
jest.mock("@/components/ui/input", () => ({ Input: (props) => require("react").createElement("input", props) }));
jest.mock("@/components/ui/textarea", () => ({ Textarea: (props) => require("react").createElement("textarea", props) }));
jest.mock("@/components/ui/label", () => ({ Label: (props) => require("react").createElement("label", props) }));
jest.mock("@/components/ui/switch", () => ({ Switch: ({ checked, onCheckedChange, ...props }) => require("react").createElement("input", { ...props, type: "checkbox", checked, onChange: (event) => onCheckedChange(event.target.checked) }) }));
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));

const reply = (json, ok = true) => ({ ok, status: ok ? 200 : 400, json: async () => json });
let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.clear();
  setLanguage("en");
  mockAuthFetch.mockReset();
  mockLogout.mockReset();
  mockRefresh.mockClear();
  mockActivateSession.mockClear();
  mockDeleteChat.mockClear().mockResolvedValue(true);
  mockSetPrefs.mockClear();
  mockBalanceRefresh.mockClear();
  global.fetch = jest.fn().mockResolvedValue(reply({ packs: [] }));
  mockAuthFetch.mockImplementation((path) => {
    if (path === "/billing/balance") return Promise.resolve(reply({ ...mockUser, unlimited: false }));
    if (path === "/referrals/me") return Promise.resolve(reply({ code: "AB12CD34", invitee_bonus: 2500, referrer_bonus: 10000, referral_count: 2, referral_tokens_earned: 20000, was_referred: false, reward_pending: false }));
    return Promise.resolve(reply({}));
  });
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  setLanguage("ar");
  localStorage.clear();
  jest.restoreAllMocks();
});

test("renders Dashboard in English with localized numbers and a switchable direction", async () => {
  await act(async () => root.render(<Dashboard onExit={mockLogout} />));
  expect(container.querySelector(".dashboard-ui").getAttribute("dir")).toBe("ltr");
  expect(container.textContent).toContain("Manage your account");
  expect(container.textContent).toContain("4,200");
  const switcher = container.querySelector('[data-testid="language-switcher"]');
  expect(switcher.value).toBe("en");
  await act(async () => {
    switcher.value = "ar";
    switcher.dispatchEvent(new Event("change", { bubbles: true }));
  });
  expect(container.querySelector(".dashboard-ui").getAttribute("dir")).toBe("rtl");
  expect(localStorage.getItem("rsvx7_language")).toBe("ar");
});

test("renders the Settings language field in English and preserves editable controls", async () => {
  await act(async () => root.render(<SettingsDialog open onOpenChange={() => {}} />));
  expect(container.querySelector('[data-testid="settings-dialog"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="language-field"]').textContent).toContain("Choose the account interface language.");
  expect(container.querySelector('[data-testid="settings-body"]').getAttribute("dir")).toBe("ltr");
  expect(container.querySelector('[data-testid="auto-suffix-text"]').value).toBe("Suffix");
  expect(container.querySelector('[data-testid="language-switcher"]').value).toBe("en");
});
