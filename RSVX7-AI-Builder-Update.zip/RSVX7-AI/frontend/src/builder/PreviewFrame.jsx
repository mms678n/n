import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { readPreviewHealth } from './generated-runtime';

export default function PreviewFrame({ state, runtime, verification = false, title = 'المعاينة' }) {
  const frame = useRef(null);
  useEffect(() => {
    const receive = event => {
      const health = readPreviewHealth(event, frame.current, state.previewUrl);
      if (!health || health.run !== state.previewRun) return;
      // The visible frame can be inside an inactive tab with no layout. Only
      // the dedicated verification frame decides whether the page is empty.
      if (!verification && health.reason !== 'runtime') return;
      const detail = health.reason === 'runtime' ? 'DF_PREVIEW_RUNTIME: ' + health.error : health.error;
      if (state.phase === 'starting') {
        runtime?.confirmPreview(state.previewRun, state.previewPort, health.ok, detail);
      } else if (!health.ok && state.phase === 'ready') {
        runtime?.reportPreviewError(state.previewPort, detail || 'DF_PREVIEW_RENDER: The preview became empty.', state.previewRun);
      }
    };
    window.addEventListener('message', receive);
    return () => window.removeEventListener('message', receive);
  }, [runtime, state.previewUrl, state.previewRun, state.previewPort, state.phase, verification]);
  if (!state.previewUrl || (verification && state.phase !== 'starting')) return null;
  const content = <iframe
    key={`${state.previewRun}:${state.previewPort}`} ref={frame} src={state.previewUrl} title={verification ? 'فحص عرض المشروع' : title}
    aria-hidden={verification || undefined} tabIndex={verification ? -1 : undefined}
    sandbox={verification ? 'allow-scripts allow-forms allow-same-origin' : 'allow-scripts allow-forms allow-same-origin allow-modals allow-downloads'}
    allow="cross-origin-isolated"
    style={verification ? { position: 'fixed', left: '-12000px', top: 0, width: 1024, height: 768, border: 0, opacity: 0, pointerEvents: 'none' } : undefined}
  />;
  return verification ? createPortal(content, document.body) : content;
}
