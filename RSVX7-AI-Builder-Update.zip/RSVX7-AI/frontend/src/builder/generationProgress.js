// Server counts describe generated source, never successful runtime checks.
export function generationProgress(build, job, revision) {
  const progress = job?.pipeline;
  const phase = {structure:'structuring',writing:'writing',reviewing:'reviewing'}[progress?.stage];
  const pipeline = phase && Number.isSafeInteger(progress.completed) && Number.isSafeInteger(progress.total)
    && progress.completed >= 0 && progress.completed <= progress.total && progress.total <= 1500 ? progress : undefined;
  if (job?.status !== 'running' || job.mode !== 'build') {
    return job?.status === 'completed' && job.mode === 'build' && job.revision + 1 === revision && pipeline
      ? {...build,pipeline} : build;
  }
  const call = job.modelCall || {};
  const count = value => Number.isSafeInteger(value) && value >= 0 ? value : 0;
  const started = Date.parse(job.startedAt);
  return {
    ...build,
    phase: pipeline ? phase : job.request?.action === 'repair' ? 'repairing' : 'writing',
    pipeline,
    startedAt: Number.isFinite(started) ? started : build.startedAt,
    finishedAt: undefined,
    files: count(job.generation?.files),
    generation: {
      phase: call.phase || 'waiting_provider',
      chars: count(call.chars), reasoningChars: count(call.reasoningChars),
      calls: count(call.number), batches: count(job.generation?.batches),
      updatedAt: call.updatedAt,
    },
  };
}
