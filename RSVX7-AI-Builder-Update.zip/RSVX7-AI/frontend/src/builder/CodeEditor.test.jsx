import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import CodeEditor from './CodeEditor';

let node, root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  global.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
  node = document.createElement('div');
  document.body.appendChild(node);
  root = createRoot(node);
});
afterEach(async () => {
  await act(async () => root.unmount());
  node.remove();
});

test.each([
  ['index.html', '<h1>Generated project</h1>'],
  ['src/App.jsx', 'export default function App() { return <h1>Generated project</h1>; }'],
  ['style.css', 'body { color: crimson; }'],
  ['package.json', '{"name":"generated-project"}'],
])('generated %s opens in the real editor without crashing the page', async (path, source) => {
  // Builder mounts this pane even while its chat tab is selected. Do not mock
  // CodeMirror: mixing its state/view instances must fail this regression.
  await act(async () => root.render(<CodeEditor path={path} value={source} onChange={() => {}} disabled={false} />));
  expect(node.querySelector('.cm-content').textContent).toBe(source);
});
