import { ProjectRuntime, readPreviewHealth } from './generated-runtime';

// A single SDK container at a time. A different account/project always tears
// the previous container down before mounting source into the next one.
let previousCleanup = Promise.resolve();
export function createRuntime(onState, onRepair) {
  let wc, booting, boot, closed = false, sequence = 0, applying = Promise.resolve();
  const container = { then(resolve, reject) { return boot().then(resolve, reject); } };
  const runtime = new ProjectRuntime(container, undefined, true, async signal => {
    const response = await fetch('/internal/project-verifier.js', { signal, cache: 'no-cache' });
    if (!response.ok) throw Error('تعذّر تحميل أدوات الفحص. أعد المحاولة.');
    return response.text();
  });
  const stateOff = runtime.state.listen(onState);
  const repairOff = runtime.repairRequest.listen(request => { if (request) onRepair(request); });
  const known = new Set();
  boot = () => booting ||= (async () => {
    try {
      await previousCleanup;
      if (!window.crossOriginIsolated) throw Error('التشغيل يحتاج HTTPS ومتصفحًا يدعم بيئة المعاينة المعزولة. يمكنك تنزيل الملفات.');
      const { WebContainer } = await import('@webcontainer/api');
      wc = await WebContainer.boot({ coep: 'credentialless', workdirName: 'project' });
      if (closed) { wc.teardown(); throw Error('Workspace closed'); }
      return wc;
    } catch (error) { booting = undefined; throw error; }
  })();
  return {
    runtime,
    async apply(files, repair = false, repairState) {
      const attempt = ++sequence;
      const preceding = applying;
      let release;
      applying = new Promise(resolve => { release = resolve; });
      runtime.stop();
      if (repairState !== undefined) runtime.restoreRepairState(repairState);
      runtime.beginTask(true, repair);
      try {
        await preceding;
        if (closed || attempt !== sequence) return;
        const target = await boot();
        if (closed || attempt !== sequence) return;
        runtime.beginFileChanges();
        const next = new Set(Object.keys(files).map(p => p.replace('/home/project/', '')));
        for (const name of known) if (!next.has(name)) {
          await target.fs.rm(name, { force: true });
          known.delete(name);
        }
        for (const [path, file] of Object.entries(files)) {
          if (closed || attempt !== sequence) return;
          const name = path.replace('/home/project/', '');
          const folder = name.split('/').slice(0, -1).join('/');
          if (folder) await target.fs.mkdir(folder, { recursive: true });
          const content = file.isBinary ? Uint8Array.from(atob(file.content), c => c.charCodeAt(0)) : file.content;
          await target.fs.writeFile(name, content);
          known.add(name);
          if (closed || attempt !== sequence) return;
          runtime.fileWritten(name);
        }
        if (!closed && attempt === sequence) await runtime.verify();
      } catch (error) { if (!closed && attempt === sequence) runtime.pause(error.message); }
      finally { release(); }
    },
    stop() { sequence++; runtime.stop(); },
    dispose() {
      closed = true; sequence++; stateOff(); repairOff(); runtime.stop();
      previousCleanup = (booting || Promise.resolve()).catch(() => {}).then(() => { wc?.teardown(); });
    },
  };
}
export { readPreviewHealth };
