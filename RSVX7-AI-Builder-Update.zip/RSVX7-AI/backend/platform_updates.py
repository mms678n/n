"""Owner can request a fixed host-side update; no shell or repository input."""
import json
import os
import time
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException
from auth import require_super_admin

router = APIRouter(prefix='/api/admin/platform-update', tags=['Platform updates'])
CONTROL = Path('/app/update-control')

def state():
    try:
        value = json.loads((CONTROL / 'status.json').read_text())
        result = {k: value.get(k) for k in ('status', 'stage', 'repository', 'branch', 'commit', 'updated_at')}
        result['configured'] = True
        try:
            result['online'] = time.time() - (CONTROL / 'heartbeat').stat().st_mtime < 30
        except OSError:
            result['online'] = False
        if not result['online']:
            result.update(status='offline', stage='offline')
            return result
        if (CONTROL / 'requests' / 'update').exists() and result['status'] != 'running':
            result.update(status='pending', stage='queued')
        return result
    except (OSError, ValueError):
        return {'configured': False, 'status': 'unavailable'}

@router.get('')
async def get_status(_=Depends(require_super_admin)):
    return state()

@router.post('', status_code=202)
async def request_update(_=Depends(require_super_admin)):
    current = state()
    if not current['configured']:
        raise HTTPException(409, 'اربط GitHub على السيرفر أولًا حسب OPERATIONS.txt.')
    if not current.get('online'):
        raise HTTPException(503, 'خدمة التحديث متوقفة. شغّل rsvx7-updater على السيرفر.')
    if current['status'] in ('running', 'pending'):
        raise HTTPException(409, 'يوجد تحديث قيد التنفيذ.')
    try:
        fd = os.open(CONTROL / 'requests' / 'update', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(fd)
    except FileExistsError:
        raise HTTPException(409, 'يوجد تحديث بانتظار التنفيذ.')
    except OSError:
        raise HTTPException(503, 'خدمة التحديث غير جاهزة على السيرفر.')
    return state()
