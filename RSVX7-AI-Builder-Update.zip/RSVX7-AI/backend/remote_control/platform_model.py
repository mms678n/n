"""Remote AI uses the existing model assignment, key selection, wallet and leases."""
import uuid
from types import SimpleNamespace
from fastapi import HTTPException
import anyio
import ai_settings
from auth import db
from tokens import estimate_messages_tokens, check_can_afford, charge_user, max_completion_for_balance
from tg_verify import require_membership
from .auth_bridge import actor

def cached_prompt_tokens(usage):
    """Use the same provider cache fields as native chat and Builder."""
    details = getattr(usage, 'prompt_tokens_details', None)
    return int(getattr(details, 'cached_tokens', 0) or getattr(usage, 'prompt_cache_hit_tokens', 0) or 0)

class PlatformClient:
    def __init__(self): self.chat = SimpleNamespace(completions=self)
    async def protocol_key(self):
        settings = await ai_settings.current_settings('deepdark')
        provider = ai_settings.request_client(ai_settings.client)
        return (settings['model'], str(getattr(provider, 'base_url', '')))
    async def create(self, **kwargs):
        identity = actor.get()
        if not identity: raise HTTPException(401, 'Remote AI requires an authenticated platform session')
        user = await db.users.find_one({'_id': identity['_id']})
        if not user or user.get('status') == 'suspended' or int(user.get('session_version',0)) != int(identity.get('session_version',0)):
            raise HTTPException(403, 'Platform session ended')
        from memberships import refresh, require_access
        user = await refresh(user, db, grant_missing=False)
        require_access(user, feature="hacker")
        await require_membership(user)
        settings = await ai_settings.current_settings('deepdark')
        client = ai_settings.request_client(ai_settings.client)
        if client is None: raise HTTPException(503, 'اتصال نموذج المنصة غير مهيأ.')
        messages = kwargs['messages']
        prompt = estimate_messages_tokens(messages)
        exempt = user.get('role') in ('super_admin','admin','moderator','support')
        cap = min(int(settings['max_completion_tokens']), int(settings['context_length']) - prompt - 256)
        budget = prompt if exempt else int(prompt*1.15)+64
        if not exempt: cap = min(cap,max_completion_for_balance(int(user.get('token_balance') or 0),budget))
        if cap < 1: raise HTTPException(402, 'رصيد أو سياق النموذج غير كافٍ.')
        await check_can_afford(user,budget+cap)
        lease = await ai_settings.claim_generation(user['_id'])
        streaming = bool(kwargs.get('stream'))
        kwargs.update(model=settings['model'],max_tokens=cap)
        if streaming: kwargs['stream_options'] = {'include_usage': True}
        try:
            result = await client.chat.completions.create(**kwargs)
            if streaming:
                return PlatformStream(result, user, settings, messages, prompt, exempt, lease)
            usage = result.usage
            completion = ''.join((choice.message.content or '') + str(getattr(choice.message,'tool_calls',None) or '') for choice in result.choices)
            await charge_user(user['_id'],prompt_tokens=getattr(usage,'prompt_tokens',prompt) if usage else prompt,
                completion_tokens=getattr(usage,'completion_tokens',0) if usage else estimate_messages_tokens([{'role':'assistant','content':completion}]),
                cached_tokens=cached_prompt_tokens(usage),
                user_input_tokens=max(1,estimate_messages_tokens([messages[-1]])-12),model=settings['model'],
                conversation_id='remote-control',role_exempt=exempt,idempotency_key='remote:'+uuid.uuid4().hex)
            return result
        finally:
            with anyio.CancelScope(shield=True):
                if not streaming or 'result' not in locals(): await ai_settings.release_generation(user['_id'],lease)

client = PlatformClient()

class PlatformStream:
    def __init__(self, stream, user, settings, messages, prompt, exempt, lease):
        self.stream,self.user,self.settings,self.messages=stream,user,settings,messages
        self.prompt,self.exempt,self.lease=prompt,exempt,lease
        self.closed=False
    def __aiter__(self): return self.events()
    async def events(self):
        usage=None; text=[]; finish=None
        try:
            async for chunk in self.stream:
                if getattr(chunk,'error',None): raise RuntimeError('تعذر إكمال بث المزود.')
                if getattr(chunk,'usage',None): usage=chunk.usage
                if chunk.choices:
                    choice=chunk.choices[0]
                    content=getattr(choice.delta,'content',None)
                    reason=choice.finish_reason
                    if finish and (content or (reason and reason != finish)):
                        raise RuntimeError('وصلت بيانات متعارضة بعد نهاية بث المزود.')
                    if content: text.append(content)
                    finish=reason or finish
                    if finish and finish not in ('stop','length'):
                        raise RuntimeError('تعذر إكمال بث المزود.')
                yield chunk
            if finish not in ('stop','length'): raise RuntimeError('انقطع بث المزود قبل اكتماله.')
            await charge_user(self.user['_id'],prompt_tokens=usage.prompt_tokens if usage else self.prompt,
                completion_tokens=usage.completion_tokens if usage else estimate_messages_tokens([{'role':'assistant','content':''.join(text)}]),
                cached_tokens=cached_prompt_tokens(usage),
                user_input_tokens=max(1,estimate_messages_tokens([self.messages[-1]])-12),model=self.settings['model'],
                conversation_id='remote-control',role_exempt=self.exempt,idempotency_key='remote:'+uuid.uuid4().hex)
        finally: await self.close()
    async def close(self):
        if self.closed:return
        self.closed=True
        with anyio.CancelScope(shield=True):
            from provider_cleanup import close_provider_stream
            try: await close_provider_stream(self.stream)
            finally: await ai_settings.release_generation(self.user['_id'],self.lease)
