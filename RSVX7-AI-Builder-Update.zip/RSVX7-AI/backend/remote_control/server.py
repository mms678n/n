import asyncio
import io
import json
import logging
import os
import re
import secrets
import tarfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).parent


from bson import ObjectId
from fastapi import (APIRouter, Depends, FastAPI, HTTPException, Query, Request,
                     UploadFile, File, WebSocket, WebSocketDisconnect)
from fastapi.responses import StreamingResponse, Response, RedirectResponse, FileResponse
from starlette.middleware.cors import CORSMiddleware

from . import ai_service
from .errors import public_error
from . import autonomous
from contextlib import suppress
from . import command_safety
from . import ssh_manager
from .store import RemoteDatabase
from .auth_bridge import get_current_user, ws_identity, hash_password, verify_password

from .crypto_utils import decrypt, encrypt
from .models import (ChatInput, DeviceIconInput, DeviceRegisterInput,
                    DeviceRenameInput, DeviceRotateInput, ExecInput, FileOpInput,
                    FileWriteInput, LoginInput, RegisterInput, ResetPasswordInput,
                    ServerInput, iso_now, utcnow)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("remotegpt")

db = RemoteDatabase()
client = db

app = FastAPI(title="Hacker rsvx7 Ai API")
api = APIRouter(prefix="/api")
# In-memory registry of connected agents: device_id -> websocket
connected_agents: dict = {}
# Frontend live-monitor watchers: device_id -> set of websockets
device_watchers: dict = {}
# User-level watchers receive a real-time device list snapshot.
user_device_watchers: dict = {}
# In-flight AI command executions: exec_id -> asyncio.Queue (agent -> exec ws relay)
device_exec_queues: dict = {}
device_exec_owners: dict = {}
# In-flight interactive terminals: shell_id -> asyncio.Queue (agent -> terminal ws relay)
device_shell_queues: dict = {}
device_shell_owners: dict = {}
AGENT_VERSION = "1.2.0"


# ---------------- helpers ----------------

def public_user(doc: dict) -> dict:
    return {
        "id": str(doc["_id"]),
        "username": doc["username"],
        "role": doc.get("role", "user"),
        "plan": doc.get("plan", "Free"),
        "created_at": doc.get("created_at"),
    }


def public_server(doc: dict) -> dict:
    return {
        "id": str(doc["_id"]),
        "nickname": doc["nickname"],
        "host": doc["host"],
        "port": doc.get("port", 22),
        "username": doc["username"],
        "os": doc.get("os", "Linux"),
        "has_password": bool(doc.get("password_enc")),
        "has_key": bool(doc.get("ssh_key_enc")),
        "status": doc.get("status", "unknown"),
        "info": doc.get("info"),
        "created_at": doc.get("created_at"),
    }


async def add_log(user_id: str, action: str, category: str, detail: str = "",
                  server_id: Optional[str] = None):
    await db.logs.insert_one({
        "user_id": str(user_id),
        "action": action,
        "category": category,
        "detail": detail,
        "server_id": server_id,
        "created_at": iso_now(),
    })


async def get_owned_server(server_id: str, user: dict) -> dict:
    try:
        oid = ObjectId(server_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Server not found")
    server = await db.servers.find_one({"_id": oid, "user_id": str(user["_id"])})
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    return server


@api.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return public_user(user)


# ---------------- servers ----------------

@api.get("/servers")
async def list_servers(user: dict = Depends(get_current_user)):
    docs = await db.servers.find({"user_id": str(user["_id"])}).sort("created_at", -1).to_list(200)
    return [public_server(d) for d in docs]


@api.post("/servers")
async def create_server(body: ServerInput, user: dict = Depends(get_current_user)):
    doc = {
        "user_id": str(user["_id"]),
        "nickname": body.nickname,
        "host": body.host,
        "port": body.port,
        "username": body.username,
        "password_enc": encrypt(body.password),
        "ssh_key_enc": encrypt(body.ssh_key),
        "os": body.os or "Linux",
        "status": "unknown",
        "info": None,
        "created_at": iso_now(),
    }
    result = await db.servers.insert_one(doc)
    doc["_id"] = result.inserted_id
    await add_log(user["_id"], f"Added server '{body.nickname}'", "server", server_id=str(result.inserted_id))
    return public_server(doc)


@api.put("/servers/{server_id}")
async def update_server(server_id: str, body: ServerInput, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    update = {
        "nickname": body.nickname,
        "host": body.host,
        "port": body.port,
        "username": body.username,
        "os": body.os or "Linux",
    }
    if body.password is not None:
        update["password_enc"] = encrypt(body.password)
    if body.ssh_key is not None:
        update["ssh_key_enc"] = encrypt(body.ssh_key)
    await db.servers.update_one({"_id": server["_id"]}, {"$set": update})
    doc = await db.servers.find_one({"_id": server["_id"]})
    return public_server(doc)


@api.delete("/servers/{server_id}")
async def delete_server(server_id: str, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    ssh_manager.close_client(str(server["_id"]))
    await db.servers.delete_one({"_id": server["_id"]})
    await add_log(user["_id"], f"Deleted server '{server['nickname']}'", "server")
    return {"message": "deleted"}


@api.post("/servers/{server_id}/test")
async def test_server(server_id: str, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    ok, msg = await asyncio.to_thread(ssh_manager.test_connection, server)
    await db.servers.update_one({"_id": server["_id"]}, {"$set": {"status": "online" if ok else "offline"}})
    await add_log(user["_id"], f"Tested '{server['nickname']}': {'OK' if ok else 'FAIL'}", "connection", detail=msg, server_id=server_id)
    return {"success": ok, "message": msg}


@api.post("/servers/{server_id}/connect")
async def connect_server(server_id: str, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        info = await asyncio.to_thread(ssh_manager.get_server_info, server)
    except Exception as e:
        await db.servers.update_one({"_id": server["_id"]}, {"$set": {"status": "offline"}})
        raise HTTPException(status_code=400, detail=f"Connection failed: {e}")
    await db.servers.update_one({"_id": server["_id"]}, {"$set": {"status": "online", "info": info}})
    await add_log(user["_id"], f"Connected to '{server['nickname']}'", "connection", server_id=server_id)
    return {"status": "online", "info": info}


@api.post("/servers/{server_id}/exec")
async def exec_command(server_id: str, body: ExecInput, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        result = await asyncio.to_thread(ssh_manager.run_command, server, body.command)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    await add_log(user["_id"], f"Executed: {body.command[:120]}", "command", detail=f"exit={result['exit_code']}", server_id=server_id)
    return result


@api.get("/servers/{server_id}/metrics")
async def server_metrics(server_id: str, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        return await asyncio.to_thread(ssh_manager.get_metrics, server)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ---------------- files ----------------

@api.get("/servers/{server_id}/files")
async def files_list(server_id: str, path: str = Query("."), user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        items = await asyncio.to_thread(ssh_manager.list_dir, server, path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"path": path, "items": items}


@api.get("/servers/{server_id}/files/read")
async def files_read(server_id: str, path: str = Query(...), user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        content = await asyncio.to_thread(ssh_manager.read_file, server, path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"path": path, "content": content}


@api.post("/servers/{server_id}/files/write")
async def files_write(server_id: str, body: FileWriteInput, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        await asyncio.to_thread(ssh_manager.write_file, server, body.path, body.content)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    await add_log(user["_id"], f"Edited file {body.path}", "file", server_id=server_id)
    return {"message": "saved"}


@api.post("/servers/{server_id}/files/mkdir")
async def files_mkdir(server_id: str, body: FileOpInput, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        await asyncio.to_thread(ssh_manager.make_dir, server, body.path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"message": "created"}


@api.post("/servers/{server_id}/files/delete")
async def files_delete(server_id: str, body: FileOpInput, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        await asyncio.to_thread(ssh_manager.delete_path, server, body.path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    await add_log(user["_id"], f"Deleted {body.path}", "file", server_id=server_id)
    return {"message": "deleted"}


@api.post("/servers/{server_id}/files/rename")
async def files_rename(server_id: str, body: FileOpInput, user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        await asyncio.to_thread(ssh_manager.rename_path, server, body.path, body.new_path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"message": "renamed"}


@api.post("/servers/{server_id}/files/upload")
async def files_upload(server_id: str, path: str = Query(...), file: UploadFile = File(...),
                       user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    data = await file.read()
    filename = (file.filename or "upload").replace("\\", "/").rsplit("/", 1)[-1]
    if filename in (".", "..", ""): raise HTTPException(400, "Invalid filename")
    target = f"{path.rstrip('/')}/{filename}"
    try:
        await asyncio.to_thread(ssh_manager.upload_bytes, server, target, data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    await add_log(user["_id"], f"Uploaded {file.filename}", "file", server_id=server_id)
    return {"message": "uploaded", "path": target}


@api.get("/servers/{server_id}/files/download")
async def files_download(server_id: str, path: str = Query(...), token: str = Query(None),
                         user: dict = Depends(get_current_user)):
    server = await get_owned_server(server_id, user)
    try:
        data = await asyncio.to_thread(ssh_manager.download_bytes, server, path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    fname = path.rstrip("/").split("/")[-1]
    return Response(content=data, media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{fname}"'})


# ---------------- docker ----------------

DOCKER_FORMATS = {
    "containers": ("docker ps -a --format '{{.ID}}|{{.Names}}|{{.Image}}|{{.Status}}|{{.State}}|{{.Ports}}'",
                   ["id", "name", "image", "status", "state", "ports"]),
    "images": ("docker images --format '{{.ID}}|{{.Repository}}|{{.Tag}}|{{.Size}}'",
               ["id", "repository", "tag", "size"]),
    "volumes": ("docker volume ls --format '{{.Name}}|{{.Driver}}'", ["name", "driver"]),
    "networks": ("docker network ls --format '{{.ID}}|{{.Name}}|{{.Driver}}|{{.Scope}}'",
                 ["id", "name", "driver", "scope"]),
}


@api.get("/servers/{server_id}/docker/{resource}")
async def docker_list(server_id: str, resource: str, user: dict = Depends(get_current_user)):
    if resource not in DOCKER_FORMATS:
        raise HTTPException(status_code=404, detail="Unknown resource")
    server = await get_owned_server(server_id, user)
    cmd, fields = DOCKER_FORMATS[resource]
    try:
        result = await asyncio.to_thread(ssh_manager.run_command, server, cmd)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    if result["exit_code"] != 0:
        return {"available": False, "error": result["stderr"].strip() or "Docker not available", "items": []}
    items = []
    for line in result["stdout"].strip().splitlines():
        cols = line.split("|")
        if len(cols) >= len(fields):
            items.append(dict(zip(fields, cols)))
    return {"available": True, "items": items}


@api.post("/servers/{server_id}/docker/container/{action}/{container_id}")
async def docker_action(server_id: str, action: str, container_id: str, user: dict = Depends(get_current_user)):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", container_id): raise HTTPException(400, "Invalid container ID")
    if action not in ("start", "stop", "restart", "remove"):
        raise HTTPException(status_code=400, detail="Invalid action")
    server = await get_owned_server(server_id, user)
    cmd = f"docker rm -f {container_id}" if action == "remove" else f"docker {action} {container_id}"
    result = await asyncio.to_thread(ssh_manager.run_command, server, cmd)
    await add_log(user["_id"], f"Docker {action} {container_id[:12]}", "docker", server_id=server_id)
    return {"success": result["exit_code"] == 0, "output": result["stdout"] + result["stderr"]}


@api.get("/servers/{server_id}/docker/logs/{container_id}")
async def docker_logs(server_id: str, container_id: str, user: dict = Depends(get_current_user)):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", container_id): raise HTTPException(400, "Invalid container ID")
    server = await get_owned_server(server_id, user)
    result = await asyncio.to_thread(ssh_manager.run_command, server, f"docker logs --tail 200 {container_id}")
    return {"logs": result["stdout"] + result["stderr"]}


# ---------------- logs ----------------

@api.get("/logs")
async def get_logs(category: Optional[str] = None, user: dict = Depends(get_current_user)):
    q = {"user_id": str(user["_id"])}
    if category:
        q["category"] = category
    docs = await db.logs.find(q).sort("created_at", -1).limit(300).to_list(300)
    return [{"id": str(d["_id"]), "action": d["action"], "category": d["category"],
             "detail": d.get("detail", ""), "created_at": d["created_at"]} for d in docs]


# ---------------- dashboard ----------------

@api.get("/dashboard/stats")
async def dashboard_stats(user: dict = Depends(get_current_user)):
    uid = str(user["_id"])
    total_servers = await db.servers.count_documents({"user_id": uid})
    online = await db.servers.count_documents({"user_id": uid, "status": "online"})
    commands = await db.logs.count_documents({"user_id": uid, "category": "command"})
    ai_msgs = await db.messages.count_documents({"user_id": uid, "role": "user"})
    recent = await db.logs.find({"user_id": uid}).sort("created_at", -1).limit(8).to_list(8)
    servers = await db.servers.find({"user_id": uid}).sort("created_at", -1).limit(6).to_list(6)
    return {
        "total_servers": total_servers,
        "online_servers": online,
        "commands_run": commands,
        "ai_messages": ai_msgs,
        "plan": user.get("plan", "Free"),
        "recent_activity": [{"action": r["action"], "category": r["category"], "created_at": r["created_at"]} for r in recent],
        "servers": [public_server(s) for s in servers],
    }


# ---------------- AI chat ----------------

@api.get("/ai/sessions")
async def list_sessions(server_id: Optional[str] = None, user: dict = Depends(get_current_user)):
    query = {"user_id": str(user["_id"]), "device_id": {"$exists": False}}
    if server_id:
        query["$or"] = [{"server_id": server_id}, {"server_id": None}]
    docs = await db.chat_sessions.find(query).sort("updated_at", -1).to_list(100)
    return [{"id": str(d["_id"]), "title": d.get("title", "New chat"), "updated_at": d.get("updated_at")} for d in docs]


@api.get("/ai/sessions/{session_id}/messages")
async def session_messages(session_id: str, user: dict = Depends(get_current_user)):
    docs = await db.messages.find({"session_id": session_id, "user_id": str(user["_id"])}).sort("created_at", 1).to_list(500)
    return [{"id": str(d["_id"]), "role": d["role"], "content": d["content"], "task": d.get("task"), "created_at": d["created_at"]} for d in docs]


@api.delete("/ai/sessions/{session_id}")
async def delete_session(session_id: str, user: dict = Depends(get_current_user)):
    await db.chat_sessions.delete_one({"_id": ObjectId(session_id), "user_id": str(user["_id"])})
    await db.messages.delete_many({"session_id": session_id, "user_id": str(user["_id"])})
    return {"message": "deleted"}


async def _chat_session(uid, message, session_id=None, *, device_oid=None, server_id=None):
    if session_id:
        try:
            session = await db.chat_sessions.find_one({"_id": ObjectId(session_id), "user_id": uid})
        except Exception:
            session = None
        if not session:
            raise HTTPException(status_code=404, detail="Chat session not found")
        if session.get("device_id") != device_oid or session.get("server_id") not in (None, server_id):
            raise HTTPException(status_code=409, detail="This chat belongs to a different execution target. Start a new chat.")
        if server_id and not session.get("server_id"):
            await db.chat_sessions.update_one({"_id": ObjectId(session_id)}, {"$set": {"server_id": server_id}})
        return session_id
    doc = {"user_id": uid, "title": message[:40], "created_at": iso_now(), "updated_at": iso_now()}
    if device_oid:
        doc["device_id"] = device_oid
    if server_id:
        doc["server_id"] = server_id
    result = await db.chat_sessions.insert_one(doc)
    return str(result.inserted_id)


async def _chat_history(uid, session_id, message, **target):
    await db.messages.insert_one({"session_id": session_id, "user_id": uid, "role": "user",
                                  "content": message, "created_at": iso_now(), **target})
    docs = await db.messages.find({"session_id": session_id, "user_id": uid}).sort("created_at", -1).to_list(20)
    return [{"role": d["role"], "content": d["content"]} for d in reversed(docs)]


async def _save_task(session_id, uid, record, **target):
    await db.messages.insert_one({"session_id": session_id, "user_id": uid, "role": "assistant",
                                  "content": autonomous.history_content(record), "task": record,
                                  "created_at": iso_now(), **target})
    await db.chat_sessions.update_one({"_id": ObjectId(session_id)}, {"$set": {"updated_at": iso_now()}})
    for step in record.get("steps", []):
        await db.logs.insert_one({"user_id": uid, "action": "AI: " + step["command"][:120],
                                  "category": "device_command" if target.get("device_id") else "command",
                                  "detail": f"step={step['step_id']}, exit={step.get('exit_code')}",
                                  "command": step["command"], "exit_code": step.get("exit_code"),
                                  "duration": step.get("duration"), "task_id": record.get("task_id"),
                                  "created_at": iso_now(), **target})


@api.post("/ai/chat")
async def ai_chat(body: ChatInput, request: Request, user: dict = Depends(get_current_user)):
    uid = str(user["_id"])
    message = body.message.strip()
    if not message:
        raise HTTPException(status_code=400, detail="Message is empty")
    server = await get_owned_server(body.server_id, user) if body.server_id else None
    session_id = await _chat_session(uid, message, body.session_id, server_id=body.server_id)
    history = await _chat_history(uid, session_id, message, server_id=body.server_id)

    async def event_gen():
        queue = asyncio.Queue(maxsize=256)
        disconnected = False
        finished = False

        async def send(event):
            if not disconnected:
                await queue.put(event)

        async def worker():
            record = {}
            try:
                if server:
                    info = {**(server.get("info") or {}), "host": server["host"],
                            "os_configured": server.get("os"), "current_user": server["username"]}
                    context = ai_service.build_context(info, body.terminal_context)

                    async def execute(command, shell, timeout, on_output):
                        return await ssh_manager.run_command_stream(server, command, shell, timeout, on_output)

                    await autonomous.run_task(history, context, ai_service.request_task_turn, execute, send, record=record)
                else:
                    await send({"type": "task_started", "language": autonomous.language(history), "started_at": time.time()})
                    answer = []
                    async for delta in ai_service.stream_chat(history, None, body.terminal_context):
                        answer.append(delta)
                        await send({"type": "delta", "content": delta})
                    record.update(status="answered", summary="".join(answer), steps=[], evidence=[], verified=False)
                    await send({"type": "result", **record})
                    await send({"type": "done", "status": "answered"})
            except asyncio.CancelledError:
                record.update(status="cancelled", summary="Task stopped.", steps=record.get("steps", []))
            except Exception as exc:
                record.update(status="blocked", summary=public_error(exc), steps=[])
                await send({"type": "error", "message": public_error(exc)})
                await send({"type": "done", "status": "blocked"})
            finally:
                if record:
                    await _save_task(session_id, uid, record, server_id=body.server_id)

        yield f"data: {json.dumps({'type': 'session', 'session_id': session_id})}\n\n"
        job = asyncio.create_task(worker())
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15)
                except asyncio.TimeoutError:
                    if job.done():
                        break
                    yield ': keepalive\n\n'
                    continue
                yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                if event.get("type") == "done":
                    finished = True
                    break
        finally:
            disconnected = True
            # After a final result the worker may still be saving the record. Let that write finish.
            if not job.done() and not finished:
                job.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await job

    return StreamingResponse(event_gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---------------- devices (Hacker rsvx7 Ai Agent) ----------------

DEVICE_ID_RE = re.compile(r"^HG-[0-9A-F]{8}-[0-9A-F]{4}$", re.IGNORECASE)


def public_device(doc: dict) -> dict:
    device_id = doc["device_id"]
    online = device_id in connected_agents
    return {
        "id": str(doc["_id"]),
        "device_id": device_id,
        "uuid": doc.get("uuid"),
        "name": doc.get("name") or (doc.get("info") or {}).get("hostname") or "Unnamed device",
        "icon": doc.get("icon") or "server",
        "status": "online" if online else (doc.get("status") if doc.get("status") in ("connecting", "error") else "offline"),
        "info": doc.get("info"),
        "metrics": doc.get("metrics"),
        "agent_version": doc.get("agent_version"),
        "last_seen": doc.get("last_seen"),
        "created_at": doc.get("created_at"),
    }


async def broadcast_user_devices(user_id: str):
    watchers = user_device_watchers.get(str(user_id))
    if not watchers:
        return
    docs = await db.devices.find({"user_id": str(user_id)}).sort("created_at", -1).to_list(200)
    data = json.dumps({"type": "snapshot", "devices": [public_device(d) for d in docs]})
    for ws in list(watchers):
        try:
            await ws.send_text(data)
        except Exception:
            watchers.discard(ws)


async def broadcast_device(device_id: str, payload: dict):
    watchers = device_watchers.get(device_id)
    if watchers:
        data = json.dumps(payload)
        for ws in list(watchers):
            try:
                await ws.send_text(data)
            except Exception:
                watchers.discard(ws)
    device = await db.devices.find_one({"device_id": device_id}, {"user_id": 1})
    if device:
        await broadcast_user_devices(device["user_id"])


async def add_device_log(device_id: str, user_id: str, action: str, detail: str = ""):
    await db.logs.insert_one({
        "user_id": str(user_id), "action": action, "category": "device",
        "detail": detail, "server_id": None, "device_id": device_id, "created_at": iso_now()})


@api.get("/devices")
async def list_devices(user: dict = Depends(get_current_user)):
    docs = await db.devices.find({"user_id": str(user["_id"])}).sort("created_at", -1).to_list(200)
    return [public_device(d) for d in docs]


@api.post("/devices/register")
async def register_device(body: DeviceRegisterInput, user: dict = Depends(get_current_user)):
    device_id = body.device_id.strip().upper()
    if not DEVICE_ID_RE.match(device_id):
        raise HTTPException(status_code=400, detail="Invalid Device ID format (expected HG-XXXXXXXX-XXXX)")
    if len(body.device_secret.strip()) < 64:
        raise HTTPException(status_code=400, detail="Invalid Device Secret (must be at least 64 characters)")
    existing = await db.devices.find_one({"device_id": device_id})
    if existing:
        if existing["user_id"] != str(user["_id"]):
            raise HTTPException(status_code=409, detail="This device is already linked to another account")
        raise HTTPException(status_code=409, detail="This device is already linked to your account")
    doc = {
        "user_id": str(user["_id"]),
        "device_id": device_id,
        "secret_hash": hash_password(body.device_secret.strip()),
        "uuid": None,
        "name": body.name or None,
        "status": "offline",
        "info": None,
        "agent_version": None,
        "last_seen": None,
        "created_at": iso_now(),
    }
    result = await db.devices.insert_one(doc)
    doc["_id"] = result.inserted_id
    await add_device_log(device_id, user["_id"], f"Linked device {device_id}", "device")
    await broadcast_user_devices(str(user["_id"]))
    return public_device(doc)


@api.put("/devices/{device_id}/rename")
async def rename_device(device_id: str, body: DeviceRenameInput, user: dict = Depends(get_current_user)):
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    await db.devices.update_one({"_id": device["_id"]}, {"$set": {"name": body.name}})
    doc = await db.devices.find_one({"_id": device["_id"]})
    await broadcast_user_devices(str(user["_id"]))
    return public_device(doc)


@api.post("/devices/{device_id}/rotate-secret")
async def rotate_device_secret(device_id: str, body: DeviceRotateInput, user: dict = Depends(get_current_user)):
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    if len(body.device_secret.strip()) < 64:
        raise HTTPException(status_code=400, detail="Secret must be at least 64 characters")
    await db.devices.update_one({"_id": device["_id"]}, {"$set": {"secret_hash": hash_password(body.device_secret.strip())}})
    await add_device_log(device["device_id"], user["_id"], f"Rotated secret for {device['device_id']}", "device")
    await broadcast_user_devices(str(user["_id"]))
    return {"message": "Secret rotated"}


@api.delete("/devices/{device_id}")
async def delete_device(device_id: str, user: dict = Depends(get_current_user)):
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    ws = connected_agents.get(device["device_id"])
    if ws:
        try:
            await ws.close()
        except Exception:
            pass
        connected_agents.pop(device["device_id"], None)
    await db.devices.delete_one({"_id": device["_id"]})
    await add_device_log(device["device_id"], user["_id"], f"Removed device {device['device_id']}", "device")
    await broadcast_user_devices(str(user["_id"]))
    return {"message": "removed"}


@api.get("/devices/{device_id}")
async def get_device(device_id: str, user: dict = Depends(get_current_user)):
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return public_device(device)


@api.get("/devices/{device_id}/sessions")
async def device_sessions(device_id: str, user: dict = Depends(get_current_user)):
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    docs = await db.chat_sessions.find(
        {"user_id": str(user["_id"]), "device_id": device_id}).sort("updated_at", -1).to_list(100)
    return [{"id": str(d["_id"]), "title": d.get("title", "New chat"), "updated_at": d.get("updated_at")} for d in docs]


@api.get("/devices/{device_id}/sessions/{session_id}/messages")
async def device_session_messages(device_id: str, session_id: str, user: dict = Depends(get_current_user)):
    try:
        device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
        session = await db.chat_sessions.find_one({"_id": ObjectId(session_id), "device_id": device_id,
                                                   "user_id": str(user["_id"])})
    except Exception:
        device = session = None
    if not device or not session:
        raise HTTPException(status_code=404, detail="Device chat not found")
    docs = await db.messages.find(
        {"session_id": session_id, "user_id": str(user["_id"]), "device_id": device_id}).sort("created_at", 1).to_list(500)
    return [{"id": str(d["_id"]), "role": d["role"], "content": d["content"], "task": d.get("task"), "created_at": d["created_at"]} for d in docs]


@api.put("/devices/{device_id}/icon")
async def set_device_icon(device_id: str, body: DeviceIconInput, user: dict = Depends(get_current_user)):
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    await db.devices.update_one({"_id": device["_id"]}, {"$set": {"icon": body.icon}})
    doc = await db.devices.find_one({"_id": device["_id"]})
    await broadcast_user_devices(str(user["_id"]))
    return public_device(doc)


@api.post("/devices/{device_id}/command/{action}")
async def device_command(device_id: str, action: str, user: dict = Depends(get_current_user)):
    if action not in ("restart", "reconnect", "refresh"):
        raise HTTPException(status_code=400, detail="Invalid action")
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    ws = connected_agents.get(device["device_id"])
    if not ws:
        raise HTTPException(status_code=409, detail="Device is offline")
    try:
        await ws.send_text(json.dumps({"type": "command", "action": action}))
    except Exception:
        raise HTTPException(status_code=409, detail="Failed to reach agent")
    await add_device_log(device["device_id"], user["_id"], f"Sent '{action}' to {device['device_id']}", "device")
    return {"message": f"{action} sent"}


@api.post("/devices/{device_id}/rotate")
async def device_rotate(device_id: str, user: dict = Depends(get_current_user)):
    device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": str(user["_id"])})
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    new_secret = secrets.token_urlsafe(64)
    await db.devices.update_one({"_id": device["_id"]}, {"$set": {"secret_hash": hash_password(new_secret)}})
    ws = connected_agents.get(device["device_id"])
    delivered = False
    if ws:
        try:
            await ws.send_text(json.dumps({"type": "command", "action": "rotate_secret", "secret": new_secret}))
            delivered = True
        except Exception:
            delivered = False
    await add_device_log(device["device_id"], user["_id"], f"Rotated secret for {device['device_id']}", "device")
    await broadcast_user_devices(str(user["_id"]))
    return {"secret": new_secret, "delivered_to_agent": delivered}


# ---------------- agent installer downloads ----------------

def _agent_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "remote-agent"


@api.get("/agent/info")
async def agent_info():
    return {"version": AGENT_VERSION, "platforms": ["windows", "linux", "macos"]}


@api.get("/agent/download/{platform}")
async def agent_download(platform: str, request: Request):
    platform = platform.lower()
    mapping = {"linux": "install.sh", "macos": "install.sh", "windows": "install.ps1"}
    if platform not in mapping:
        raise HTTPException(status_code=404, detail="Unknown platform")
    # If a native installer has been published (e.g. a GitHub Release .exe/.dmg/.deb),
    # redirect the download there. Configure via env: AGENT_DOWNLOAD_WINDOWS / _LINUX / _MACOS.
    release_url = os.environ.get(f"AGENT_DOWNLOAD_{platform.upper()}", "").strip()
    if release_url:
        return RedirectResponse(url=release_url, status_code=302)
    fname = mapping[platform]
    fpath = _agent_dir() / fname
    if not fpath.exists():
        raise HTTPException(status_code=404, detail="Installer not available")
    site = os.environ.get('OPENROUTER_SITE_URL') or str(request.base_url).split('/api/remote')[0].rstrip('/')
    origin = site.rstrip('/') + '/api/remote'
    content = fpath.read_text().replace('http://127.0.0.1:3000/api/remote', origin)
    dl_name = "install-hackergpt-agent.ps1" if platform == "windows" else "install-hackergpt-agent.sh"
    return Response(content=content, media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{dl_name}"'})


@api.get("/agent/bundle")
async def agent_bundle(request: Request):
    adir = _agent_dir()
    if not adir.exists():
        raise HTTPException(status_code=404, detail="Agent bundle not available")
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        site = os.environ.get('OPENROUTER_SITE_URL') or str(request.base_url).split('/api/remote')[0].rstrip('/')
        config = json.dumps({'agent_server_url': site.rstrip('/') + '/api/remote'}).encode()
        info = tarfile.TarInfo('hackergpt-agent/agent_server.json'); info.size = len(config)
        tar.addfile(info, io.BytesIO(config))
        for f in adir.glob("*.py"):
            tar.add(f, arcname=f"hackergpt-agent/{f.name}")
        for extra in ("requirements.txt", "OPERATIONS.txt"):
            p = adir / extra
            if p.exists():
                tar.add(p, arcname=f"hackergpt-agent/{extra}")
    buf.seek(0)
    return Response(content=buf.read(), media_type="application/gzip",
                    headers={"Content-Disposition": 'attachment; filename="hackergpt-agent.tar.gz"'})


@api.get("/")
async def root():
    return {"service": "Hacker rsvx7 Ai API", "status": "operational"}


app.include_router(api)

@app.get("/healthz")
async def healthz():
    try:
        await db.command("ping")
        return {"status": "ok", "database": "ok"}
    except Exception:
        return Response(content=json.dumps({"status": "degraded", "database": "unavailable"}), media_type="application/json", status_code=503)


# ---------------- WebSocket terminal ----------------

@app.websocket("/api/ws/terminal/{server_id}")
async def terminal_ws(websocket: WebSocket, server_id: str, token: str = Query(...)):
    await websocket.accept()
    try:
        payload = await ws_identity(websocket, token)
        uid = payload["sub"]
    except Exception:
        await websocket.send_text(json.dumps({"type": "error", "data": "Authentication failed"}))
        await websocket.close()
        return

    server = await db.servers.find_one({"_id": ObjectId(server_id), "user_id": uid})
    if not server:
        await websocket.send_text(json.dumps({"type": "error", "data": "Server not found"}))
        await websocket.close()
        return

    loop = asyncio.get_event_loop()
    channel = None
    try:
        ssh_client = await asyncio.to_thread(ssh_manager.get_client, server)
        channel = ssh_client.invoke_shell(term="xterm-256color", width=120, height=32)
        channel.settimeout(0.0)
    except Exception as e:
        await websocket.send_text(json.dumps({"type": "error", "data": f"SSH connection failed: {e}"}))
        await websocket.close()
        return

    await websocket.send_text(json.dumps({"type": "connected", "data": f"Connected to {server['nickname']}"}))
    stop = threading.Event()

    def reader():
        while not stop.is_set():
            try:
                if channel.recv_ready():
                    data = channel.recv(4096).decode("utf-8", errors="replace")
                    asyncio.run_coroutine_threadsafe(
                        websocket.send_text(json.dumps({"type": "output", "data": data})), loop)
                else:
                    if channel.exit_status_ready() and not channel.recv_ready():
                        break
                    threading.Event().wait(0.02)
            except Exception:
                break

    thread = threading.Thread(target=reader, daemon=True)
    thread.start()

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except Exception:
                msg = {"type": "input", "data": raw}
            if msg.get("type") == "input":
                channel.send(msg["data"])
            elif msg.get("type") == "resize":
                try:
                    channel.resize_pty(width=int(msg.get("cols", 120)), height=int(msg.get("rows", 32)))
                except Exception:
                    pass
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        stop.set()
        try:
            channel.close()
        except Exception:
            pass


# ---------------- WebSocket: Hacker rsvx7 Ai Agent channel ----------------

@app.websocket("/api/ws/agent")
async def agent_ws(websocket: WebSocket):
    await websocket.accept()
    device_id = None
    try:
        raw = await asyncio.wait_for(websocket.receive_text(), timeout=15)
        msg = json.loads(raw)
        if msg.get("type") != "auth":
            await websocket.send_text(json.dumps({"type": "error", "message": "Expected auth"}))
            await websocket.close()
            return
        did = (msg.get("device_id") or "").strip().upper()
        secret = msg.get("secret") or ""
        device = await db.devices.find_one({"device_id": did})
        if not device or not verify_password(secret, device.get("secret_hash", "")):
            await websocket.send_text(json.dumps({"type": "error", "message": "Invalid device credentials"}))
            await websocket.close()
            return
        device_id = did
        # replace any existing connection
        old = connected_agents.get(device_id)
        if old:
            try:
                await old.close()
            except Exception:
                pass
        connected_agents[device_id] = websocket
        update = {"status": "online", "last_seen": iso_now(),
                  "agent_version": msg.get("agent_version"), "uuid": msg.get("uuid"),
                  "permissions": msg.get("permissions") or {}}
        if msg.get("info"):
            update["info"] = msg["info"]
        await db.devices.update_one({"_id": device["_id"]}, {"$set": update})
        await add_device_log(device_id, device["user_id"], f"Agent connected: {device_id}", "connection")
        await websocket.send_text(json.dumps({"type": "authok", "server_version": AGENT_VERSION}))
        await broadcast_device(device_id, {"type": "status", "status": "online"})

        while True:
            try:
                raw = await asyncio.wait_for(websocket.receive_text(), timeout=90)
            except asyncio.TimeoutError:
                logger.info(f"agent {device_id} idle >90s; closing stale connection")
                break
            try:
                msg = json.loads(raw)
            except Exception:
                continue
            mtype = msg.get("type")
            if mtype == "heartbeat":
                await db.devices.update_one({"device_id": device_id}, {"$set": {"last_seen": iso_now(), "status": "online"}})
                await websocket.send_text(json.dumps({"type": "ack", "ts": msg.get("ts")}))
            elif mtype == "ping":
                await websocket.send_text(json.dumps({"type": "pong", "ts": msg.get("ts")}))
            elif mtype == "metrics":
                metrics = msg.get("data")
                await db.devices.update_one({"device_id": device_id},
                    {"$set": {"metrics": metrics, "last_seen": iso_now()}})
                await broadcast_device(device_id, {"type": "metrics", "data": metrics})
            elif mtype == "info":
                await db.devices.update_one({"device_id": device_id},
                    {"$set": {"info": msg.get("data"), "last_seen": iso_now(),
                              "agent_version": msg.get("agent_version") or None}})
                await broadcast_device(device_id, {"type": "info", "data": msg.get("data"),
                                                   "agent_version": msg.get("agent_version")})
            elif mtype in ("exec_output", "exec_done"):
                q = device_exec_queues.get(msg.get("exec_id"))
                if q is not None and device_exec_owners.get(msg.get("exec_id")) == device_id:
                    await q.put(msg)
            elif mtype in ("shell_output", "shell_exit"):
                q = device_shell_queues.get(msg.get("shell_id"))
                if q is not None and device_shell_owners.get(msg.get("shell_id")) == device_id:
                    await q.put(msg)
    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    except Exception as e:
        logger.info(f"agent ws error: {e}")
    finally:
        if device_id and connected_agents.get(device_id) is websocket:
            connected_agents.pop(device_id, None)
            for execution_id, owner in list(device_exec_owners.items()):
                if owner == device_id and execution_id in device_exec_queues:
                    await device_exec_queues[execution_id].put({"type": "exec_output", "data": "\n[Agent connection lost]\n"})
                    await device_exec_queues[execution_id].put({"type": "exec_done", "exit_code": -1})
            device_doc = await db.devices.find_one({"device_id": device_id}, {"user_id": 1})
            await db.devices.update_one({"device_id": device_id},
                {"$set": {"status": "offline", "last_seen": iso_now()}})
            await broadcast_device(device_id, {"type": "status", "status": "offline"})
            if device_doc:
                await broadcast_user_devices(device_doc["user_id"])


# ---------------- WebSocket: real-time device list ----------------
@app.websocket("/api/ws/devices")
async def devices_ws(websocket: WebSocket, token: str = Query(...)):
    await websocket.accept()
    try:
        payload = await ws_identity(websocket, token)
        uid = payload["sub"]
    except Exception:
        await websocket.send_text(json.dumps({"type": "error", "message": "Authentication failed"}))
        await websocket.close()
        return
    user_device_watchers.setdefault(uid, set()).add(websocket)
    try:
        docs = await db.devices.find({"user_id": uid}).sort("created_at", -1).to_list(200)
        await websocket.send_text(json.dumps({"type": "snapshot", "devices": [public_device(d) for d in docs]}))
        while True:
            await websocket.receive_text()
    except (WebSocketDisconnect, Exception):
        pass
    finally:
        watchers = user_device_watchers.get(uid)
        if watchers:
            watchers.discard(websocket)


# ---------------- WebSocket: frontend live device monitor ----------------

@app.websocket("/api/ws/monitor/{device_id}")
async def monitor_ws(websocket: WebSocket, device_id: str, token: str = Query(...)):
    await websocket.accept()
    try:
        payload = await ws_identity(websocket, token)
        uid = payload["sub"]
    except Exception:
        await websocket.close()
        return
    try:
        device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": uid})
    except Exception:
        device = None
    if not device:
        await websocket.send_text(json.dumps({"type": "error", "message": "Device not found"}))
        await websocket.close()
        return
    did = device["device_id"]
    device_watchers.setdefault(did, set()).add(websocket)
    await websocket.send_text(json.dumps({
        "type": "snapshot",
        "status": "online" if did in connected_agents else "offline",
        "info": device.get("info"),
        "metrics": device.get("metrics"),
        "agent_version": device.get("agent_version"),
        "last_seen": device.get("last_seen"),
    }))
    try:
        while True:
            await websocket.receive_text()
    except (WebSocketDisconnect, Exception):
        pass
    finally:
        watchers = device_watchers.get(did)
        if watchers:
            watchers.discard(websocket)


# ---------------- WebSocket: AI command execution on linked devices ----------------

async def _run_on_agent(device, command, shell, timeout, on_output):
    did = device["device_id"]
    version = device.get("agent_version")
    if version:
        parts = tuple(int(p) if p.isdigit() else 0 for p in str(version).split(".")[:3])
        if parts < (1, 2, 0):
            return {"exit_code": -1, "duration": 0,
                    "output": "Update the linked Hacker rsvx7 Ai Agent to version 1.2.0 from this project. Older Agents do not support execution without a deadline."}
    agent = connected_agents.get(did)
    if not agent:
        return {"exit_code": -1, "duration": 0, "output": "Device is offline. Start the Hacker rsvx7 Ai Agent."}
    exec_id = secrets.token_hex(12)
    queue = asyncio.Queue()
    device_exec_queues[exec_id] = queue
    device_exec_owners[exec_id] = did
    start = time.monotonic()
    completed = False
    try:
        await agent.send_text(json.dumps({"type": "exec", "exec_id": exec_id, "command": command,
                                          "shell": shell, "timeout_seconds": timeout}))
        while True:
            remaining = timeout + 10 - (time.monotonic() - start) if timeout > 0 else None
            if remaining is not None and remaining <= 0:
                return {"exit_code": 124, "duration": timeout, "timed_out": True,
                        "output": "Agent command deadline exceeded."}
            try:
                event = await asyncio.wait_for(queue.get(), timeout=min(2, remaining) if remaining is not None else 2)
            except asyncio.TimeoutError:
                if connected_agents.get(did) is not agent:
                    return {"exit_code": -1, "duration": round(time.monotonic() - start, 2),
                            "output": "Agent connection lost; the command result is unknown."}
                continue
            if event.get("type") == "exec_output":
                await on_output(event.get("data", ""))
            elif event.get("type") == "exec_done":
                completed = True
                return {"exit_code": event.get("exit_code"), "duration": event.get("duration", round(time.monotonic() - start, 2)),
                        "timed_out": event.get("timed_out", False)}
    finally:
        if not completed:
            with suppress(Exception):
                await agent.send_text(json.dumps({"type": "exec_cancel", "exec_id": exec_id}))
        device_exec_queues.pop(exec_id, None)
        device_exec_owners.pop(exec_id, None)


async def _handle_device_chat(websocket, send, uid, device, body):
    message = str(body.get("message") or "").strip()
    if not message:
        await send({"type": "done", "status": "answered"})
        return
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    device_oid = str(device["_id"])
    session_id = await _chat_session(uid, message, body.get("session_id"), device_oid=device_oid)
    await send({"type": "session", "session_id": session_id})
    history = await _chat_history(uid, session_id, message, device_id=device_oid)
    device_info = {**(device.get("info") or {}), "device_name": device.get("name"),
                   "agent_version": device.get("agent_version"),
                   "permissions": device.get("permissions") or {}}
    record = {}
    completion = None
    async def task_send(event):
        nonlocal completion
        if event.get("type") == "done":
            completion = event
        else:
            await send(event)
    try:
        async def execute(command, shell, timeout, on_output):
            return await _run_on_agent(device, command, shell, timeout, on_output)
        await autonomous.run_task(history, ai_service.build_device_context(device_info),
                                  ai_service.request_task_turn, execute, task_send, record=record)
    finally:
        if record:
            await asyncio.shield(_save_task(session_id, uid, record, device_id=device_oid))
    if completion:
        await send(completion)


@app.websocket("/api/ws/exec/{device_id}")
async def exec_ws(websocket: WebSocket, device_id: str, token: str = Query(...)):
    await websocket.accept()
    try:
        payload = await ws_identity(websocket, token)
        uid = payload["sub"]
        device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": uid})
    except Exception:
        device = None
    if not device:
        await websocket.send_text(json.dumps({"type": "error", "message": "Device not found or authentication failed"}))
        await websocket.close()
        return
    lock = asyncio.Lock()
    async def send(event):
        async with lock:
            await websocket.send_text(json.dumps(event, ensure_ascii=False))
    async def chat_job(body):
        try:
            current = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": uid})
            await _handle_device_chat(websocket, send, uid, current, body)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.info("Device task error: %s", type(exc).__name__)
            with suppress(Exception):
                await send({"type": "error", "message": public_error(exc)})
                await send({"type": "done", "status": "blocked"})

    await send({"type": "ready", "status": "online" if device["device_id"] in connected_agents else "offline"})
    active = None
    try:
        while True:
            raw = await websocket.receive_text()
            try:
                body = json.loads(raw)
            except Exception:
                continue
            if body.get("type") == "chat":
                if active and not active.done():
                    await send({"type": "busy", "message": "A task is already running."})
                else:
                    active = asyncio.create_task(chat_job(body))
            elif body.get("type") == "cancel" and active and not active.done():
                active.cancel()
            elif body.get("type") == "ping":
                await send({"type": "pong"})
    except (WebSocketDisconnect, Exception):
        pass
    finally:
        if active and not active.done():
            active.cancel()
        if active:
            with suppress(asyncio.CancelledError, Exception):
                await active


# ---------------- WebSocket: interactive device terminal (via Agent) ----------------

@app.websocket("/api/ws/device-terminal/{device_id}")
async def device_terminal_ws(websocket: WebSocket, device_id: str, token: str = Query(...)):
    await websocket.accept()
    try:
        payload = await ws_identity(websocket, token)
        uid = payload["sub"]
    except Exception:
        await websocket.close()
        return
    try:
        device = await db.devices.find_one({"_id": ObjectId(device_id), "user_id": uid})
    except Exception:
        device = None
    if not device:
        await websocket.send_text(json.dumps({"type": "error", "data": "Device not found"}))
        await websocket.close()
        return

    did = device["device_id"]
    agent = connected_agents.get(did)
    if not agent:
        await websocket.send_text(json.dumps({"type": "offline"}))
        await websocket.close()
        return

    shell_id = secrets.token_hex(8)
    q: asyncio.Queue = asyncio.Queue()
    device_shell_queues[shell_id] = q
    device_shell_owners[shell_id] = did
    stop = asyncio.Event()

    try:
        await agent.send_text(json.dumps({"type": "shell_start", "shell_id": shell_id, "cols": 120, "rows": 32}))
    except Exception:
        device_shell_queues.pop(shell_id, None)
        device_shell_owners.pop(shell_id, None)
        await websocket.send_text(json.dumps({"type": "offline"}))
        await websocket.close()
        return
    await websocket.send_text(json.dumps({"type": "connected", "data": device.get("name") or did}))
    await add_device_log(did, uid, f"Opened terminal on {did}", "connection")

    async def pump_output():
        while not stop.is_set():
            try:
                m = await asyncio.wait_for(q.get(), timeout=1.0)
            except asyncio.TimeoutError:
                if connected_agents.get(did) is not agent:
                    await websocket.send_text(json.dumps({"type": "offline"}))
                    stop.set()
                    break
                continue
            if m.get("type") == "shell_output":
                await websocket.send_text(json.dumps({"type": "output", "data": m.get("data", "")}))
            elif m.get("type") == "shell_exit":
                await websocket.send_text(json.dumps({"type": "exit"}))
                stop.set()
                break

    async def pump_input():
        while not stop.is_set():
            try:
                raw = await websocket.receive_text()
            except Exception:
                stop.set()
                break
            try:
                msg = json.loads(raw)
            except Exception:
                continue
            a = connected_agents.get(did)
            if a is None:
                await websocket.send_text(json.dumps({"type": "offline"}))
                stop.set()
                break
            try:
                if msg.get("type") == "input":
                    await a.send_text(json.dumps({"type": "shell_input", "shell_id": shell_id, "data": msg.get("data", "")}))
                elif msg.get("type") == "resize":
                    await a.send_text(json.dumps({"type": "shell_resize", "shell_id": shell_id,
                                                  "cols": int(msg.get("cols", 120)), "rows": int(msg.get("rows", 32))}))
            except Exception:
                stop.set()
                break

    out_task = asyncio.create_task(pump_output())
    in_task = asyncio.create_task(pump_input())
    try:
        _done, pending = await asyncio.wait({out_task, in_task}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
        await asyncio.gather(out_task, in_task, return_exceptions=True)
    finally:
        device_shell_queues.pop(shell_id, None)
        device_shell_owners.pop(shell_id, None)
        a = connected_agents.get(did)
        if a is not None:
            try:
                await a.send_text(json.dumps({"type": "shell_close", "shell_id": shell_id}))
            except Exception:
                pass
        try:
            await websocket.close()
        except Exception:
            pass


# ---------------- device chat sessions endpoints registered above ----------------


# ---------------- startup ----------------

async def startup():
    from persistence import uses_mysql
    if uses_mysql(): return  # Version 2 SQL migrations own these tables and indexes.
    await db.servers.create_index("user_id")
    await db.logs.create_index([("user_id", 1), ("created_at", -1)])
    await db.messages.create_index([("session_id", 1), ("created_at", 1)])
    await db.devices.create_index("device_id", unique=True)
    await db.devices.create_index("user_id")
    await db.devices.update_many({}, {"$set": {"status": "offline"}})

async def shutdown():
    for ws in list(connected_agents.values()):
        with suppress(Exception): await ws.close(code=1001)
    for sid in list(ssh_manager._clients): ssh_manager.close_client(sid)

class SessionGuard:
    def __init__(self, app): self.app = app
    async def __call__(self, scope, receive, send):
        if scope['type'] != 'websocket' or scope['path'].endswith('/ws/agent'):
            return await self.app(scope, receive, send)
        from starlette.websockets import WebSocket
        from urllib.parse import parse_qs
        token = parse_qs(scope.get('query_string',b'').decode()).get('token',[''])[0]
        async def checked_receive():
            event = await receive()
            if event['type'] == 'websocket.receive':
                try: await ws_identity(WebSocket(scope, receive, send),token)
                except HTTPException:
                    await send({'type':'websocket.close','code':4401})
                    return {'type':'websocket.disconnect','code':4401}
            return event
        await self.app(scope, checked_receive, send)
app.add_middleware(SessionGuard)

from bson.errors import InvalidId
from fastapi.responses import JSONResponse
@app.exception_handler(InvalidId)
async def invalid_target(request, error):
    return JSONResponse({'detail':'Target not found'}, status_code=404)
