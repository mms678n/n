"""RSVX7 Builder: existing account, administrator's model and existing token wallet.

The private Node service reuses the DarkForge agent engine. It receives no API
key or database credentials. Browser verification never runs generated code in
the application server process.
"""
import asyncio
import hashlib
import hmac
import json
import logging
import os
import re
import time
import uuid
from datetime import datetime, timezone, timedelta

import anyio
import httpx
import jwt
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, ConfigDict

from auth import current_user, db, JWT_SECRET
from workspace import _get_project, project_memory_prompt
from ai_settings import current_settings, claim_generation, release_generation, provider_error, MODEL_FIELDS
from tokens import check_can_afford, charge_user, estimate_messages_tokens, max_completion_for_balance
from tg_verify import require_membership
from memberships import require_access, refresh

async def builder_access(user: dict = Depends(current_user)):
    require_access(user, feature='builder')
    return user

router = APIRouter(prefix='/api/builder', tags=['Builder'])
_tasks: dict[str, asyncio.Task] = {}
CHECKS = ['files', 'dependencies', 'types', 'lint', 'tests', 'build', 'preview']
AGENTS = ['architect', 'designer', 'coder', 'reviewer']
MODEL_HEARTBEAT_SECONDS = 10
MODEL_PREFLIGHT_SECONDS = 30
MODEL_CALL_SECONDS = 450
MODEL_CLEANUP_SECONDS = 5
JOB_STALL_SECONDS = 480
JOB_TOTAL_SECONDS = 3600
ENGINE_PROTOCOL = 4
logger = logging.getLogger('builder')
ENGINE_URL = 'http://127.0.0.1:' + os.environ.get('BUILDER_ENGINE_PORT', '3001')

def _now(): return datetime.now(timezone.utc).isoformat()
def engine_secret(): return hmac.new(JWT_SECRET.encode(), b'rsvx7-builder-engine-v1', hashlib.sha256).hexdigest()
ENGINE_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'builder', 'dist', 'service.mjs')

def _check_engine_health(response):
    try: health = response.json()
    except ValueError: health = {}
    if response.status_code != 200 or not isinstance(health, dict) or health.get('protocol') != ENGINE_PROTOCOL or health.get('mode') != 'direct':
        raise HTTPException(503, 'محرك Builder يعمل بإصدار أو إعدادات قديمة. أعد تشغيل خدمة المنصة لتفعيل التحديث.')
    return True

async def ensure_engine():
    """Start the private Node engine on loopback if it is not already answering."""
    headers = {'Authorization': 'Bearer ' + engine_secret()}
    try:
        async with httpx.AsyncClient(timeout=2, trust_env=False) as client:
            if _check_engine_health(await client.get(ENGINE_URL + '/health', headers=headers)): return
    except httpx.HTTPError: pass
    if not os.path.isfile(ENGINE_FILE): raise HTTPException(503, 'ملفات محرك Builder المبنية غير موجودة. أعد بناء المنصة قبل التشغيل.')
    env = {**os.environ, 'BUILDER_ENGINE_SECRET': engine_secret(),
           'BUILDER_API_ORIGIN': os.environ.get('BUILDER_API_ORIGIN', 'http://127.0.0.1:' + os.environ.get('PORT', '8001'))}
    with open('/tmp/builder-engine.log', 'ab') as log:
        await asyncio.create_subprocess_exec('node', ENGINE_FILE, env=env, stdout=log, stderr=log, start_new_session=True)
    for _ in range(20):
        await asyncio.sleep(0.25)
        try:
            async with httpx.AsyncClient(timeout=1, trust_env=False) as client:
                if _check_engine_health(await client.get(ENGINE_URL + '/health', headers=headers)): return
        except httpx.HTTPError: pass
    raise HTTPException(503, 'تعذّر بدء محرك Builder. أعد تشغيل خدمة المنصة وراجع سجل التشغيل.')

def _empty(): return {'revision': 0, 'files': {}, 'messages': [], 'phase': 'planning', 'job': None, 'darkMode': True, 'checks': [], 'repairState': {'automaticAttempts': 0, 'fingerprints': []}}
def _state(project): return {**_empty(), **(project.get('builder') or {})}
def _cas(uid, pid, revision, job=None):
    query = {'_id': pid, 'user_id': uid}
    query['$or'] = [{'builder.revision': revision}] + ([{'builder': {'$exists': False}}] if revision == 0 else [])
    if job is not None: query.update({'builder.job.id': job, 'builder.job.status': 'running'})
    return query

def validate_files(files):
    if not isinstance(files, dict) or len(files) > 1500: raise HTTPException(400, 'ملفات المشروع غير صالحة.')
    result, size = {}, 0
    for raw, file in files.items():
        path = raw.removeprefix('/home/project/')
        if not path or path.startswith('/') or len(path) > 400 or re.search(r'[\\\x00-\x1f"<>:]', path) or any(p in ('', '.', '..', '.git', 'node_modules', '.darkforge', 'dist', 'build') for p in path.split('/')):
            raise HTTPException(400, 'مسار ملف غير صالح.')
        if not isinstance(file, dict) or file.get('type') != 'file' or not isinstance(file.get('content'), str): raise HTTPException(400, 'صيغة ملف غير صالحة.')
        size += len(file['content'].encode('utf-8'))
        if size > 6 * 1024 * 1024: raise HTTPException(413, 'مصدر المشروع أكبر من 6 MB.')
        result['/home/project/' + path] = {'type': 'file', 'content': file['content'], 'isBinary': file.get('isBinary') is True}
    return result

class QuestionAnswer(BaseModel):
    id: str = Field(min_length=1, max_length=80)
    options: list[str] = Field(default_factory=list, max_length=5)
    text: str = Field(default='', max_length=2000)

class RepairContext(BaseModel):
    step: str = Field(pattern=r'^(files|dependencies|types|lint|tests|build|preview)$')
    diagnostic: str = Field(min_length=1, max_length=8000)
    automatic: bool = False
    affectedFiles: list[str] = Field(default_factory=list, max_length=30)


class RunBody(BaseModel):
    model_config = ConfigDict(extra='ignore')
    requestId: str = Field(min_length=8, max_length=100, pattern=r'^[a-zA-Z0-9_-]+$')
    revision: int = Field(ge=0)
    action: str = Field(default='message', pattern=r'^(message|answers|retry|approve|discuss|repair)$')
    text: str = Field(default='', max_length=20000)
    proposalId: str | None = Field(default=None, max_length=100)
    questionMessageId: str | None = Field(default=None, max_length=100)
    answers: list[QuestionAnswer] = Field(default_factory=list, max_length=3)
    darkMode: bool = True
    personality: str = Field(default='deepdark', max_length=50)
    deepThink: bool = False
    autoSuffix: str = Field(default='', max_length=5000)
    repairContext: RepairContext | None = None

def question_answer_text(state, body):
    plan = state.get('plan') or {}
    if plan.get('kind') != 'questions' or body.questionMessageId != state.get('proposalId'):
        raise HTTPException(409, 'تغيّرت الأسئلة. حدّث المشروع قبل إرسال الإجابات.')
    questions = plan.get('questions') or []
    answers = {answer.id: answer for answer in body.answers}
    if len(answers) != len(body.answers) or set(answers) != {q['id'] for q in questions}:
        raise HTTPException(400, 'أجب عن كل الأسئلة ثم أرسلها معًا.')
    lines = []
    for question in questions:
        answer = answers[question['id']]
        if len(set(answer.options)) != len(answer.options) or any(option not in question['options'] for option in answer.options):
            raise HTTPException(400, 'أحد الخيارات لا يطابق الأسئلة الحالية.')
        if question.get('multiple') is False and len(answer.options) > 1:
            raise HTTPException(400, 'اختر إجابة واحدة لهذا السؤال.')
        parts = answer.options + ([answer.text.strip()] if answer.text.strip() else [])
        if not parts: raise HTTPException(400, 'أجب عن كل الأسئلة ثم أرسلها معًا.')
        lines.append(question['label'] + ': ' + '، '.join(parts))
    return '\n\n'.join(lines)

class SaveBody(BaseModel):
    revision: int = Field(ge=0)
    files: dict

class CheckBody(BaseModel):
    revision: int = Field(ge=0)
    checks: list[dict] = Field(max_length=7)

async def _save_job(uid, pid, job, patch):
    return await db.projects.update_one({'_id': pid, 'user_id': uid, 'builder.job.id': job, 'builder.job.status': 'running'}, {'$set': {**{'builder.' + k: v for k, v in patch.items()}, 'updated_at': _now()}})

BUILDER_DEFAULT_NAME = 'مشروع جديد'

class BuilderProjectBody(BaseModel):
    name: str = Field(default='', max_length=120)

def _builder_summary(doc):
    b = doc.get('builder') or {}
    return {'_id': doc['_id'], 'name': doc.get('builder_name') or doc.get('name') or BUILDER_DEFAULT_NAME,
            'updated_at': doc.get('updated_at'), 'created_at': doc.get('created_at'),
            'file_count': len(b.get('files') or {}), 'status': (b.get('job') or {}).get('status'), 'legacy': doc.get('kind') != 'builder'}

def _require_builder(project):
    if project.get('kind') != 'builder' and not project.get('builder'): raise HTTPException(404, 'مشروع Builder غير موجود.')
    return project

@router.get('/projects')
async def list_builder_projects(user: dict = Depends(builder_access)):
    docs = await db.projects.find({'user_id': user['_id'], '$or': [{'kind': 'builder'}, {'builder.revision': {'$gt': 0}}, {'builder.messages.0': {'$exists': True}}]},
                                  {'name': 1, 'builder_name': 1, 'kind': 1, 'updated_at': 1, 'created_at': 1, 'builder.files': 1, 'builder.job.status': 1}
                                  ).sort('updated_at', -1).to_list(200)
    return [_builder_summary(d) for d in docs]

@router.post('/projects')
async def create_builder_project(body: BuilderProjectBody, user: dict = Depends(builder_access)):
    now = _now(); name = body.name.strip()
    doc = {'_id': 'b_' + uuid.uuid4().hex[:20], 'user_id': user['_id'], 'kind': 'builder', 'name': name or BUILDER_DEFAULT_NAME,
           'builder_auto_name': not name, 'description': '', 'is_archived': False, 'created_at': now, 'updated_at': now, 'last_opened_at': now}
    await db.projects.insert_one(doc)
    return _builder_summary(doc)

@router.patch('/projects/{pid}')
async def rename_builder_project(pid: str, body: BuilderProjectBody, user: dict = Depends(builder_access)):
    _require_builder(await _get_project(pid, user['_id']))
    name = body.name.strip()
    if not name: raise HTTPException(400, 'اكتب اسم المشروع.')
    await db.projects.update_one({'_id': pid, 'user_id': user['_id']}, {'$set': {'builder_name': name, 'builder_auto_name': False, 'updated_at': _now()}})
    return {'ok': True, 'name': name}

@router.delete('/projects/{pid}')
async def delete_builder_project(pid: str, user: dict = Depends(builder_access)):
    project = _require_builder(await _get_project(pid, user['_id']))
    job = (project.get('builder') or {}).get('job') or {}
    task = _tasks.get(job.get('id'))
    if task: task.cancel()
    if project.get('kind') == 'builder': await db.projects.delete_one({'_id': pid, 'user_id': user['_id']})
    else: await db.projects.update_one({'_id': pid, 'user_id': user['_id']}, {'$unset': {'builder': '', 'builder_name': ''}})
    return {'ok': True}

@router.get('/projects/{pid}')
async def get_builder(pid: str, filesRevision: int | None = None, user: dict = Depends(builder_access)):
    project = await _get_project(pid, user['_id'])
    state = _state(project)
    job = state.get('job') or {}
    if job.get('status') == 'running' and job.get('id') not in _tasks:
        await _save_job(user['_id'], pid, job['id'], {'job.status': 'failed', 'job.error': 'أُعيد تشغيل الخادم. ملفاتك محفوظة؛ أعد المحاولة.'})
        state['job'] = {**job, 'status': 'failed', 'error': 'أُعيد تشغيل الخادم. ملفاتك محفوظة؛ أعد المحاولة.'}
    if filesRevision == state['revision']: state.pop('files', None)
    state['executionMode'] = 'direct'
    state['engineProtocol'] = ENGINE_PROTOCOL
    state['projectId'] = pid
    state['projectName'] = project.get('builder_name') or project.get('name') or BUILDER_DEFAULT_NAME
    settings = await current_settings()
    state['model'] = settings['model']
    state['models'] = settings.get('profile_capabilities', {})
    return state

@router.put('/projects/{pid}/files')
async def save_files(pid: str, body: SaveBody, user: dict = Depends(builder_access)):
    state = _state(await _get_project(pid, user['_id']))
    if (state.get('job') or {}).get('status') == 'running': raise HTTPException(409, 'انتظر اكتمال العمل قبل حفظ تعديلاتك.')
    files = validate_files(body.files)
    query = _cas(user['_id'], pid, body.revision)
    query['builder.job.status'] = {'$ne': 'running'}
    result = await db.projects.update_one(query, {'$set': {'builder.files': files, 'builder.revision': body.revision + 1, 'builder.checks': [],
        'builder.repairState': {'automaticAttempts': 0, 'fingerprints': []}, 'updated_at': _now()}})
    if not result.modified_count: raise HTTPException(409, 'تغيّرت الملفات في نافذة أخرى. حدّث المشروع أولًا.')
    return {'revision': body.revision + 1}

@router.post('/projects/{pid}/checks')
async def save_checks(pid: str, body: CheckBody, user: dict = Depends(builder_access)):
    await _get_project(pid, user['_id'])
    if len(body.checks) != 7 or {c.get('id') for c in body.checks} != set(CHECKS): raise HTTPException(400, 'يجب تضمين الفحوص السبعة.')
    checks = []
    for check in body.checks:
        if check.get('status') not in ('pending', 'running', 'passed', 'failed', 'skipped'): raise HTTPException(400, 'حالة فحص غير صالحة.')
        checks.append({'id': check['id'], 'status': check['status'], 'label': str(check.get('label', ''))[:100], 'detail': str(check.get('detail', ''))[:1000]})
    query = _cas(user['_id'], pid, body.revision); query['builder.job.status'] = {'$ne': 'running'}
    result = await db.projects.update_one(query, {'$set': {'builder.checks': checks, 'builder.checkedRevision': body.revision, 'builder.checkedAt': _now()}})
    if not result.modified_count: raise HTTPException(409, 'هذه النتائج تخص نسخة قديمة من المشروع.')
    return {'ok': True, 'passed': all(c['status'] == 'passed' for c in checks)}

@router.post('/projects/{pid}/cancel')
async def cancel(pid: str, user: dict = Depends(builder_access)):
    state = _state(await _get_project(pid, user['_id']))
    job = state.get('job') or {}
    if job.get('status') == 'running':
        # Fence writes first. Late Node replies can never replace source after cancellation.
        await _save_job(user['_id'], pid, job['id'], {'job.status': 'cancelled'})
        task = _tasks.get(job['id'])
        if task: task.cancel()
    return {'ok': True}

@router.post('/projects/{pid}/run', status_code=202)
async def start(pid: str, body: RunBody, user: dict = Depends(builder_access)):
    await require_membership(user)
    await ensure_engine()
    project = await _get_project(pid, user['_id']); state = _state(project)
    if state.get('lastRequestId') == body.requestId: return {'job': state.get('job')}
    if (state.get('job') or {}).get('status') == 'running': raise HTTPException(409, 'يوجد عمل جارٍ لهذا المشروع.')
    if state['revision'] != body.revision: raise HTTPException(409, 'تغيّرت الملفات. حدّث المشروع.')
    retrying = body.action == 'retry'
    if retrying:
        previous = state.get('job') or {}
        if previous.get('status') not in ('failed', 'cancelled') or previous.get('revision', body.revision) != body.revision:
            raise HTTPException(409, 'لا يوجد طلب متوقف لهذه النسخة. أرسل تعديلًا جديدًا.')
        last_user = next((m for m in reversed(state['messages']) if m.get('role') == 'user'), None)
        if not last_user: raise HTTPException(409, 'أرسل طلبك أولًا.')
        saved_request = previous.get('request') or {**body.model_dump(), 'action': 'message', 'text': last_user['content']}
        retry_selection = {key: getattr(body, key) for key in ('personality', 'deepThink') if key in body.model_fields_set}
        body = RunBody(**{**saved_request, **retry_selection, 'requestId': body.requestId, 'revision': body.revision})
        if body.action == 'repair' and body.repairContext is not None:
            # Retry is an explicit user action, not another automatic attempt.
            body.repairContext.automatic = False
    if body.action == 'approve':
        if not state.get('plan') or state['plan'].get('kind') != 'proposal' or body.proposalId != state.get('proposalId'):
            raise HTTPException(409, 'اعتمد التصور المعروض أولًا.')
        approved = state['plan']
    else: approved = state.get('approvedPlan') if body.action != 'discuss' else None
    if body.action == 'repair' and (not approved or not state['files']): raise HTTPException(409, 'لا يوجد مشروع معتمد لإصلاحه.')
    if body.repairContext is not None and body.action != 'repair':
        raise HTTPException(400, 'تشخيص الإصلاح متاح لطلب الإصلاح فقط.')
    repair_state = dict(state.get('repairState') or {'automaticAttempts': 0, 'fingerprints': []})
    source_model = None
    if body.repairContext is not None:
        # Validate paths with the same source policy and only forward real files.
        paths = validate_files({path: {'type': 'file', 'content': ''} for path in body.repairContext.affectedFiles})
        body.repairContext.affectedFiles = [path for path in paths if path in state['files']]
        if body.repairContext.automatic:
            source_model = state.get('sourceModel')
            previous = state.get('job') or {}
            if not source_model and previous.get('status') == 'completed' and previous.get('mode') == 'build' and previous.get('revision', -2) + 1 == state['revision']:
                source_model = {'modelSettings': previous.get('modelSettings'),
                    'personality': (previous.get('request') or {}).get('personality', 'deepdark'),
                    'deepThink': bool((previous.get('request') or {}).get('deepThink'))}
            if not source_model or not (source_model.get('modelSettings') or {}).get('model'):
                raise HTTPException(409, 'لا يوجد سجل نموذج لهذه النسخة. اختر النموذج واطلب الإصلاح يدويًا.')
            diagnostic = re.sub(r'\b\d+\b', '#', body.repairContext.diagnostic)
            fingerprint = hashlib.sha256((body.repairContext.step + ':' + diagnostic).encode()).hexdigest()
            attempts = int(repair_state.get('automaticAttempts') or 0)
            fingerprints = list(repair_state.get('fingerprints') or [])
            if attempts >= 2 or fingerprint in fingerprints:
                raise HTTPException(409, 'توقف الإصلاح التلقائي لهذه النسخة. راجع المشكلة ثم اطلب الإصلاح يدويًا.')
            # Reserved atomically with job acceptance, including cancelled jobs.
            repair_state = {'automaticAttempts': attempts + 1, 'fingerprints': [*fingerprints, fingerprint]}
            body.personality = source_model['personality']
            body.deepThink = bool(source_model.get('deepThink'))
    if body.action in ('message', 'approve', 'answers'):
        repair_state = {'automaticAttempts': 0, 'fingerprints': []}
    text = body.text.strip()
    if body.action == 'approve': text = 'اعتماد التصور وبدء التنفيذ'
    if body.action == 'answers': text = question_answer_text(state, body)
    if not text: raise HTTPException(400, 'اكتب طلبك أولًا.')
    if body.autoSuffix.strip(): text += '\n\n' + body.autoSuffix.strip()
    require_access(user, model=body.personality)
    settings = await current_settings(body.personality)
    if not settings['key_configured']: raise HTTPException(503, 'خدمة النموذج غير مهيأة؛ اطلب من الإدارة إعداد المفتاح.')
    settings = {**settings, **({key: value for key, value in source_model['modelSettings'].items() if key in MODEL_FIELDS} if source_model else {})}
    await check_can_afford(user, 1)
    jid = uuid.uuid4().hex
    history = list(state['messages'])[-28:]
    message = {'id': uuid.uuid4().hex, 'role': 'user', 'content': text}
    if body.action == 'answers':
        message.update(questionMessageId=body.questionMessageId, questionAnswers=[a.model_dump() for a in body.answers])
    if body.action == 'repair': message['annotations'] = [{'type': 'studioRepair', 'attempt': repair_state.get('automaticAttempts', 0),
        'automatic': bool(body.repairContext and body.repairContext.automatic)}]
    if not retrying: history.append(message)
    job = {'id': jid, 'status': 'running', 'mode': 'build' if approved else 'planning', 'startedAt': _now(), 'agents': [],
           'lastProgressAt': _now(), 'deadlineAt': (datetime.now(timezone.utc) + timedelta(seconds=JOB_TOTAL_SECONDS)).isoformat(),
           'revision': body.revision, 'request': body.model_dump(exclude={'requestId', 'revision'}),
           'model': settings['model'], 'modelSettings': {key: settings.get(key) for key in MODEL_FIELDS}}
    patch = {**state, 'messages': history, 'job': job, 'lastRequestId': body.requestId, 'darkMode': body.darkMode,
             'approvedPlan': approved, 'repairState': repair_state, 'phase': 'build' if approved else 'planning'}
    query = _cas(user['_id'], pid, body.revision); query['builder.job.status'] = {'$ne': 'running'}
    # File revisions do not change during planning. Fence the conversation as
    # well, so two tabs cannot overwrite each other's newer questions/answers.
    query['builder.lastRequestId'] = state.get('lastRequestId')
    result = await db.projects.update_one(query, {'$set': {'builder': patch, 'updated_at': _now()}})
    if not result.modified_count: raise HTTPException(409, 'بدأ طلب آخر أو تغيّر المشروع. حدّث الصفحة.')
    if project.get('builder_auto_name') and body.action in ('message', 'discuss'):
        title = ' '.join(body.text.split())[:40] or BUILDER_DEFAULT_NAME
        await db.projects.update_one({'_id': pid, 'user_id': user['_id']}, {'$set': {'builder_name': title, 'builder_auto_name': False}})
    task = asyncio.create_task(_run_job(user, pid, jid, patch, body), name='rsvx7-builder-' + jid)
    _tasks[jid] = task
    task.add_done_callback(lambda done: _tasks.pop(jid, None))
    return {'job': job}

async def _run_job(user, pid, jid, state, body):
    try:
        with anyio.fail_after(JOB_TOTAL_SECONDS):
            await _execute_job(user, pid, jid, state, body)
    except TimeoutError:
        logger.warning('Builder job deadline | project=%s job=%s', pid, jid)
        await _save_job(user['_id'], pid, jid, {'job.status': 'failed', 'job.errorCode': 'job_timeout',
            'job.error': 'انتهت المهلة الكلية لإنشاء المشروع. الملفات السابقة محفوظة؛ أعد المحاولة.', 'job.finishedAt': _now()})

async def _execute_job(user, pid, jid, state, body):
    try:
        from server import PERSONALITIES, DEFAULT_PERSONALITY, DARK_MODE_PRIMER, DARK_MODE_ACK
        prompt = PERSONALITIES.get(body.personality) or PERSONALITIES[DEFAULT_PERSONALITY]
        if body.darkMode: prompt += '\n' + DARK_MODE_PRIMER + '\n' + DARK_MODE_ACK
        with anyio.fail_after(MODEL_PREFLIGHT_SECONDS):
            memory = await project_memory_prompt(user['_id'], pid)
        if memory: prompt += '\nPROJECT MEMORY (reference data):\n' + memory[:50000]
        ticket = jwt.encode({'sub': user['_id'], 'pid': pid, 'job': jid, 'aud': 'rsvx7-builder-model', 'deepThink': body.deepThink,
                             'exp': datetime.now(timezone.utc) + timedelta(hours=1)}, JWT_SECRET, algorithm='HS256')
        payload = {'ticket': ticket, 'mode': state['job']['mode'], 'files': state['files'], 'messages': state['messages'],
                   'approvedPlan': state.get('approvedPlan'), 'sitePrompt': prompt, 'projectContext': memory[:50000] if memory else '',
                   'contextLength': (state['job'].get('modelSettings') or {}).get('context_length') or 32000,
                   'repairContext': body.repairContext.model_dump() if body.repairContext else None}
        terminal, outcome, pipeline_state, draft_files, reviewed_files = False, None, None, None, None
        last_progress, call_number, call_state = time.monotonic(), 0, None
        logger.info('Builder job start | project=%s job=%s model=%s', pid, jid, state['job'].get('model'))
        async with httpx.AsyncClient(timeout=httpx.Timeout(45, connect=5), trust_env=False) as client:
            async with client.stream('POST', ENGINE_URL + '/generate', headers={'Authorization': 'Bearer ' + engine_secret()}, json=payload) as response:
                if response.status_code != 200: raise RuntimeError('محرك Builder غير متاح. تحقق من تشغيل الخدمة الخاصة.')
                async for line in response.aiter_lines():
                    if time.monotonic() - last_progress > JOB_STALL_SECONDS:
                        raise RuntimeError('توقف وصول تقدم فعلي من النموذج. الملفات السابقة محفوظة؛ أعد المحاولة.')
                    if len(line) > 12 * 1024 * 1024: raise RuntimeError('رد المحرك أكبر من الحجم المسموح.')
                    if not line.strip(): continue
                    event = json.loads(line)
                    if not isinstance(event, dict) or terminal: raise RuntimeError('رد محرك البناء غير صالح؛ ملفاتك السابقة محفوظة.')
                    if outcome is not None and event.get('type') != 'done':
                        raise RuntimeError('وصل حدث بعد النتيجة النهائية؛ ملفاتك السابقة محفوظة.')
                    if event.get('type') == 'pipeline':
                        stage, completed, total = event.get('stage'), event.get('completed'), event.get('total')
                        if state['job']['mode'] != 'build' or stage not in ('structure', 'writing', 'reviewing') or type(completed) is not int or type(total) is not int or not 0 <= completed <= total <= 1500:
                            raise RuntimeError('حالة مراحل إنشاء المشروع غير صالحة.')
                        if total == 0 and (stage != 'structure' or completed != 0 or 'files' in event):
                            raise RuntimeError('حالة مخطط الملفات غير صالحة.')
                        prior_stage = pipeline_state['stage'] if pipeline_state else None
                        allowed = {None: ('structure',), 'structure': ('structure', 'writing'),
                            'writing': ('writing', 'reviewing'), 'reviewing': ('reviewing', 'writing')}
                        if stage not in allowed[prior_stage] or (prior_stage == 'structure' and stage == 'writing' and not pipeline_state['total']):
                            raise RuntimeError('ترتيب مراحل إنشاء المشروع غير صالح.')
                        if prior_stage == stage and (completed < pipeline_state['completed'] or total < pipeline_state['total']):
                            raise RuntimeError('تراجع تقدم مراحل إنشاء المشروع.')
                        pipeline_state = {'stage': stage, 'completed': completed, 'total': total}
                        patch = {'job.pipeline': pipeline_state, 'job.lastProgressAt': _now()}
                        if 'files' in event:
                            draft_files = validate_files(event['files'])
                            if not draft_files: raise RuntimeError('لم يرجع المحرك ملفات مسودة صالحة.')
                            patch['job.draftFiles'] = draft_files
                        reviewed_files = draft_files if stage == 'reviewing' and completed == total and total > 0 and 'files' in event else None
                        last_progress = time.monotonic()
                        await _save_job(user['_id'], pid, jid, patch)
                    elif event.get('type') == 'activity':
                        if outcome is not None: raise RuntimeError('وصل تقدم بعد نتيجة إنشاء المشروع.')
                        call_id, phase = event.get('callId'), event.get('phase')
                        chars, reasoning = event.get('chars'), event.get('reasoningChars')
                        if not isinstance(call_id, str) or not re.fullmatch(r'[a-zA-Z0-9_-]{8,100}', call_id) or phase not in ('waiting_provider', 'receiving', 'accounting', 'validating') or any(type(n) is not int or not 0 <= n <= 8 * 1024 * 1024 for n in (chars, reasoning)):
                            raise RuntimeError('بيانات تقدم النموذج غير صالحة.')
                        new_call = call_state is None or call_state['id'] != call_id
                        if new_call:
                            if phase != 'waiting_provider' or chars or reasoning: raise RuntimeError('ترتيب استدعاءات النموذج غير صالح.')
                            call_number += 1
                            call_state = {'id': call_id, 'number': call_number, 'startedAt': _now(), 'chars': 0, 'reasoningChars': 0}
                            logger.info('Builder model start | project=%s job=%s call=%s model=%s', pid, jid, call_number, state['job'].get('model'))
                        if chars < call_state['chars'] or reasoning < call_state['reasoningChars']: raise RuntimeError('تراجع عداد تقدم النموذج.')
                        advanced = chars + reasoning > call_state['chars'] + call_state['reasoningChars']
                        call_state.update(phase=phase, chars=chars, reasoningChars=reasoning, updatedAt=_now())
                        progress_patch = {'job.modelCall': dict(call_state)}
                        if advanced:
                            last_progress = time.monotonic(); progress_patch['job.lastProgressAt'] = _now()
                        await _save_job(user['_id'], pid, jid, progress_patch)
                    elif event.get('type') == 'validation':
                        if outcome is not None or state['job']['mode'] != 'build' or type(event.get('batch')) is not int or not 1 <= event['batch'] <= 100 or type(event.get('attempt')) is not int or not 1 <= event['attempt'] <= 3 or not isinstance(event.get('reason'), str):
                            raise RuntimeError('تشخيص صيغة الملفات غير صالح.')
                        validation = {'batch': event['batch'], 'attempt': event['attempt'], 'reason': event['reason'][:1200], 'at': _now()}
                        patch = {'job.validation': validation}
                        if call_state:
                            call_state.update(phase='retrying_format', updatedAt=_now()); patch['job.modelCall'] = dict(call_state)
                        await _save_job(user['_id'], pid, jid, patch)
                        logger.warning('Builder file format rejected | project=%s job=%s batch=%s attempt=%s', pid, jid, event['batch'], event['attempt'])
                    elif event.get('type') == 'agents':
                        tasks = event.get('tasks', [])
                        if not isinstance(tasks, list) or not 1 <= len(tasks) <= 4 or any(not isinstance(t, dict) or t.get('role') not in AGENTS or t.get('status') not in ('pending', 'running', 'completed', 'failed') for t in tasks) or len({t['role'] for t in tasks}) != len(tasks): raise RuntimeError('حالة الفريق غير صالحة.')
                        await _save_job(user['_id'], pid, jid, {'job.agents': tasks})
                    elif event.get('type') == 'generation':
                        if state['job']['mode'] != 'build' or outcome is not None or not isinstance(event.get('files'), int) or not isinstance(event.get('batches'), int) or not 0 <= event['files'] <= 1500 or not 1 <= event['batches'] <= 100:
                            raise RuntimeError('حالة إنشاء الملفات غير صالحة.')
                        last_progress = time.monotonic()
                        await _save_job(user['_id'], pid, jid, {'job.generation': {'files': event['files'], 'batches': event['batches']}, 'job.agents': [], 'job.lastProgressAt': _now()})
                    elif event.get('type') == 'plan':
                        if state['job']['mode'] != 'planning' or outcome is not None: raise RuntimeError('ترتيب أحداث البناء غير صالح.')
                        plan = event['plan']; mid = uuid.uuid4().hex
                        if plan.get('kind') not in ('reply', 'questions', 'proposal'): raise RuntimeError('التصور غير صالح.')
                        messages = state['messages'] + [{'id': mid, 'role': 'assistant', 'content': plan.get('message', ''), 'plan': plan}]
                        outcome = {'messages': messages[-30:], 'plan': plan, 'proposalId': mid, 'phase': 'review' if plan['kind'] == 'proposal' else 'planning'}
                    elif event.get('type') == 'files':
                        if state['job']['mode'] != 'build' or outcome is not None: raise RuntimeError('ترتيب أحداث البناء غير صالح.')
                        files = validate_files(event['files'])
                        if not files: raise RuntimeError('لم يرجع المحرك ملفات مشروع صالحة.')
                        if reviewed_files is None or files != reviewed_files:
                            raise RuntimeError('لم تكتمل مراجعة هذه الملفات؛ ملفاتك السابقة محفوظة.')
                        messages = state['messages'] + [{'id': uuid.uuid4().hex, 'role': 'assistant', 'content': 'تم تجهيز التعديلات.', 'annotations': [event['annotation']]}]
                        model_settings = state['job'].get('modelSettings') or {}
                        source_model = {'modelSettings': {key: model_settings.get(key) for key in MODEL_FIELDS},
                            'personality': (state['job'].get('request') or {}).get('personality', body.personality),
                            'deepThink': bool((state['job'].get('request') or {}).get('deepThink', body.deepThink))}
                        outcome = {'files': files, 'revision': state['revision'] + 1, 'messages': messages[-30:], 'phase': 'generated', 'checks': [],
                            'sourceModel': source_model, 'job.draftFiles': None}
                    elif event.get('type') == 'error':
                        code = event.get('code')
                        if isinstance(code, str) and re.fullmatch(r'[a-z_]{1,50}', code):
                            await _save_job(user['_id'], pid, jid, {'job.errorCode': code})
                        raise RuntimeError(str(event.get('message', 'تعذّر إكمال العمل.'))[:1000])
                    elif event.get('type') == 'done':
                        if outcome is None: raise RuntimeError('انتهى رد المحرك دون نتيجة مكتملة.')
                        terminal = True
                    else: raise RuntimeError('وصل حدث غير معروف من محرك البناء.')
        if not terminal or outcome is None: raise RuntimeError('انقطع رد المحرك قبل اكتماله.')
        await _save_job(user['_id'], pid, jid, {**outcome, 'job.status': 'completed', 'job.finishedAt': _now()})
        logger.info('Builder job complete | project=%s job=%s calls=%s', pid, jid, call_number)
    except asyncio.CancelledError: raise
    except Exception as error:
        message = str(error) if isinstance(error, RuntimeError) else 'تعذّر الاتصال بمحرك البناء. ملفاتك السابقة محفوظة.'
        code = 'generation_stalled' if isinstance(error, RuntimeError) and message.startswith('توقف وصول تقدم فعلي') else 'engine_timeout' if isinstance(error, (httpx.TimeoutException, TimeoutError)) else 'builder_error'
        logger.warning('Builder job failed | project=%s job=%s error=%s', pid, jid, type(error).__name__)
        await _save_job(user['_id'], pid, jid, {'job.status': 'failed', 'job.error': message[:1000], 'job.finishedAt': _now()})
        if code != 'builder_error': await db.projects.update_one({'_id': pid, 'user_id': user['_id'], 'builder.job.id': jid, 'builder.job.status': 'failed'}, {'$set': {'builder.job.errorCode': code}})

class ModelBody(BaseModel):
    callId: str = Field(pattern=r'^[a-zA-Z0-9_-]{8,100}$')
    messages: list[dict] = Field(min_length=1, max_length=65)
    jsonMode: bool = False
    stream: bool = False
    role: str | None = Field(default=None, pattern="^(coder|reviewer|architect|designer|planner|builder|file_planner|file_reviewer)$")
    criteria: list[str] = Field(default_factory=list, max_length=200)
    advisory: bool = False

async def _model_identity(request):
    token = request.headers.get('Authorization', '').removeprefix('Bearer ')
    try: scope = jwt.decode(token, JWT_SECRET, algorithms=['HS256'], audience='rsvx7-builder-model')
    except jwt.InvalidTokenError: raise HTTPException(401, 'Invalid Builder scope')
    uid, pid, jid = scope.get('sub'), scope.get('pid'), scope.get('job')
    if not all(isinstance(v, str) for v in (uid, pid, jid)): raise HTTPException(401, 'Invalid Builder scope')
    project = await db.projects.find_one({'_id': pid, 'user_id': uid, 'builder.job.id': jid, 'builder.job.status': 'running'})
    user = await db.users.find_one({'_id': uid})
    if not project or not user or user.get('status') == 'suspended': raise HTTPException(403, 'Builder scope ended')
    user = await refresh(user, db, grant_missing=False)
    require_access(user, feature='builder')
    return scope, uid, pid, jid, user, project

async def _model_result(body: ModelBody, request: Request, on_delta=None, on_progress=None):
    try:
        with anyio.fail_after(MODEL_CALL_SECONDS):
            return await _model_result_inner(body, request, on_delta, on_progress)
    except TimeoutError:
        raise HTTPException(504, 'انتهت مهلة استدعاء النموذج. ملفات المشروع السابقة محفوظة؛ أعد المحاولة.')

async def _model_result_inner(body: ModelBody, request: Request, on_delta=None, on_progress=None):
    scope, uid, pid, jid, user, project = await _model_identity(request)
    messages = []
    for message in body.messages:
        if message.get('role') not in ('system', 'user', 'assistant') or not isinstance(message.get('content'), str): raise HTTPException(400, 'Invalid model messages')
        messages.append({'role': message['role'], 'content': message['content']})
    if sum(len(m['content']) for m in messages) > 250000: raise HTTPException(413, 'سياق المشروع كبير؛ قلّل المرفقات أو الطلب.')
    from ai_settings import client, request_client, reasoning_capabilities
    job = project.get('builder', {}).get('job', {})
    selected_profile = (job.get('request') or {}).get('personality', 'deepdark')
    require_access(user, model=selected_profile)
    settings = await current_settings(selected_profile)
    # Keep every agent on the selected model/capabilities for this accepted job.
    # The credential remains server-only and can rotate independently.
    settings.update({key: value for key, value in (job.get('modelSettings') or {}).items() if key in MODEL_FIELDS})
    client = request_client(client)
    if client is None: raise HTTPException(503, 'خدمة النموذج غير مهيأة.')
    prompt_tokens = estimate_messages_tokens(messages)
    cap = min(32768, int(settings['max_completion_tokens']), int(settings['context_length']) - prompt_tokens - 256)
    exempt = user.get('role') in ('super_admin', 'admin', 'moderator', 'support')
    budget_prompt = prompt_tokens if exempt else int(prompt_tokens * 1.15) + 64
    if not exempt: cap = min(cap, max_completion_for_balance(int(user.get('token_balance') or 0), budget_prompt))
    if cap < 1: await check_can_afford(user, budget_prompt + 1); raise HTTPException(413, 'لا توجد مساحة كافية في سياق النموذج.')
    await check_can_afford(user, budget_prompt + cap)
    lease = await claim_generation(uid, ttl_seconds=max(240, int(MODEL_CALL_SECONDS) + 30))
    stream, text, reasoning, total_chars, finish, usage_p, usage_c, cached, seen = None, [], [], 0, None, 0, 0, 0, False
    reasoning_chars, last_reasoning_progress = 0, 0.0
    from server import _reasoning_delta
    try:
        capability = reasoning_capabilities(settings); extra = {}
        model_options = {}
        if body.jsonMode and 'response_format' in (settings.get('supported_parameters') or []):
            model_options['response_format'] = {'type': 'json_object'}
            if 'structured_outputs' in (settings.get('supported_parameters') or []):
                from builder_output import response_format
                structured = response_format(body.role, body.criteria)
                if structured: model_options['response_format'] = structured
        if capability['supports_reasoning'] or str(settings['model']).lower().startswith('deepseek/'):
            enabled = capability['reasoning_mandatory'] or bool(scope.get('deepThink'))
            extra = {'reasoning': {'enabled': enabled, 'exclude': False}}
            # Leave room for executable output. DeepSeek V4 defaults to high
            # reasoning; merely hiding reasoning does not reduce that budget.
            if enabled and 'reasoning_effort' in (settings.get('supported_parameters') or []):
                efforts = (settings.get('reasoning') or {}).get('supported_efforts') or []
                effort = next((level for level in ('low', 'minimal', 'medium', 'high', 'xhigh', 'max') if level in efforts), None)
                if effort: extra['reasoning']['effort'] = effort
        disconnected = False
        async def watch_disconnect(group):
            nonlocal disconnected
            while True:
                if await request.is_disconnected():
                    disconnected = True
                    group.cancel_scope.cancel()
                    return
                await anyio.sleep(0.3)
        async with anyio.create_task_group() as group:
            group.start_soon(watch_disconnect, group)
            with anyio.fail_after(420):
                while True:
                    try:
                        stream = await client.chat.completions.create(model=settings['model'], messages=messages, stream=True,
                            max_tokens=cap, stream_options={'include_usage': True}, extra_body=extra or None, **model_options)
                        break
                    except Exception as error:
                        from builder_output import rejects_response_format
                        if not model_options.get('response_format') or not rejects_response_format(error): raise
                        if model_options['response_format']['type'] == 'json_schema': model_options['response_format'] = {'type': 'json_object'}
                        else: model_options.pop('response_format')
                async for chunk in stream:
                    if getattr(chunk, 'error', None): raise RuntimeError('provider_unavailable')
                    usage = getattr(chunk, 'usage', None)
                    if usage is not None:
                        usage_p = int(getattr(usage, 'prompt_tokens', 0) or 0); usage_c = int(getattr(usage, 'completion_tokens', 0) or 0); seen = True
                        cached = int(getattr(getattr(usage, 'prompt_tokens_details', None), 'cached_tokens', 0) or getattr(usage, 'prompt_cache_hit_tokens', 0) or 0)
                    choices = getattr(chunk, 'choices', None) or []
                    if choices:
                        content = getattr(getattr(choices[0], 'delta', None), 'content', None)
                        reasoning_part = _reasoning_delta(getattr(choices[0], 'delta', None))
                        next_finish = getattr(choices[0], 'finish_reason', None)
                        if finish and ((isinstance(content, str) and content) or reasoning_part or (next_finish and next_finish != finish)):
                            raise RuntimeError('provider_protocol: content after terminal event')
                        if isinstance(content, str):
                            text.append(content); total_chars += len(content)
                            if content and on_delta is not None: await on_delta(content)
                        if reasoning_part:
                            reasoning.append(reasoning_part); total_chars += len(reasoning_part); reasoning_chars += len(reasoning_part)
                            if on_progress is not None and time.monotonic() - last_reasoning_progress >= 2:
                                await on_progress(reasoning_chars, 'receiving'); last_reasoning_progress = time.monotonic()
                        finish = next_finish or finish
                    if total_chars > 8 * 1024 * 1024: raise RuntimeError('Provider response too large')
            group.cancel_scope.cancel()
        if disconnected: raise HTTPException(499, 'Builder request cancelled')
        if finish in ('content_filter', 'content-filter'): raise RuntimeError('content_policy_violation')
        if finish not in ('stop', 'length', 'max_tokens'): raise RuntimeError('provider_protocol: incomplete or unsupported terminal event')
        # Optional advice may be empty. Preserve native billing: a rejected
        # empty code response never deducts user credits.
        if not ''.join(text).strip() and not body.advisory:
            if finish in ('length', 'max_tokens'):
                raise HTTPException(502, 'استهلك النموذج حد الإخراج قبل إرسال الملفات؛ أوقف التفكير العميق أو اختر حد إخراج أعلى. تم حفظ الملفات السابقة.')
            raise RuntimeError('empty_response')
        if not seen: usage_p, usage_c = prompt_tokens, estimate_messages_tokens([{'role': 'assistant', 'content': ''.join(reasoning) + ''.join(text)}])
        if on_progress is not None: await on_progress(reasoning_chars, 'accounting')
        await charge_user(uid, prompt_tokens=usage_p, completion_tokens=usage_c, cached_tokens=cached,
            user_input_tokens=max(1, estimate_messages_tokens([messages[-1]]) - 12), model=settings['model'],
            conversation_id='builder:' + pid, role_exempt=exempt, idempotency_key='builder:' + jid + ':' + body.callId)
        return {'text': ''.join(text), 'finishReason': finish}
    except HTTPException: raise
    except Exception as error:
        while isinstance(error, BaseExceptionGroup) and error.exceptions: error = error.exceptions[0]
        raise HTTPException(502, provider_error(error))
    finally:
        with anyio.CancelScope(shield=True):
            from provider_cleanup import close_provider_stream
            try:
                await close_provider_stream(stream)
            finally:
                with anyio.move_on_after(MODEL_CLEANUP_SECONDS, shield=True):
                    try: await release_generation(uid, lease)
                    except Exception: logger.warning('Builder lease cleanup failed | job=%s', jid)


@router.post('/internal/model')
async def model_call(body: ModelBody, request: Request):
    if not body.stream:
        return await _model_result(body, request)
    # Reject invalid capabilities before sending streaming headers. The worker
    # revalidates before spending credits, so cancellation/revocation still wins.
    try:
        with anyio.fail_after(MODEL_PREFLIGHT_SECONDS):
            await _model_identity(request)
    except TimeoutError:
        raise HTTPException(504, 'انتهت مهلة التحقق من طلب Builder. أعد المحاولة.')
    async def events():
        sender, receiver = anyio.create_memory_object_stream(16)
        async def delta(text): await sender.send({'type': 'delta', 'text': text})
        async def progress(reasoning, phase): await sender.send({'type': 'progress', 'reasoningChars': reasoning, 'phase': phase})
        async def work():
            try:
                result = await _model_result(body, request, delta, progress)
                await sender.send({'type': 'result', 'finishReason': result['finishReason']})
            except HTTPException as error:
                detail = error.detail
                message = detail if isinstance(detail, str) else detail.get('message', 'تعذّر إكمال طلب النموذج.') if isinstance(detail, dict) else 'تعذّر إكمال طلب النموذج.'
                await sender.send({'type': 'error', 'status': error.status_code, 'message': message})
            except Exception as error:
                await sender.send({'type': 'error', 'status': 502, 'message': provider_error(error)})
            finally:
                await sender.aclose()
        async with sender, receiver, anyio.create_task_group() as group:
            group.start_soon(work)
            try:
                yield '\n'  # flush headers before the provider starts thinking
                while True:
                    try:
                        with anyio.move_on_after(MODEL_HEARTBEAT_SECONDS) as heartbeat:
                            event = await receiver.receive()
                        if heartbeat.cancel_called:
                            yield '\n'
                            continue
                    except anyio.EndOfStream: break
                    yield json.dumps(event, ensure_ascii=False, separators=(',', ':')) + '\n'
            except GeneratorExit:
                return
            finally:
                group.cancel_scope.cancel()
    return StreamingResponse(events(), media_type='application/x-ndjson', headers={'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no'})
