"""Optional direct image analysis through an OpenAI-compatible provider."""
import base64
import io
import logging
import os

import httpx
from openai import AsyncOpenAI
from PIL import Image
from starlette.concurrency import run_in_threadpool

logger = logging.getLogger(__name__)


def normalize_image(data):
    with Image.open(io.BytesIO(data)) as image:
        image = image.convert("RGB")
        image.thumbnail((1600, 1600))
        output = io.BytesIO()
        image.save(output, format="JPEG", quality=88)
    return base64.b64encode(output.getvalue()).decode("ascii")


async def describe_image(data: bytes) -> str:
    model = os.environ.get("VISION_MODEL", "").strip()
    if not model:
        return ""
    dedicated = None
    try:
        key = os.environ.get("VISION_API_KEY", "").strip()
        base = os.environ.get("VISION_BASE_URL", "").strip()
        if key:
            dedicated = AsyncOpenAI(
                api_key=key,
                base_url=base or os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
                timeout=httpx.Timeout(90.0, connect=10.0), max_retries=0,
            )
            client = dedicated
        elif base:
            # A separately configured endpoint must have its own credential.
            logger.warning("VISION_API_KEY is required with VISION_BASE_URL")
            return ""
        else:
            from ai_settings import current_settings, request_client
            await current_settings()
            client = request_client()
        if client is None:
            return ""
        encoded = await run_in_threadpool(normalize_image, data)
        result = await client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "Describe the image accurately and transcribe visible text. Use Arabic when Arabic text is visible, otherwise English."},
                {"role": "user", "content": [
                    {"type": "text", "text": "Describe this image and its visible text."},
                    {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + encoded}},
                ]},
            ],
            max_tokens=2048,
        )
        return (result.choices[0].message.content or "").strip()
    except Exception as error:
        # Never return provider exceptions or credentials to the browser.
        logger.warning("Image analysis unavailable (%s); local OCR remains available", type(error).__name__)
        return ""
    finally:
        if dedicated is not None:
            await dedicated.close()
