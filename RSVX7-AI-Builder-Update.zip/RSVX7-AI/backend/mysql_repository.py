"""مستودع MySQL غير متصل تلقائياً عند الاستيراد.

الواجهة تحافظ على أسماء collections وعمليات التطبيق الحالية دون بناء shim
Mongo عام: كل operators محددة في sql_document_ops، وكل جدول وعمود SQL من
whitelist ثابتة في sql_schema. جميع الكتابات داخل معاملات، ومعاملات التطبيق
المركبة تستطيع تمرير collections للحصول على صفوف أقفال منطقية بترتيب معجمي.
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone
import asyncio
import json
import os
import re
import ssl as ssl_module
from typing import Any, AsyncIterator, Iterable, Mapping, Sequence
from urllib.parse import parse_qsl, unquote, urlsplit
import uuid

try:
    from pymongo.errors import DuplicateKeyError
except Exception:  # pragma: no cover - legacy application normally supplies pymongo
    class DuplicateKeyError(Exception):
        """نفس اسم خطأ التطبيق حتى تعمل اختبارات MySQL المستقلة."""

try:
    import asyncmy
    from asyncmy.cursors import DictCursor
except Exception as exc:  # pragma: no cover - dependency is supplied by runtime
    asyncmy = None
    DictCursor = None
    _ASYNCMY_IMPORT_ERROR = exc

from sql_document_ops import (
    CompiledQuery,
    MISSING,
    TYPED_FIELDS,
    UnsafeFieldError,
    apply_projection,
    apply_update,
    compile_filter,
    dumps_document,
    get_path,
    loads_document,
    matches_document,
    upsert_seed,
    utc_datetime,
    validate_field_for_collection,
)
from sql_schema import (
    BASE_COLUMNS,
    COLLECTION_TABLES,
    DECLARED_INDEXES,
    LOCK_TABLE,
    MIGRATIONS,
    SCHEMA_TABLE,
    SCHEMA_VERSION,
)


class MySQLConfigurationError(ValueError):
    """DSN أو TLS غير آمن/غير صالح."""


class SchemaNotReadyError(RuntimeError):
    """المخطط غير مهيأ؛ شغّل migration قبل تشغيل الخادم."""


@dataclass(frozen=True)
class WriteResult:
    acknowledged: bool = True
    matched_count: int = 0
    modified_count: int = 0
    deleted_count: int = 0
    inserted_id: Any = None
    upserted_id: Any = None


@dataclass(frozen=True)
class ParsedDSN:
    host: str
    port: int
    user: str
    password: str = field(repr=False)
    database: str
    ssl_context: ssl_module.SSLContext | None
    connect_kwargs: dict[str, Any] = field(repr=False)
    local_plaintext: bool


_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
_SAFE_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_DATE_COLUMNS = {"created_at", "updated_at", "registered_at", "last_login", "last_opened_at", "redeemed_at", "starts_at", "expires_at", "banned_at", "timestamp"}
_BOOL_COLUMNS = {"is_owner", "is_archived", "is_favorite", "is_pinned", "is_deleted", "enabled"}
_INT_COLUMNS = {"token_balance", "item_order", "order_index", "next_order_index", "tokens", "telegram_id"}


def _local_host(host: str) -> bool:
    return host.lower().strip("[]") in _LOCAL_HOSTS


def _parse_tls_json(value: str) -> dict[str, Any]:
    try:
        decoded = json.loads(unquote(value))
    except (TypeError, json.JSONDecodeError) as exc:
        raise MySQLConfigurationError("mysqlssl must be valid JSON") from exc
    if not isinstance(decoded, dict):
        raise MySQLConfigurationError("mysqlssl must be a JSON object")
    return decoded


def _ssl_context_from_options(options: Mapping[str, Any], *, managed: bool) -> ssl_module.SSLContext:
    insecure_keys = {"verify", "verify_identity", "check_hostname", "rejectUnauthorized"}
    for key in insecure_keys:
        if key in options and options[key] in (False, 0, "0", "false", "False", "no"):
            raise MySQLConfigurationError("insecure MySQL TLS options are rejected")
    for key in ("insecure", "skip_verify"):
        if options.get(key) in (True, 1, "1", "true", "True", "yes"):
            raise MySQLConfigurationError("insecure MySQL TLS options are rejected")
    context = ssl_module.create_default_context()
    ca = options.get("ca") or options.get("cafile") or options.get("ca_cert")
    if ca:
        ca_text = str(ca)
        try:
            if "BEGIN CERTIFICATE" in ca_text:
                context.load_verify_locations(cadata=ca_text)
            else:
                context.load_verify_locations(cafile=ca_text)
        except (OSError, ssl_module.SSLError) as exc:
            raise MySQLConfigurationError("mysqlssl CA certificate could not be loaded") from exc
    cert = options.get("cert") or options.get("certfile")
    key = options.get("key") or options.get("keyfile")
    if cert:
        try:
            context.load_cert_chain(certfile=str(cert), keyfile=str(key) if key else None)
        except (OSError, ssl_module.SSLError) as exc:
            raise MySQLConfigurationError("mysqlssl client certificate could not be loaded") from exc
    # Managed/TiDB endpoints always verify identity. Local TLS also verifies;
    # only explicit local plaintext is permitted as a test choice.
    context.check_hostname = True
    context.verify_mode = ssl_module.CERT_REQUIRED
    return context


def parse_mysql_dsn(url: str, *, allow_local_plaintext: bool = False) -> ParsedDSN:
    """تحليل DSN مع دعم mysqlssl JSON الشائع في Manus دون تسجيل الأسرار."""
    if not isinstance(url, str) or not url:
        raise MySQLConfigurationError("MySQL DSN is required")
    parsed = urlsplit(url)
    if parsed.scheme.lower() not in {"mysql", "mysql+asyncmy", "mariadb"}:
        raise MySQLConfigurationError("DSN scheme must be mysql://, mariadb://, or mysql+asyncmy://")
    host = parsed.hostname or ""
    if not host:
        raise MySQLConfigurationError("MySQL DSN host is required")
    try:
        port = int(parsed.port or 3306)
    except ValueError as exc:
        raise MySQLConfigurationError("Invalid MySQL port") from exc
    user = unquote(parsed.username or "")
    password = unquote(parsed.password or "")
    database = unquote(parsed.path.lstrip("/"))
    if not user or not database:
        raise MySQLConfigurationError("MySQL DSN user and database are required")
    query = {key.lower(): value for key, value in parse_qsl(parsed.query, keep_blank_values=True)}
    is_local = _local_host(host)
    explicit_plaintext = allow_local_plaintext
    ssl_options: dict[str, Any] | None = None
    for key in ("mysqlssl", "ssl", "tls"):
        if key in query:
            raw = query[key]
            if raw.lower() in {"0", "false", "off", "disable", "disabled", "none"}:
                if not is_local or not allow_local_plaintext:
                    raise MySQLConfigurationError("plaintext MySQL is allowed only for explicit localhost tests")
                explicit_plaintext = True
            elif raw:
                ssl_options = _parse_tls_json(raw) if raw.lstrip().startswith(("{", "%7B")) else {"ca": raw}
    for key in ("sslmode", "verify", "verify_identity", "insecure", "skip_verify"):
        if key in query:
            value = query[key].lower()
            if key == "sslmode" and value in {"disable", "allow", "prefer"}:
                if not is_local or not allow_local_plaintext:
                    raise MySQLConfigurationError("insecure sslmode is rejected")
                explicit_plaintext = True
            elif value in {"0", "false", "off", "no", "disable"}:
                raise MySQLConfigurationError("insecure MySQL TLS query value is rejected")
    if is_local and explicit_plaintext and ssl_options is None:
        ssl_context = None
    else:
        # Managed connections default to the system trust store when Manus did
        # not include mysqlssl; this still verifies the endpoint.
        ssl_context = _ssl_context_from_options(ssl_options or {}, managed=not is_local)
    kwargs: dict[str, Any] = {
        "host": host, "port": port, "user": user, "password": password,
        "db": database, "autocommit": False, "charset": "utf8mb4",
    }
    if ssl_context is not None:
        kwargs["ssl"] = ssl_context
    return ParsedDSN(host, port, user, password, database, ssl_context, kwargs, ssl_context is None)


class _CursorBase:
    """Cursor متأخر التنفيذ حتى تطابق find() سلوك Motor."""
    def __init__(self, collection: "MySQLCollection", query: Mapping[str, Any], projection: Mapping[str, Any] | None):
        self.collection = collection
        self.query = dict(query or {})
        self.projection = dict(projection) if projection else None
        self.sort_spec: list[tuple[str, int]] = []
        self._limit: int | None = None
        self._skip = 0
        self._loaded: list[dict[str, Any]] | None = None
        self._position = 0

    def sort(self, key_or_list: Any, direction: int | None = None):
        if isinstance(key_or_list, str):
            specs = [(key_or_list, int(direction if direction is not None else 1))]
        else:
            specs = [(str(key), int(value)) for key, value in key_or_list]
        for sort_field, order in specs:
            if order not in (-1, 1):
                raise ValueError("sort direction must be 1 or -1")
            validate_field_for_collection(self.collection.name, sort_field)
        self.sort_spec = specs
        return self

    def limit(self, value: int):
        self._limit = int(value) if value else None
        return self

    def skip(self, value: int):
        self._skip = max(0, int(value))
        return self

    async def _load(self, length: int | None = None) -> list[dict[str, Any]]:
        if self._loaded is not None:
            return self._loaded
        cap = self._limit
        if length is not None and length > 0:
            cap = min(cap, length) if cap is not None else length
        self._loaded = await self.collection._find_documents(
            self.query, self.projection, self.sort_spec, cap, self._skip,
        )
        return self._loaded

    async def to_list(self, length: int | None = None) -> list[dict[str, Any]]:
        rows = await self._load(length)
        if length is None or length <= 0:
            return rows[self._position:]
        return rows[self._position:self._position + length]

    def __aiter__(self):
        return self

    async def __anext__(self):
        rows = await self._load()
        if self._position >= len(rows):
            raise StopAsyncIteration
        value = rows[self._position]
        self._position += 1
        return value


class _ListCursor:
    def __init__(self, values: list[dict[str, Any]]):
        self.values = values
        self.position = 0

    async def to_list(self, length: int | None = None) -> list[dict[str, Any]]:
        if length is None or length <= 0:
            return self.values[self.position:]
        return self.values[self.position:self.position + length]

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self.position >= len(self.values):
            raise StopAsyncIteration
        value = self.values[self.position]
        self.position += 1
        return value


class _AggregateCursor:
    def __init__(self, collection, pipeline):
        self.collection, self.pipeline = collection, pipeline
        self.result = None

    async def _load(self):
        if self.result is None:
            self.result = await self.collection._aggregate(self.pipeline)
        return self.result

    async def to_list(self, length=None):
        return await (await self._load()).to_list(length)

    def __aiter__(self):
        return self

    async def __anext__(self):
        return await (await self._load()).__anext__()


class MySQLCollection:
    """واجهة collection ضيقة لعقود routes الحالية."""
    def __init__(self, database: "MySQLDatabase", name: str):
        if name not in COLLECTION_TABLES:
            raise ValueError(f"Unsupported collection: {name}")
        self.database = database
        self.name = name
        self.table = COLLECTION_TABLES[name]

    def _validate_field(self, field: str) -> str:
        return validate_field_for_collection(self.name, field)

    def _typed_fields(self) -> Mapping[str, str]:
        return TYPED_FIELDS.get(self.name, {})

    async def _find_documents(
        self, query: Mapping[str, Any], projection: Mapping[str, Any] | None,
        sort_spec: Sequence[tuple[str, int]], limit: int | None, skip: int,
    ) -> list[dict[str, Any]]:
        compiled = compile_filter(query, field_validator=self._validate_field, typed_fields=self._typed_fields())
        params = list(compiled.params)
        order = ""
        if sort_spec:
            terms = []
            for field, direction in sort_spec:
                expr, expr_params = self.database._sort_expression(self.name, field)
                terms.append(f"({expr} IS NULL) ASC, {expr} {'DESC' if direction < 0 else 'ASC'}")
                params.extend(expr_params)
            order = " ORDER BY " + ", ".join(terms)
        limit_sql = ""
        if limit is not None:
            limit_sql = " LIMIT %s"
            params.append(max(0, int(limit)))
        if skip:
            limit_sql += " OFFSET %s"
            params.append(max(0, int(skip)))
        sql = f"SELECT `data` FROM `{self.table}` WHERE {compiled.sql}{order}{limit_sql}"
        async with self.database._connection() as conn:
            rows = await self.database._fetchall(conn, sql, params)
        output: list[dict[str, Any]] = []
        for row in rows:
            document = loads_document(row.get("data") if isinstance(row, Mapping) else row[0])
            if "_id" not in document and isinstance(row, Mapping):
                # data written by this repository always includes _id; this is
                # only a safe recovery for manually prepared SQL fixtures.
                document["_id"] = row.get("doc_id")
            if matches_document(document, query):
                output.append(apply_projection(document, projection))
        return output

    async def find_one(self, query: Mapping[str, Any] | None = None, projection: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        rows = await self.find(query, projection).limit(1).to_list(1)
        return rows[0] if rows else None

    def find(self, query: Mapping[str, Any] | None = None, projection: Mapping[str, Any] | None = None) -> _CursorBase:
        return _CursorBase(self, query or {}, projection)

    async def count_documents(self, query: Mapping[str, Any] | None = None) -> int:
        compiled = compile_filter(query or {}, field_validator=self._validate_field, typed_fields=self._typed_fields())
        sql = f"SELECT COUNT(*) AS `count` FROM `{self.table}` WHERE {compiled.sql}"
        async with self.database._connection() as conn:
            rows = await self.database._fetchall(conn, sql, compiled.params)
        return int((rows[0].get("count") if rows and isinstance(rows[0], Mapping) else rows[0][0]) or 0) if rows else 0

    async def insert_one(self, document: Mapping[str, Any]) -> WriteResult:
        doc = dict(document)
        if "_id" not in doc:
            doc["_id"] = uuid.uuid4().hex
        async with self.database.transaction((self.name,)) as conn:
            try:
                await self.database._insert_row(conn, self.name, doc)
            except Exception as exc:
                self.database._raise_duplicate(exc)
                raise
        return WriteResult(inserted_id=doc["_id"])

    async def update_one(self, query: Mapping[str, Any], update: Mapping[str, Any], *, upsert: bool = False) -> WriteResult:
        async with self.database.transaction((self.name,)) as conn:
            rows = await self.database._locked_documents(conn, self.name, query)
            if rows:
                old = rows[0]
                new = apply_update(old, update, is_insert=False)
                await self.database._replace_row(conn, self.name, new)
                return WriteResult(matched_count=1, modified_count=int(new != old))
            if not upsert:
                return WriteResult()
            seed = upsert_seed(query)
            new = apply_update(seed, update, is_insert=True)
            if "_id" not in new:
                new["_id"] = uuid.uuid4().hex
            # A same-_id document that fails the filter is a duplicate key, not
            # a silent replacement. This is the required CAS/upsert contract.
            conflict = await self.database._document_by_id(conn, self.name, new["_id"], for_update=True)
            if conflict is not None:
                raise DuplicateKeyError(f"duplicate _id for upsert: {new['_id']!r}")
            try:
                await self.database._insert_row(conn, self.name, new)
            except Exception as exc:
                self.database._raise_duplicate(exc)
                raise
            return WriteResult(upserted_id=new["_id"])

    async def update_many(self, query: Mapping[str, Any], update: Mapping[str, Any], *, upsert: bool = False) -> WriteResult:
        if upsert:
            raise ValueError("update_many upsert is not part of the application contract")
        async with self.database.transaction((self.name,)) as conn:
            rows = await self.database._locked_documents(conn, self.name, query)
            modified = 0
            for old in rows:
                new = apply_update(old, update, is_insert=False)
                await self.database._replace_row(conn, self.name, new)
                modified += int(new != old)
            return WriteResult(matched_count=len(rows), modified_count=modified)

    async def find_one_and_update(
        self, query: Mapping[str, Any], update: Mapping[str, Any], *, upsert: bool = False,
        return_document: Any = False, **kwargs: Any,
    ) -> dict[str, Any] | None:
        result_after = bool(return_document)
        async with self.database.transaction((self.name,)) as conn:
            rows = await self.database._locked_documents(conn, self.name, query)
            if rows:
                old = rows[0]
                new = apply_update(old, update, is_insert=False)
                await self.database._replace_row(conn, self.name, new)
                return new if result_after else old
            if not upsert:
                return None
            new = apply_update(upsert_seed(query), update, is_insert=True)
            if "_id" not in new:
                new["_id"] = uuid.uuid4().hex
            conflict = await self.database._document_by_id(conn, self.name, new["_id"], for_update=True)
            if conflict is not None:
                raise DuplicateKeyError(f"duplicate _id for upsert: {new['_id']!r}")
            try:
                await self.database._insert_row(conn, self.name, new)
            except Exception as exc:
                self.database._raise_duplicate(exc)
                raise
            return new if result_after else None

    async def delete_one(self, query: Mapping[str, Any]) -> WriteResult:
        async with self.database.transaction((self.name,)) as conn:
            rows = await self.database._locked_documents(conn, self.name, query)
            if not rows:
                return WriteResult()
            doc_id = str(rows[0]["_id"])
            await self.database._execute(conn, f"DELETE FROM `{self.table}` WHERE `doc_id` = %s", [doc_id])
            return WriteResult(deleted_count=1)

    async def delete_many(self, query: Mapping[str, Any]) -> WriteResult:
        async with self.database.transaction((self.name,)) as conn:
            rows = await self.database._locked_documents(conn, self.name, query)
            if not rows:
                return WriteResult()
            ids = [str(row["_id"]) for row in rows]
            placeholders = ",".join("%s" for _ in ids)
            await self.database._execute(conn, f"DELETE FROM `{self.table}` WHERE `doc_id` IN ({placeholders})", ids)
            return WriteResult(deleted_count=len(ids))

    def aggregate(self, pipeline: Sequence[Mapping[str, Any]]):
        # Existing routes call aggregate(...).to_list(), not await aggregate().
        return _AggregateCursor(self, pipeline)

    async def _aggregate(self, pipeline: Sequence[Mapping[str, Any]]) -> _ListCursor:
        """دعم group/sort/limit المستعملة في إحصاءات القسائم فقط."""
        stages = list(pipeline)
        groups = [i for i, stage in enumerate(stages) if "$group" in stage]
        if len(groups) != 1:
            raise ValueError("Exactly one application $group is required")
        group_position = groups[0]
        before_matches = []
        for stage in stages[:group_position]:
            if set(stage) != {"$match"}:
                raise ValueError("Only $match can precede the application group")
            before_matches.append(stage["$match"])
        query = {"$and": before_matches} if before_matches else {}
        compiled = compile_filter(query, field_validator=self._validate_field, typed_fields=self._typed_fields())
        group_stage = next((stage.get("$group") for stage in stages if "$group" in stage), None)
        if group_stage is None or not isinstance(group_stage, Mapping):
            raise ValueError("Only the application's $group aggregate is supported")
        group_id = group_stage.get("_id")
        if group_id is not None and (not isinstance(group_id, str) or not group_id.startswith("$")):
            raise ValueError("Aggregate group _id must be null or a field reference")
        group_field = group_id[1:] if isinstance(group_id, str) else None
        if group_field:
            self._validate_field(group_field)
        sums: list[tuple[str, str | int]] = []
        for alias, expression in group_stage.items():
            if alias == "_id":
                continue
            if not _SAFE_IDENTIFIER.fullmatch(str(alias)) or not isinstance(expression, Mapping) or set(expression) != {"$sum"}:
                raise ValueError("Only named $sum accumulators are supported")
            operand = expression["$sum"]
            if operand != 1 and (not isinstance(operand, str) or not operand.startswith("$")):
                raise ValueError("$sum must be 1 or a field reference")
            if isinstance(operand, str):
                self._validate_field(operand[1:])
            sums.append((str(alias), operand))
        # SQL aggregation keeps the read bounded to selected columns and avoids
        # loading the whole collection for common coupon statistics.
        select: list[str] = []
        params: list[Any] = []
        if group_field:
            expr, p = self.database._sort_expression(self.name, group_field)
            select.append(f"{expr} AS `group_value`")
            params.extend(p)
        else:
            select.append("NULL AS `group_value`")
        for alias, operand in sums:
            if operand == 1:
                select.append(f"COUNT(*) AS `{alias}`")
            else:
                expr, p = self.database._sort_expression(self.name, operand[1:])
                select.append(f"COALESCE(SUM(CAST({expr} AS DECIMAL(65,18))), 0) AS `{alias}`")
                params.extend(p)
        sql = f"SELECT {', '.join(select)} FROM `{self.table}` WHERE {compiled.sql}"
        params.extend(compiled.params)
        if group_field:
            sql += " GROUP BY `group_value`"
        async with self.database._connection() as conn:
            rows = await self.database._fetchall(conn, sql, params)
        values: list[dict[str, Any]] = []
        for row in rows:
            value: dict[str, Any] = {"_id": row.get("group_value") if isinstance(row, Mapping) else row[0]}
            for alias, _ in sums:
                raw = row.get(alias) if isinstance(row, Mapping) else None
                value[alias] = int(raw or 0) if raw is not None and float(raw).is_integer() else raw
            values.append(value)
        for stage in stages[group_position + 1:]:
            if "$sort" in stage:
                spec = stage["$sort"]
                if not isinstance(spec, Mapping):
                    raise ValueError("$sort requires an object")
                for field, direction in reversed(list(spec.items())):
                    if field not in {"_id", *(alias for alias, _ in sums)}:
                        raise UnsafeFieldError(f"Unknown aggregate sort field: {field}")
                    values.sort(key=lambda item, f=field: (item.get(f) is None, item.get(f)), reverse=int(direction) < 0)
            elif "$limit" in stage:
                values = values[:int(stage["$limit"])]
            elif "$match" in stage:
                values = [value for value in values if matches_document(value, stage["$match"])]
            else:
                raise ValueError(f"Unsupported aggregate stage: {next(iter(stage))}")
        return _ListCursor(values)

    async def create_index(self, keys: Any, unique: bool = False, name: str | None = None, **kwargs: Any) -> str:
        index_name = name or self.database._declared_index_name(self.name, keys, unique)
        if index_name not in DECLARED_INDEXES.get(self.name, frozenset()):
            raise ValueError(f"Index is not declared in the additive SQL schema: {index_name}")
        # DDL migrations own indexes; repeated application calls are an explicit
        # no-op rather than an index drop/rebuild.
        return index_name

    async def index_information(self) -> dict[str, dict[str, Any]]:
        return {name: {"name": name} for name in DECLARED_INDEXES.get(self.name, frozenset())}

    async def drop_index(self, name: str) -> None:
        raise RuntimeError("Destructive index deletion is intentionally unsupported")


class MySQLDatabase:
    """قاعدة MySQL ذات collections صريحة وتهيئة يدوية فقط."""
    backend_name = "mysql"

    def __init__(self, url: str, *, minsize: int = 1, maxsize: int = 10,
                 allow_local_plaintext: bool = False, pool: Any = None, **kwargs: Any):
        self.url = url  # لا نعرضه في repr/log؛ يحمل secret
        self.parsed = parse_mysql_dsn(url, allow_local_plaintext=allow_local_plaintext)
        self.pool = pool
        self.minsize = int(minsize)
        self.maxsize = int(maxsize)
        self.pool_kwargs = {**self.parsed.connect_kwargs, **kwargs}
        self.pool_kwargs.setdefault("init_command", "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED")
        self.pool_kwargs.setdefault("connect_timeout", 10)
        self._pool_lock = asyncio.Lock()
        self._connection_var: ContextVar[Any] = ContextVar(f"rsvx7_mysql_connection_{id(self)}", default=None)
        self._transaction_depth: ContextVar[int] = ContextVar(f"rsvx7_mysql_depth_{id(self)}", default=0)
        self._locked_collections: ContextVar[frozenset[str]] = ContextVar(f"rsvx7_mysql_locks_{id(self)}", default=frozenset())
        self._collections = {name: MySQLCollection(self, name) for name in COLLECTION_TABLES}
        for name, collection in self._collections.items():
            setattr(self, name, collection)

    async def _ensure_pool(self):
        if self.pool is not None:
            return self.pool
        if asyncmy is None:
            raise RuntimeError(f"asyncmy is required: {_ASYNCMY_IMPORT_ERROR}")
        async with self._pool_lock:
            if self.pool is None:
                self.pool = await asyncmy.create_pool(
                    minsize=self.minsize, maxsize=self.maxsize, **self.pool_kwargs,
                )
        return self.pool

    async def ping(self) -> bool:
        async with self._connection() as conn:
            await self._execute(conn, "SELECT 1", [])
        return True

    async def initialize(self) -> int:
        """إنشاء/ترقية المخطط؛ لا تُستدعى عند import أو image build."""
        pool = await self._ensure_pool()
        conn = await pool.acquire()
        try:
            await self._execute(conn, f"""CREATE TABLE IF NOT EXISTS `{SCHEMA_TABLE}` (
                `version` INT NOT NULL PRIMARY KEY,
                `applied_at` DATETIME(6) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci""", [])
            rows = await self._fetchall(conn, f"SELECT MAX(`version`) AS `version` FROM `{SCHEMA_TABLE}`", [])
            current = int((rows[0] or {}).get("version") or 0)
            for migration in MIGRATIONS:
                if migration.version <= current:
                    continue
                await conn.begin()
                try:
                    for statement in migration.statements:
                        await self._execute(conn, statement, [])
                    await self._execute(conn, f"INSERT IGNORE INTO `{SCHEMA_TABLE}` (`version`, `applied_at`) VALUES (%s, %s)", [migration.version, datetime.now(timezone.utc)])
                    await conn.commit()
                except Exception:
                    await conn.rollback()
                    raise
                current = migration.version
            # Prepare lock rows once, outside domain transactions. Repeated
            # INSERT IGNORE on an existing key takes a shared lock and causes
            # deadlocks when concurrent callers then upgrade to FOR UPDATE.
            locks = await self._fetchall(conn, f"SELECT `lock_key` FROM `{LOCK_TABLE}`", [])
            existing = {row["lock_key"] for row in locks}
            for name in sorted(set(COLLECTION_TABLES) - existing):
                await self._execute(conn, f"INSERT IGNORE INTO `{LOCK_TABLE}` (`lock_key`) VALUES (%s)", [name])
            await conn.commit()
            return current
        finally:
            pool.release(conn)

    async def migrate(self) -> int:
        return await self.initialize()

    async def verify_schema(self) -> int:
        """قراءة الإصدار والجداول والأقفال المطلوبة؛ لا DDL أثناء الجاهزية."""
        async with self._connection() as conn:
            rows = await self._fetchall(conn, f"SELECT MAX(`version`) AS `version` FROM `{SCHEMA_TABLE}`", [])
            expected = set(COLLECTION_TABLES.values()) | {SCHEMA_TABLE, LOCK_TABLE}
            tables = await self._fetchall(conn, "SELECT TABLE_NAME AS name FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()", [])
            present = {row["name"] for row in tables}
            if not expected.issubset(present):
                raise SchemaNotReadyError("Required application tables are missing")
            locks = await self._fetchall(conn, f"SELECT `lock_key` FROM `{LOCK_TABLE}`", [])
            if not set(COLLECTION_TABLES).issubset({row["lock_key"] for row in locks}):
                raise SchemaNotReadyError("Required application domain locks are missing")
        current = int((rows[0] or {}).get("version") or 0)
        if current < SCHEMA_VERSION:
            raise SchemaNotReadyError(f"MySQL schema version {current} is below required {SCHEMA_VERSION}")
        return current

    async def close(self) -> None:
        pool, self.pool = self.pool, None
        if pool is None:
            return
        pool.close()
        wait_closed = getattr(pool, "wait_closed", None)
        if wait_closed is not None:
            result = wait_closed()
            if asyncio.iscoroutine(result):
                await result

    @asynccontextmanager
    async def transaction(self, collections: Iterable[str] = ()) -> AsyncIterator[Any]:
        """معاملة مشتركة، مع صف lock لكل collection بترتيب معجمي."""
        existing = self._connection_var.get()
        requested = tuple(sorted(set(collections)))
        for name in requested:
            if name not in COLLECTION_TABLES:
                raise ValueError(f"Unknown logical collection lock: {name}")
        if existing is not None:
            await self._lock_collections(existing, requested)
            yield existing
            return
        pool = await self._ensure_pool()
        conn = await pool.acquire()
        token_conn = self._connection_var.set(conn)
        token_depth = self._transaction_depth.set(1)
        token_locks = self._locked_collections.set(frozenset())
        try:
            await conn.begin()
            try:
                await self._lock_collections(conn, requested)
                yield conn
            except BaseException:
                await conn.rollback()
                raise
            else:
                await conn.commit()
        finally:
            self._locked_collections.reset(token_locks)
            self._transaction_depth.reset(token_depth)
            self._connection_var.reset(token_conn)
            pool.release(conn)

    @asynccontextmanager
    async def _connection(self) -> AsyncIterator[Any]:
        current = self._connection_var.get()
        if current is not None:
            yield current
            return
        pool = await self._ensure_pool()
        conn = await pool.acquire()
        try:
            yield conn
        finally:
            # A SELECT with autocommit disabled starts a read transaction. Clear
            # its snapshot before pooling so connections are reusable, not
            # discarded or returned with an old consistent-read snapshot.
            await conn.rollback()
            pool.release(conn)

    async def _lock_collections(self, conn: Any, names: Sequence[str]) -> None:
        already = self._locked_collections.get()
        needed = [name for name in names if name not in already]
        for name in sorted(needed):
            rows = await self._fetchall(conn, f"SELECT `lock_key` FROM `{LOCK_TABLE}` WHERE `lock_key` = %s FOR UPDATE", [name])
            if not rows:
                raise SchemaNotReadyError("Application domain locks need migration preparation")
        if needed:
            self._locked_collections.set(frozenset(set(already).union(needed)))

    async def _cursor(self, conn: Any):
        if DictCursor is None:
            return conn.cursor()
        return conn.cursor(DictCursor)

    async def _execute(self, conn: Any, sql: str, params: Sequence[Any]) -> Any:
        cursor = await self._cursor(conn)
        try:
            await cursor.execute(sql, tuple(params))
            return cursor
        finally:
            close = getattr(cursor, "close", None)
            if close is not None:
                result = close()
                if asyncio.iscoroutine(result):
                    await result

    async def _fetchall(self, conn: Any, sql: str, params: Sequence[Any]) -> list[Any]:
        cursor = await self._cursor(conn)
        try:
            await cursor.execute(sql, tuple(params))
            result = await cursor.fetchall()
            return list(result or [])
        finally:
            close = getattr(cursor, "close", None)
            if close is not None:
                result = close()
                if asyncio.iscoroutine(result):
                    await result

    def _table_columns(self, collection: str) -> tuple[str, ...]:
        return BASE_COLUMNS

    def _column_value(self, document: Mapping[str, Any], column: str) -> Any:
        if column == "doc_id":
            return str(document["_id"])
        field = column
        if column == "date_key":
            field = "date"
        elif column == "item_order":
            field = "order"
        value = get_path(document, field)
        if value is MISSING or value is None:
            return None
        if column in _BOOL_COLUMNS:
            return int(bool(value))
        if column in _INT_COLUMNS:
            try:
                return int(value)
            except (TypeError, ValueError):
                return None
        if column in _DATE_COLUMNS:
            return utc_datetime(value)
        if column in {"data", "doc_id"}:
            return value
        text = str(value)
        limit = 320 if column in {"dedup_key", "idempotency_key", "email"} else 191
        if len(text) > limit:
            raise ValueError(f"Application SQL field is too long: {column}")
        return text

    def _row_values(self, document: Mapping[str, Any]) -> list[Any]:
        values: list[Any] = []
        for column in BASE_COLUMNS:
            if column == "data":
                values.append(dumps_document(document))
            else:
                values.append(self._column_value(document, column))
        return values

    async def _insert_row(self, conn: Any, collection: str, document: Mapping[str, Any]) -> None:
        table = COLLECTION_TABLES[collection]
        columns = self._table_columns(collection)
        placeholders = ",".join("%s" for _ in columns)
        quoted = ",".join(f"`{column}`" for column in columns)
        await self._execute(conn, f"INSERT INTO `{table}` ({quoted}) VALUES ({placeholders})", self._row_values(document))

    async def _replace_row(self, conn: Any, collection: str, document: Mapping[str, Any]) -> None:
        table = COLLECTION_TABLES[collection]
        columns = [column for column in BASE_COLUMNS if column != "doc_id"]
        assignments = ",".join(f"`{column}` = %s" for column in columns)
        values = [dumps_document(document) if column == "data" else self._column_value(document, column) for column in columns]
        values.append(str(document["_id"]))
        try:
            await self._execute(conn, f"UPDATE `{table}` SET {assignments} WHERE `doc_id` = %s", values)
        except Exception as error:
            self._raise_duplicate(error)
            raise

    def _decode_rows(self, rows: Sequence[Any]) -> list[dict[str, Any]]:
        out = []
        for row in rows:
            raw = row.get("data") if isinstance(row, Mapping) else row[0]
            out.append(loads_document(raw))
        return out

    async def _locked_documents(self, conn: Any, collection: str, query: Mapping[str, Any]) -> list[dict[str, Any]]:
        compiled = compile_filter(query, field_validator=lambda field: validate_field_for_collection(collection, field), typed_fields=TYPED_FIELDS.get(collection, {}))
        table = COLLECTION_TABLES[collection]
        rows = await self._fetchall(conn, f"SELECT `data` FROM `{table}` WHERE {compiled.sql} FOR UPDATE", compiled.params)
        documents = self._decode_rows(rows)
        return [document for document in documents if matches_document(document, query)]

    async def _document_by_id(self, conn: Any, collection: str, value: Any, *, for_update: bool = False) -> dict[str, Any] | None:
        suffix = " FOR UPDATE" if for_update else ""
        rows = await self._fetchall(conn, f"SELECT `data` FROM `{COLLECTION_TABLES[collection]}` WHERE `doc_id` = %s{suffix}", [str(value)])
        if not rows:
            return None
        return loads_document(rows[0].get("data") if isinstance(rows[0], Mapping) else rows[0][0])

    def _raise_duplicate(self, exc: Exception) -> None:
        if isinstance(exc, DuplicateKeyError):
            raise exc
        errno = getattr(exc, "args", [None])[0] if getattr(exc, "args", None) else None
        message = str(exc).lower()
        if errno in {1062, 1169} or "duplicate" in message or "unique constraint" in message:
            raise DuplicateKeyError(str(exc)) from exc

    def _sort_expression(self, collection: str, field: str) -> tuple[str, list[Any]]:
        validate_field_for_collection(collection, field)
        if field == "_id":
            return "`doc_id`", []
        typed = TYPED_FIELDS.get(collection, {}).get(field)
        if typed:
            return f"`{typed}`", []
        return "JSON_UNQUOTE(JSON_EXTRACT(`data`, %s))", ["$." + field]

    def _declared_index_name(self, collection: str, keys: Any, unique: bool) -> str:
        if isinstance(keys, str):
            pairs = [(keys, 1)]
        else:
            pairs = list(keys)
        names = {
            ("users", (('username', 1),)): "uniq_rsvx7_users_username",
            ("users", (('registration_ip', 1),)): "idx_rsvx7_users_registration_ip",
            ("users", (('last_ip', 1),)): "idx_rsvx7_users_last_ip",
            ("usage", (('user_id', 1), ('date', 1))): "uniq_rsvx7_usage_user_date",
            ("tg_required_groups", (('order', 1),)): "idx_rsvx7_tg_groups_order",
            ("token_usage_history", (('user_id', 1), ('created_at', -1))): "idx_rsvx7_token_usage_history_user_created",
            ("token_usage_history", (("conversation_id", 1),)): "idx_rsvx7_token_usage_history_conversation",
            ("coupons", (("expires_at", 1),)): "idx_rsvx7_coupons_expires",
            ("redemptions", (('dedup_key', 1),)): "uniq_rsvx7_redemptions_dedup",
            ("redemptions", (("user_id", 1), ("code", 1))): "idx_rsvx7_redemptions_user_code",
            ("redemptions", (("redeemed_at", 1),)): "idx_rsvx7_redemptions_redeemed",
            ("redemptions", (("code", 1),)): "idx_rsvx7_redemptions_user_code",
            ("ai_request_leases", (("expires_at", 1),)): "idx_rsvx7_leases_expires",
        }
        normalized = tuple((str(k), int(v)) for k, v in pairs)
        direct = names.get((collection, normalized))
        if direct:
            return direct
        if collection == "users" and normalized == (("username", 1),):
            return "uniq_rsvx7_users_username"
        raise ValueError(f"Index keys are not declared for {collection}: {normalized!r}")


__all__ = [
    "DuplicateKeyError", "MySQLConfigurationError", "MySQLDatabase", "MySQLCollection",
    "ParsedDSN", "SchemaNotReadyError", "WriteResult", "parse_mysql_dsn",
]
