"""rsvx7 — Token-based billing (DeepSeek/OpenRouter style).

Design:
* Monthly allowances expire independently of permanent credit-pack top-ups.
* Every request pre-flight estimates the prompt cost using tiktoken (cl100k_base).
  Real charging always uses the `usage` block that DeepSeek returns after the
  stream ends (via `stream_options.include_usage`), so users are never billed
  based on an approximation — the tokenizer estimate is ONLY the pre-flight
  budget guard.
* `charge_user(uid, prompt_tokens, completion_tokens, ...)` atomically
  decrements `token_balance` and increments cumulative counters + writes a
  `token_usage_history` row.
* When `token_balance <= 0` (or below the pre-flight estimate) every AI
  endpoint returns 402 `insufficient_tokens` — the chat renders the same
  inline gate card used for `subscription_required`.
"""
from __future__ import annotations
import logging, math, os, secrets, hashlib
from datetime import datetime, timezone
from typing import Optional, List, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field, ConfigDict

from auth import db, current_user, require_admin, require_permission
from persistence import database_transaction, uses_mysql
from memberships import refresh as refresh_membership, wallet_fields

logger = logging.getLogger("tokens")

# Credit-pack top-ups. Wallet model — each pack ADDS to `token_balance`.
# Balance persists forever, never freezes, never expires.
PLAN_TOKENS = {
    "basic":     1_000_000,   #  $5
    "pro":       5_000_000,   # $10
    "unlimited": 15_000_000,  # $20
    # Legacy names — mapped to the same three packs.
    "plan1":     1_000_000,
    "plan2":     5_000_000,
    "plan3":     15_000_000,
    "trial":         5_000,   # legacy trial migration only
}

# Same numbers surfaced to buyers, with prices.
CREDIT_PACKS = [
    {"id": "basic",     "tokens":  1_000_000, "usd":  5, "label": "1M Tokens"},
    {"id": "pro",       "tokens":  5_000_000, "usd": 10, "label": "5M Tokens"},
    {"id": "unlimited", "tokens": 15_000_000, "usd": 20, "label": "15M Tokens"},
]

# Add-on packs (admin-only for now; a Stripe checkout can call these later)
ADDON_PACKS = {
    "250k": {"tokens": 250_000,   "usd": 2},
    "1m":   {"tokens": 1_000_000, "usd": 5},
    "5m":   {"tokens": 5_000_000, "usd": 15},
}

# Keep this single source of truth for both the final debit and the pre-flight
# guard. The UI-facing usage total is intentionally not this number.
BILLING_MULTIPLIER = 1.5


def required_billing_tokens(raw_tokens: int) -> int:
    """Return a conservative charge for a raw prompt/completion budget."""
    return int(math.ceil(max(0, int(raw_tokens or 0)) * BILLING_MULTIPLIER))


def available_raw_tokens(balance: int) -> int:
    """Maximum raw tokens that can be billed without exceeding a wallet."""
    if int(balance) < 0:
        return 0
    return int(math.floor(int(balance) / BILLING_MULTIPLIER))


def max_completion_for_balance(balance: int, prompt_tokens: int) -> int:
    """Budget helper for stream callers: raw completion cap after prompt."""
    return max(0, available_raw_tokens(balance) - max(0, int(prompt_tokens or 0)))

# tiktoken encoder for pre-flight prompt-cost estimation. DeepSeek uses its
# own tokenizer but cl100k is close enough for a budget guard.
try:
    import tiktoken
    _ENC = tiktoken.get_encoding("cl100k_base")
except Exception as e:
    _ENC = None
    logger.warning("tiktoken unavailable (%s) — falling back to char-based estimate", e)


def estimate_tokens(text: str) -> int:
    """Fast pre-flight estimate. Real charge uses DeepSeek's returned usage."""
    if not text: return 0
    if _ENC is not None:
        try: return len(_ENC.encode(text))
        except Exception: pass
    # Fallback: ~4 chars/token for latin, ~2 for CJK/Arabic — take the average.
    return max(1, len(text) // 3)


def estimate_messages_tokens(messages: list[dict]) -> int:
    """Approximate prompt-side token cost of a chat completions payload."""
    total = 0
    for m in messages:
        c = m.get("content")
        if isinstance(c, str):
            total += estimate_tokens(c)
        elif isinstance(c, list):
            # multimodal
            for part in c:
                if isinstance(part, dict) and isinstance(part.get("text"), str):
                    total += estimate_tokens(part["text"])
        total += 4  # per-message overhead (role, delimiters)
    return total + 8  # completion opener overhead


# ────────── DB helpers ──────────
async def get_balance(uid: str) -> dict:
    u = await db.users.find_one({"_id": uid})
    if not u: raise HTTPException(404, "User not found")
    u = await refresh_membership(u, db)
    return {
        **wallet_fields(u),
        "token_balance": int(u.get("token_balance") or 0),
        "total_used_tokens": int(u.get("total_used_tokens") or 0),
        "total_input_tokens": int(u.get("total_input_tokens") or 0),
        "total_output_tokens": int(u.get("total_output_tokens") or 0),
    }


class InsufficientTokensError(HTTPException):
    def __init__(self, remaining: int, needed: int):
        super().__init__(
            status_code=402,
            detail={
                "code": "insufficient_tokens",
                "remaining": remaining,
                "needed": needed,
                "message": "نفد رصيد التوكنات. يرجى شحن الرصيد للمتابعة.",
                "cta": "شحن الرصيد",
            },
        )


async def maybe_freeze_expired(user: dict) -> dict:
    """Wallet model — no expiry, no freeze. This is a no-op kept only so
    existing callers don't need to be rewritten."""
    return user


async def check_can_afford(user: dict, estimate: int) -> int:
    """Pre-flight gate matching the real multiplier and no-overdraw debit.

    A positive balance alone is not enough: the old "last 1 token" rule let a
    full stream run and then fail at final charging. Stream callers should use
    ``max_completion_for_balance`` to cap their request as well; this check is
    intentionally conservative because final usage can differ from an
    estimate.
    """
    if user.get("role") in ("super_admin", "admin", "moderator", "support"):
        return -1
    balance = int((user.get("token_balance") or 0))
    needed = max(1, required_billing_tokens(estimate))
    if balance < needed:
        raise InsufficientTokensError(remaining=balance, needed=needed)
    return balance


async def charge_user(uid: str, *, prompt_tokens: int, completion_tokens: int,
                      cached_tokens: int = 0, user_input_tokens: int = 0,
                      model: str = "", conversation_id: str | None = None,
                      role_exempt: bool = False,
                      idempotency_key: str | None = None) -> dict:
    # Lock both domains before reading: debit + ledger commit or roll back
    # together, including staff idempotency. No lock is held during AI streaming.
    async with database_transaction(db, collections=("token_usage_history", "users")):
        return await _charge_user(
            uid, prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
            cached_tokens=cached_tokens, user_input_tokens=user_input_tokens,
            model=model, conversation_id=conversation_id, role_exempt=role_exempt,
            idempotency_key=idempotency_key,
        )


async def _charge_user(uid: str, *, prompt_tokens: int, completion_tokens: int,
                       cached_tokens: int = 0, user_input_tokens: int = 0,
                       model: str = "", conversation_id: str | None = None,
                       role_exempt: bool = False,
                       idempotency_key: str | None = None) -> dict:
    """Deduct BILLABLE usage from the balance and write history.

    Billing model — matches DeepSeek's cache-discount pricing:
        billable_input  = prompt_tokens - cached_tokens   (cache hits are free)
        billable_output = completion_tokens
        billable_total  = billable_input + billable_output

    History captures both the raw DeepSeek numbers (for admin analytics) and
    the amount actually charged."""
    prompt_tokens = max(0, int(prompt_tokens or 0))
    completion_tokens = max(0, int(completion_tokens or 0))
    cached_tokens = max(0, int(cached_tokens or 0))
    billable_input = max(0, prompt_tokens - cached_tokens)
    raw_billable_total = billable_input + completion_tokens
    # Business multiplier: charge every user (regardless of plan) 1.5× the raw
    # DeepSeek billable usage. The stored history keeps BOTH the raw and the
    # multiplied number so admins can audit.
    billable_total = int(round(raw_billable_total * BILLING_MULTIPLIER))
    # The key is deliberately optional so existing callers remain unchanged.
    # When supplied it is stored on the user as an atomic marker, which makes a
    # retried request safe without putting a history row ahead of the debit.
    idempotency_key = str(idempotency_key).strip()[:200] if idempotency_key else None
    now = datetime.now(timezone.utc).isoformat()
    doc = {
        "_id": "u_" + secrets.token_urlsafe(9),
        "user_id": uid, "conversation_id": conversation_id,
        "model": model or "",
        # What the user actually typed (their contribution) — used for display.
        "user_input_tokens": int(user_input_tokens or 0),
        "assistant_output_tokens": completion_tokens,
        # Full DeepSeek numbers — kept for admin auditing.
        "full_prompt_tokens": prompt_tokens,
        "cached_tokens": cached_tokens,
        # What actually cost — used for balance deduction.
        "billable_input": billable_input,
        "billable_output": completion_tokens,
        "billable_tokens": billable_total,
        # Legacy field names, kept for backwards compat with any earlier readers.
        "input_tokens": prompt_tokens, "output_tokens": completion_tokens,
        "total_tokens": billable_total,
        "created_at": now,
    }
    if role_exempt:
        if idempotency_key:
            old = await db.token_usage_history.find_one({
                "user_id": uid, "idempotency_key": idempotency_key,
            })
            if old:
                return old
            doc["idempotency_key"] = idempotency_key
        await db.token_usage_history.insert_one(doc)
        return doc

    pending_path = "billing_pending.k" + hashlib.sha256(idempotency_key.encode()).hexdigest() if idempotency_key else None
    async def clear_pending():
        if pending_path:
            try: await db.users.update_one({"_id": uid}, {"$unset": {pending_path: ""}})
            except Exception: logger.warning("Deferred billing receipt cleanup uid=%s", uid)

    # Debit and cumulative counters must be one conditional Mongo write.  The
    # old implementation inserted history first, then decremented and finally
    # clamped the balance, which could overdraw under concurrent requests and
    # leave a history row when the debit failed.
    user_filter = {"_id": uid, "token_balance": {"$gte": billable_total}}
    inc = {
        "token_balance": -billable_total,
        "total_used_tokens": billable_total,
        "total_input_tokens": billable_input,
        "total_output_tokens": completion_tokens,
    }
    update = {"$inc": inc}
    if idempotency_key:
        user_filter["billing_charge_markers"] = {"$ne": idempotency_key}
        update["$addToSet"] = {"billing_charge_markers": idempotency_key}

    # CAS protects the expiring bucket against concurrent debits and renewals.
    # Existing permanent-only service users keep their previous billing behavior.
    monthly_debit, monthly_version = 0, None
    for _ in range(64):
        current = await db.users.find_one({"_id": uid})
        if not current: raise HTTPException(404, "User not found")
        current = await refresh_membership(current, db, grant_missing=False)
        monthly = current.get("monthly")
        if monthly and monthly.get("version"):
            monthly_debit = min(billable_total, max(0, int(monthly.get("remaining") or 0)))
            monthly_version = monthly["version"]
            user_filter["monthly.version"] = monthly_version
            user_filter["monthly.remaining"] = monthly["remaining"]
            inc["monthly.remaining"] = -monthly_debit
        doc["monthly_debit"] = monthly_debit
        doc["purchased_debit"] = billable_total - monthly_debit
        doc["monthly_period"] = monthly_version
        if pending_path:
            doc["idempotency_key"] = idempotency_key
            # A crash/retry between debit and ledger insert must reconstruct
            # the ORIGINAL split, not infer it from the already-debited bucket.
            update["$set"] = {pending_path: dict(doc)}
        charged = await db.users.update_one(user_filter, update)
        if charged.matched_count: break
        if int(current.get("token_balance") or 0) < billable_total or (idempotency_key and idempotency_key in (current.get("billing_charge_markers") or [])): break
    doc["monthly_debit"] = monthly_debit
    doc["purchased_debit"] = billable_total - monthly_debit
    doc["monthly_period"] = monthly_version
    if not charged.matched_count:
        current = await db.users.find_one(
            {"_id": uid},
            {"token_balance": 1, "billing_charge_markers": 1, "billing_pending": 1},
        )
        if not current:
            raise HTTPException(404, "User not found")
        # A retry after the debit but before history insertion must not debit
        # again.  Reconstructing the same row is safe because the optional
        # unique index below collapses concurrent history inserts.
        if idempotency_key and idempotency_key in (current.get("billing_charge_markers") or []):
            existing = await db.token_usage_history.find_one({
                "user_id": uid, "idempotency_key": idempotency_key,
            })
            if existing:
                await clear_pending()
                return existing
            receipt = (current.get("billing_pending") or {}).get(pending_path.split(".", 1)[1])
            if receipt: doc = receipt
            doc["idempotency_key"] = idempotency_key
            try:
                await db.token_usage_history.insert_one(doc)
            except Exception:
                existing = await db.token_usage_history.find_one({
                    "user_id": uid, "idempotency_key": idempotency_key,
                })
                if existing:
                    return existing
                raise
            await clear_pending()
            return doc
        if int(current.get("token_balance") or 0) >= billable_total:
            raise HTTPException(409, "تغيّر الرصيد؛ أعد المحاولة.")
        raise InsufficientTokensError(
            remaining=int(current.get("token_balance") or 0), needed=billable_total
        )

    if idempotency_key:
        doc["idempotency_key"] = idempotency_key
    try:
        # History is intentionally written only after the successful debit.
        await db.token_usage_history.insert_one(doc)
    except Exception:
        # Another retry may have inserted the same idempotency row while this
        # writer was committing. In that case the debit is already represented
        # by the shared marker and must not be compensated.
        if idempotency_key:
            existing = await db.token_usage_history.find_one({
                "user_id": uid, "idempotency_key": idempotency_key,
            })
            if existing:
                return existing
        # A failed history write must not turn a real debit into lost balance.
        # The inverse update is itself atomic and preserves concurrent changes.
        rollback = {"$inc": {
            "token_balance": billable_total,
            "total_used_tokens": -billable_total,
            "total_input_tokens": -billable_input,
            "total_output_tokens": -completion_tokens,
        }}
        if idempotency_key:
            rollback["$pull"] = {"billing_charge_markers": idempotency_key}
            rollback["$unset"] = {pending_path: ""}
        try:
            if monthly_version:
                rollback["$inc"]["monthly.remaining"] = monthly_debit
                restored = await db.users.update_one({"_id": uid, "monthly.version": monthly_version}, rollback)
                if not restored.matched_count:
                    # A renewed/expired period cannot receive old monthly funds.
                    # Compensate the failed debit as permanent credit instead.
                    rollback["$inc"].pop("monthly.remaining", None)
                    await db.users.update_one({"_id": uid}, rollback)
            else:
                await db.users.update_one({"_id": uid}, rollback)
        except Exception:
            logger.exception("Unable to compensate failed token history insert uid=%s", uid)
        raise
    await clear_pending()
    return doc


# ────────── Migration ──────────
async def migrate_legacy_users():
    """Backfill token_balance for users on the old plan1/plan2/plan3 system so
    they don't wake up with a zero balance after this deploy. Runs on startup;
    idempotent (only touches users whose token_balance field is missing)."""
    n_migrated = 0
    async for u in db.users.find({"token_balance": {"$exists": False}}):
        sub = u.get("subscription") or {}
        plan = (sub.get("plan") or "").lower()
        tokens = PLAN_TOKENS.get(plan)
        if tokens is None and u.get("trial_expires_at"):
            # Active trial? give trial tokens
            try:
                if datetime.fromisoformat(u["trial_expires_at"]) > datetime.now(timezone.utc):
                    tokens = PLAN_TOKENS["trial"]
            except Exception: pass
        if tokens is None:
            tokens = 0
        await db.users.update_one({"_id": u["_id"]}, {"$set": {
            "token_balance": tokens,
            "total_used_tokens": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
        }})
        n_migrated += 1
    if n_migrated:
        logger.info("Token migration: backfilled %d users", n_migrated)


async def ensure_indexes():
    if uses_mysql(db):
        return
    await db.token_usage_history.create_index([("user_id", 1), ("created_at", -1)])
    await db.token_usage_history.create_index("conversation_id")
    try:
        await db.token_usage_history.create_index(
            [("user_id", 1), ("idempotency_key", 1)],
            unique=True,
            partialFilterExpression={"idempotency_key": {"$exists": True}},
            name="uniq_token_charge_idempotency",
        )
    except Exception:
        # Legacy duplicate rows must not prevent the service from starting;
        # user-side atomic markers still prevent a second debit.
        logger.warning("Could not create token idempotency index", exc_info=True)


# ────────── Routers ──────────
billing_router = APIRouter(prefix="/api/billing")
admin_billing_router = APIRouter(prefix="/api/admin")


@billing_router.get("/balance")
async def api_balance(u: dict = Depends(current_user)):
    if u.get("role") in ("super_admin", "admin", "moderator", "support"):
        return {"token_balance": -1, "total_used_tokens": 0, "unlimited": True}
    return {**(await get_balance(u["_id"])), "unlimited": False}


@billing_router.get("/packs")
async def api_credit_packs():
    """Public list of credit packs — wallet model, no subscriptions."""
    return {"packs": CREDIT_PACKS}


@billing_router.get("/usage")
async def api_usage(limit: int = Query(50, ge=1, le=500), u: dict = Depends(current_user)):
    docs = await db.token_usage_history.find({"user_id": u["_id"]}).sort("created_at", -1).limit(limit).to_list(limit)
    return [{**d, "_id": str(d.get("_id"))} for d in docs]


class AddTokensBody(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    amount: int = Field(gt=0, le=100_000_000)
    reason: Optional[str] = "admin_add"


class SetBalanceBody(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    balance: int = Field(ge=0, le=1_000_000_000)


@admin_billing_router.post("/tokens/add")
async def admin_add_tokens(body: AddTokensBody, _: dict = Depends(require_permission("payments"))):
    r = await db.users.update_one({"_id": body.user_id}, {"$inc": {"token_balance": body.amount}})
    if not r.matched_count: raise HTTPException(404, "User not found")
    # audit trail: negative row for admin adjustments (input/output both zero)
    await db.token_usage_history.insert_one({
        "_id": "u_" + secrets.token_urlsafe(9),
        "user_id": body.user_id, "conversation_id": None,
        "model": "admin_adjust",
        "input_tokens": 0, "output_tokens": 0, "cached_tokens": 0,
        "total_tokens": -int(body.amount),  # negative → credit
        "reason": body.reason or "admin_add",
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    return {"ok": True, "balance": (await get_balance(body.user_id))["token_balance"]}


@admin_billing_router.post("/tokens/set")
async def admin_set_balance(body: SetBalanceBody, _: dict = Depends(require_permission("payments"))):
    from memberships import adjust_wallet
    user, _ = await adjust_wallet(db, body.user_id, purchased=body.balance)
    return {"ok": True, "balance": user["token_balance"], "purchased_remaining": body.balance}



@admin_billing_router.post("/tokens/reset")
async def admin_reset_balance(body: SetBalanceBody, _: dict = Depends(require_permission("payments"))):
    """Convenience: zero out the balance without touching cumulative counters."""
    r = await db.users.update_one({"_id": body.user_id}, {"$set": {"token_balance": 0, "monthly.remaining": 0}})
    if not r.matched_count: raise HTTPException(404, "User not found")
    return {"ok": True}


class UserOnlyBody(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str


@admin_billing_router.post("/tokens/deduct")
async def admin_deduct_tokens(body: AddTokensBody, _: dict = Depends(require_permission("payments"))):
    """Deduct N tokens from a user's balance (clamps at 0)."""
    from memberships import adjust_wallet
    user, deducted = await adjust_wallet(db, body.user_id, deduct=body.amount)
    await db.token_usage_history.insert_one({
        "_id": "u_" + secrets.token_urlsafe(9),
        "user_id": body.user_id, "conversation_id": None,
        "model": "admin_adjust",
        "user_input_tokens": 0, "assistant_output_tokens": 0,
        "full_prompt_tokens": 0, "cached_tokens": 0,
        "billable_input": 0, "billable_output": 0,
        "billable_tokens": int(deducted),
        "input_tokens": 0, "output_tokens": 0, "total_tokens": int(deducted),
        "reason": body.reason or "admin_deduct",
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    return {"ok": True, "balance": (await get_balance(body.user_id))["token_balance"]}


@admin_billing_router.post("/tokens/freeze")
async def admin_freeze_balance(body: UserOnlyBody, _: dict = Depends(require_permission("payments"))):
    """Wallet model — freeze is deprecated (no expiry, no subscription).
    Kept as a no-op so old admin buttons don't 404."""
    u = await db.users.find_one({"_id": body.user_id})
    if not u: raise HTTPException(404, "User not found")
    return {"ok": True, "frozen": 0, "note": "wallet model — freeze deprecated"}


@admin_billing_router.post("/tokens/unfreeze")
async def admin_unfreeze_balance(body: UserOnlyBody, _: dict = Depends(require_permission("payments"))):
    """Wallet model — unfreeze is deprecated. No-op stub."""
    u = await db.users.find_one({"_id": body.user_id})
    if not u: raise HTTPException(404, "User not found")
    return {"ok": True, "restored": 0, "note": "wallet model — no frozen balance to restore"}
